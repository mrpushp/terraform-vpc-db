import logging
#import maestro
import os
import sys
import re
import stat

logger = logging.getLogger("DB2/install.py")
scriptdir = '/tmp/db2scripts'
basedir = os.path.join(scriptdir, 'DB2')
libdir = os.path.join(basedir, 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
import util

if not basedir in sys.path:
    sys.path.append(basedir)
from DB2_DBMS import DB2_DBMS
from DB2_Instance import DB2_Instance

#Take arguments
installDir=sys.argv[1]   # /opt/IBM/db2
databaseFixpack=sys.argv[2] #""
db2level=sys.argv[3]            #""
fixpacksList=sys.argv[4]   #""
instanceMountPoint=sys.argv[5]
instanceOwner=sys.argv[6]  #""
instanceOwnerPassword=sys.argv[7]
#instanceOwnerUID=sys.argv[8]
instanceOwnerUID=500
instanceOwnerGroup=sys.argv[9]
instancePort=sys.argv[10]
instanceOwnerGroupID=sys.argv[11]
#fencedUserID=sys.argv[12]
fencedUserID=501
fencedUserGroup=sys.argv[13]
fencedUserGroupID=sys.argv[14]
fencedUserPassword=sys.argv[15]
sysControlGroupID=sys.argv[16]
sysMaintGroupID=sys.argv[17]
sysMonGroupID=sys.argv[18]
sysControlGroupName=sys.argv[19]
sysMaintGroupName=sys.argv[20]
sysMonGroupName=sys.argv[21]
dbuserid=sys.argv[22]
fencedUser=sys.argv[23]
dbaasdir = '/dbaas'
if not os.path.exists(dbaasdir):
    os.makedirs(dbaasdir)
#os.chmod(dbaasdir, 0777)
os.chmod(dbaasdir, stat.S_IRWXO)

if not os.path.exists(installDir):
    os.makedirs(installDir)
#os.chmod(dbaasdir, 0777)
os.chmod(installDir, stat.S_IRWXO)

#util.setupTagFile()

DB2_DBMS_agent = DB2_DBMS(installDir, databaseFixpack, db2level, fixpacksList)
DB2_DBMS_agent.install()
logger.debug('##################dbms installation finished!##################')
logger.debug("###################################################################")
logger.debug("#           Create and configure instance                         #")
logger.debug("###################################################################")

# work on instance file next
inst_name = instanceOwner

DB2_Instance_agent = DB2_Instance(inst_name, instanceOwnerUID, instanceOwnerGroup, instancePort,instanceOwnerGroupID,fencedUserGroupID, instanceMountPoint, instanceOwnerPassword, fencedUserID, fencedUserGroup, fencedUserPassword, sysControlGroupID, sysMaintGroupID, sysMonGroupID, sysControlGroupName, sysMaintGroupName, sysMonGroupName, dbuserid, fencedUser)
DB2_Instance_agent.install(DB2_DBMS_agent.get_dbms_home())

logger.debug("###################create instance: finished###################")
