import logging
import os
import sys
import re
import stat

scriptdir = '/tmp/db2scripts'
basedir = os.path.join(scriptdir, 'DB2')
libdir = os.path.join(basedir, 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
import util

cmd='ln -s /usr/lib64/libstdc++.so.6  /lib/libstdc++.so.6'
util.runShell(cmd)

installDir=sys.argv[1]   # /opt/IBM/db2/V11.1
instanceOwner=sys.argv[2]  #"db2inst1"
instanceOwnerPassword=sys.argv[3] #passw0rd
instancePort=sys.argv[4] #50000
fencedUser=sys.argv[5]  #db2fenc1
fencedUserGroup='db2fsdm1'
instanceOwnerGroup='db2iadm1'
fencedUserPassword=instanceOwnerPassword
daasUser='dasusr1'
daasUserpassword=instanceOwnerPassword
daasUserGroup='dasadm1'
instanceOwnerID='1004'
instanceOwnerGroupID='501'
fenceID='1003'
fenceGroupID='502'
daasID='1005'
daasGroupID='503'

if not os.path.exists(installDir):
    os.makedirs(installDir)
#os.chmod(dbaasdir, 0777)
os.chmod(installDir, stat.S_IRWXO)

#extract dir
extDir='/tmp/dbaas'
if not os.path.exists(extDir):
    os.makedirs(extDir)
cmd='tar -zxf /tmp/db2server/DB2S_11.5.4_MPML.tar.gz -C %s' % extDir
rc,out,err=util.runShell(cmd)
os.chdir('%s/server_dec/' % extDir)
cmd='./db2_install -y -n -p server -b %s' % installDir
rc,out,err=util.runShell(cmd)
print("#################db2 install finished##############")
cmd='groupadd -g %s %s' % (daasGroupID, daasUserGroup)
rc,out,err=util.runShell(cmd)
cmd='groupadd -g %s %s' % (fenceGroupID, fencedUserGroup)
rc,out,err=util.runShell(cmd)
cmd='groupadd -g %s %s' % (instanceOwnerGroupID,instanceOwnerGroup)
rc,out,err=util.runShell(cmd)

cmd='useradd -u %s -g %s  -m -d /home/%s %s' % (fenceID, fencedUserGroup, fencedUser, fencedUser)
rc,out,err=util.runShell(cmd)
#useradd -u 1005 -g dasadm1 -m -d /home/dasusr1 dasusr1
cmd='useradd -u %s -g %s  -m -d /home/%s %s' % (daasID, daasUserGroup, daasUser,daasUser)
rc,out,err=util.runShell(cmd)

cmd='useradd -u %s -g %s  -m -d /home/%s %s' % (instanceOwnerID, instanceOwnerGroup, instanceOwner,instanceOwner)
#useradd -u 1004 -g db2iadm1 -m -d /home/db2inst1 db2inst1
rc,out,err=util.runShell(cmd)
cmd='%s/instance/db2icrt -u %s %s' % (installDir, fencedUser, instanceOwner)
rc,out,err=util.runShell(cmd)

print("###################create instance: finished###################")
