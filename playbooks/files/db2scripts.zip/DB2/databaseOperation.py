#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import sys
import os
import maestro
import logging
import traceback
import time

libdir = os.path.join(maestro.node['scriptdir'], 'DB2', 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
import nls
from GlobalLock import Lock
nls.install()

logger = logging.getLogger("DB2/databaseOperation.py")
from DatabaseForSystemWorkload import DatabaseForSystemWorkload

LOCK_NAME = 'database_operation_lock'
rc = False
message = ''

# the exception for the operation
class OperationException(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

    def getValue(self):
        return self.value
    
with Lock(LOCK_NAME):
    try:
        parms = maestro.parms
        inst_name = maestro.parms['instanceOwner']
        op_parms = maestro.operation['parms']
        db_name = op_parms['databaseName']
        operation_action = maestro.operation['method']

        #==========================================================================================#        
        # backup|change_backup|scaleUp                                                             #
        #==========================================================================================#
        
        database_agent = DatabaseForSystemWorkload(inst_name, db_name, logger)
        if not database_agent.is_database_exist():
            raise OperationException("Failed to execute database operation because the database %s does not exist" % db_name)
        #===========================================backup=========================================#
        if operation_action == 'backup':
                #if HADR enabled and this node is primary, then backup
                # Set parameters for operation
                if op_parms.has_key('imageRequest'):
                    image_request = op_parms['imageRequest']
                else:
                    image_request = 'M' # [M: Manual backup, A: Automated backup, B: Baseline backup]
                
                if op_parms.has_key('imageName'):
                    image_name = op_parms['imageName']
                else:
                    image_name = ''
                    
                if op_parms.has_key('imageDescription'):
                        image_desc = op_parms['imageDescription']
                else:
                        image_desc = ''
                        
                # Call backup script
                rc, message = database_agent.backup(image_request, image_name, image_desc)
        #===========================================change_backup========================================#
        elif operation_action == 'change_backup':
            if op_parms.has_key('frequency'):
                frqcy = op_parms['frequency']
                if frqcy != 'once' and frqcy != 'daily' and frqcy != 'weekly' and frqcy != 'off':
                    rc = False
                    message ="The frequency value is not valid."
                    
                if op_parms.has_key('date') and op_parms.has_key('time'):
                    date_param = op_parms['date']
                    time_param = op_parms['time']
                    tm_wday = time.strftime("%w", time.strptime(date_param, "%Y%m%d"))
                    rc, message = database_agent.change_backup_frequency(frqcy, date_param, time_param, tm_wday)
                elif op_parms.has_key('timestamp'):                    
                    new_timestamp = op_parms['timestamp'] / 1000       
                    timeArray = time.localtime(new_timestamp)     
                    tm_year, tm_mon, tm_mday, tm_hour, tm_min, tm_wday = time.strftime("%Y %m %d %H %M %w", timeArray).split()
                    date_param='%s%s%s' % (tm_year, tm_mon, tm_mday)
                    time_param='%s:%s' % (tm_hour, tm_min)
                    rc, message = database_agent.change_backup_frequency(frqcy, date_param, time_param, tm_wday)
                else:
                    rc, message = database_agent.change_backup_frequency(frqcy)
            else:
                rc = False
                message ="There is no frequency field, auto-scheduled backup can not be triggered."
    
        #===========================================scale up========================================#
        elif operation_action == 'scaleUp':
            if op_parms.has_key('storage'):
                rc, message = database_agent.scaleupStorage(op_parms['storage'])
            else:
                rc = False
                message ="There is no disk size field, fail to scale up storage." 
    
    except OperationException as e:
            rc = False
            message = e.getValue()
    except:
        traceback.print_exc()
        #returnMsg = nls.msg('2121E')
        rc = False
        message = 'Failed because of unknown Exception'
    finally:
        maestro.operation['successful'] = rc
        maestro.operation['return_value'] = message