#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import logging
import maestro
import os
import sys
import re

###################################################################
#          import the lib and defined function                     #
###################################################################
# Get an logger with name "DB2/install.py"
logger = logging.getLogger("DB2/install.py")

scriptdir = maestro.node['scriptdir']
basedir = os.path.join(scriptdir, 'DB2')
libdir = os.path.join(basedir, 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
import util

if not basedir in sys.path:
    sys.path.append(basedir)
from DB2_DBMS import DB2_DBMS
from DB2_Instance import DB2_Instance


def restore_export_info():
    logger.debug("restore_export_info")
    import json
    export_json_file = "/tmp/export_json_file.json"
    restore_succeed = False
    try:
        maestro.storage.restore(export_json_file)
        logger.debug("restore via maestro.storage.restore")
        restore_succeed = True
    except:
        import traceback
        traceback.print_exc()
        if os.path.isfile(export_json_file):
            restore_succeed = True
            logger.debug("restore via export_json_file")
        else:
            logger.debug("export_json_file doesn't exist")
    if restore_succeed:
        logger.debug("retore export file info")
        with open(export_json_file) as f:
            maestro.export['DATABASES'] = json.load(f)

parms = maestro.parms

dbaasdir = '/dbaas'
if not os.path.exists(dbaasdir):
    os.makedirs(dbaasdir)
os.chmod(dbaasdir, 0777)

util.setupTagFile()

###################################################################
#                           instance profile                #
###################################################################
inst_name = parms['instanceOwner']

###################################################################
#              DBaaS upgrade and dbms installation                #
###################################################################
#get the selected fixpack details from the storehouse  
if 'fixpacksList' in parms:
    db2FixPack = parms['fixpacksList']
else:
    db2FixPack = ""

logger.debug("DB2 DBMS fixpack from UI/REST is: %s" % db2FixPack)

if maestro.isUpdate():
    logger.debug("###################################################################")
    logger.debug("#                        db2 DBMS upgrade                         #")
    logger.debug("###################################################################")
    restore_export_info()

    
    DB2_DBMS_agent = DB2_DBMS()
    DB2_DBMS_agent.upgrade_by_payload()
    logger.debug("##################upgrade DBMS: finished##################")
    # export_env()
    #sys.exit(0)
elif maestro.isRevert():
    logger.warn('Skip the revert function, only export the env')
    restore_export_info()
    #sys.exit(0)
else:
    logger.debug("###################################################################")
    logger.debug("#                      Install DBMS                               #")
    logger.debug("###################################################################")

    DB2_DBMS_agent = DB2_DBMS()
    DB2_DBMS_agent.install()
    logger.debug('##################dbms installation finished!##################')

    logger.debug("###################################################################")
    logger.debug("#           Create and configure instance                         #")
    logger.debug("###################################################################")
    inst_name = parms['instanceOwner']

    DB2_Instance_agent = DB2_Instance(inst_name)
    DB2_Instance_agent.install(DB2_DBMS_agent.get_dbms_home())

    logger.debug("###################create instance: finished###################")

logger.debug('install.py finished')
