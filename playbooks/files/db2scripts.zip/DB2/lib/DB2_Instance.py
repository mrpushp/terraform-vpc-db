#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#import maestro
import os
import util
import logging
import subprocess
import time
import traceback
import sys

from StorehouseUtil import StorehouseUtil
from UserGroupManager import UserGroupManager
from DB2User import DB2User
from DB2Group import DB2Group

scriptdir = '/tmp/db2scripts'

class DB2_Instance():
    def __init__(self, instance_name, instanceOwnerUID, instanceOwnerGroup, instancePort,instanceOwnerGroupID,fencedUserGroupID, instanceMountPoint, instanceOwnerPassword, fencedUserID, fencedUserGroup, fencedUserPassword, sysControlGroupID, sysMaintGroupID, sysMonGroupID, sysControlGroupName, sysMaintGroupName, sysMonGroupName,dbuserid, fencedUser):
        self.inst_name = instance_name
        self.instanceOwnerGroup = instanceOwnerGroup
        self.logger = logging.getLogger("DB2/DB2_Instance.py")
        vm_template_id='DB2'
        self.instancePort = instancePort
        self.instanceOwnerGroupID=instanceOwnerGroupID
        self.fencedUserGroupID=fencedUserGroupID
        self.instanceMountPoint=instanceMountPoint
        self.instanceOwnerPassword=instanceOwnerPassword
        self.fencedUserID=fencedUserID
        self.fencedUserGroup=fencedUserGroup
        self.fencedUserPassword=fencedUserPassword
        self.sysControlGroupID=sysControlGroupID
        self.sysMaintGroupID=sysMaintGroupID
        self.sysMonGroupID=sysMonGroupID
        self.sysControlGroupName=sysControlGroupName
        self.sysMaintGroupName=sysMaintGroupName
        self.sysMonGroupName=sysMonGroupName
        self.instanceOwnerUID=instanceOwnerUID
        self.dbuserid=dbuserid
        self.fencedUser=fencedUser
        ###################################################################
        #                           instance profile                      #
        ###################################################################
        #vm_template_id = maestro.node['id'][:maestro.node['id'].rindex('.')]
        self.instance_json_name = '%s_%s_instance_profile.json' % (vm_template_id, self.inst_name)
        self.logger.debug('=========init %s instance_profile.json================' % self.inst_name)
        self.inst_profile_content = {}
        dbaasdir = '/dbaas'
        instace_profile_local_url = os.path.join(dbaasdir, self.instance_json_name)
        self.storehouse_util = StorehouseUtil(instace_profile_local_url,instace_profile_local_url)
        '''instace_profile_local_url = os.path.join(dbaasdir, self.instance_json_name)
        if 'DEPLOYMENT_URL' in os.environ:
            remote_profile_url = os.path.join(os.environ['DEPLOYMENT_URL'], 'instances', self.instance_json_name)
        self.storehouse_util = StorehouseUtil(instace_profile_local_url, remote_profile_url)
        if self.storehouse_util.exist():
            if not self.downloadProfile():
                self.logger.debug("Error: fail to download instance profile because instance profile does not exist in storehouse.")
                self.inst_profile_content = {}
        else:
            self.logger.debug("Error: fail to initial instance profile because instance profile does not exist in storehouse.")
            self.logger.debug("Warning: instance profile does not exist in storehouse, will generate a new instance profile with users, groups and permission info.")
            self.inst_profile_content = {}
        '''
        self.shell_script = os.path.normpath(os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell'))

    def getInstanceProfile(self):
        return self.inst_profile_content

    # Download dbaas inst_profile_content from storehouse
    
    '''
    def downloadProfile(self):
        self.inst_profile_content = self.storehouse_util.download()
        if self.inst_profile_content == None:
            return False
        return True
    
    # Upload the inst_profile_content to storehouse
    def uploadProfile(self):
        self.storehouse_util.generate(self.inst_profile_content, new_collection='..')
    '''

    def isInstanceExists(self):
        return os.path.exists("/home/%s/sqllib/db2nodes.cfg" % self.inst_name)

    def openFirewallPolicy(self):
        INSTANCE_PORT = self.instancePort # instance inbound
        PORT_DEBUG_4553 = '4553' # inbound
        PORT_DEBUG_4554 = '4554' # outbound
        PORT_DEBUG_4555 = '4555' # outbound
        PORT_DEBUG_50010 = '50010' # inbound and outbound
        
        udpPorts = []
        #udpPorts.append(4789)
    
        tcpPorts=[]
        tcpPorts.append(INSTANCE_PORT)
        tcpPorts.append(PORT_DEBUG_4553)
        tcpPorts.append(PORT_DEBUG_4554)
        tcpPorts.append(PORT_DEBUG_4555)
        tcpPorts.append(PORT_DEBUG_50010)
        openicmp=False

        self.logger.debug('Setting up firewall policy')
        common.openPorts(tcpports, udpports, openicmp)
        
        '''maestro.firewall.open_tcpin(src = 'private', dport = INSTANCE_PORT)
        maestro.firewall.open_tcpin(src = 'private', dport = PORT_DEBUG_4553)
        maestro.firewall.open_tcpout(src = 'private', dport = PORT_DEBUG_4554)
        maestro.firewall.open_tcpout(src = 'private', dport = PORT_DEBUG_4555)
        maestro.firewall.open_tcpin(src = 'private', dport = PORT_DEBUG_50010)
        maestro.firewall.open_tcpout(src = 'private', dport = PORT_DEBUG_50010)
        '''
        
        '''
        if self.hasHADRDB():
            openicmp=True
            maestro.firewall.open_in(protocol="icmp")
            maestro.firewall.open_out(protocol="icmp")
            if 'portList' in self.inst_profile_content:
                from HADRManager import HADRManager
                for port in self.inst_profile_content['portList']:
                    maestro.firewall.open_tcpin(network='public', dport=port)
                    maestro.firewall.open_tcpout(network='public', dport=port)
                    maestro.firewall.open_tcpin(network='private', dport=port)
                    maestro.firewall.open_tcpout(network='private', dport=port)
                    if port in [HADRManager.GSPort, HADRManager.TSPort, HADRManager.RMCPort]:
                        maestro.firewall.open_in(protocol='udp', dport=port, network='public')
                        maestro.firewall.open_out(protocol='udp', dport=port, network='public')
                        maestro.firewall.open_in(protocol='udp', dport=port, network='private')
                        maestro.firewall.open_out(protocol='udp', dport=port, network='private')
        '''
                        

    @util.performance_profile_trace
    def prepareInstancePath(self):
        #parms = maestro.parms
        sysadm_group = self.instanceOwnerGroup
        inst_home = os.path.join('/home', self.inst_name)
        iMountPoint=self.instanceMountPoint
        instanceOwnerGroupID=self.instanceOwnerGroupID
        fencedUserGroupID=self.fencedUserGroupID
        instanceOwnerUID=self.instanceOwnerUID
        fencedUserID=self.fencedUserID
        
        #if iMountPoint and iMountPoint != "":
        if True:
            #instanceMountPoint = parms['instanceMountPoint'].strip()
            if not os.path.ismount(iMountPoint):
                self.logger.error("The mount point path:'%s' does not exist" % iMountPoint)
                sys.exit(1)

            #if iMountPoint == "/":
            #    self.logger.error("Illegal mount point: '%s' for instance" % iMountPoint)
            #    #maestro.check_status(1, "Illegal mount point for instance: '%s'" % instanceMountPoint)
            #    #sys.exit(1)

            if not os.path.exists(inst_home):
                #===========Code changes for RFE 92204==============#
                try: 
                    if instanceOwnerGroupID and instanceOwnerGroupID != "":
                        self.logger.debug('Instance Owner Group ID: %s' % instanceOwnerGroupID)
                        if int(instanceOwnerGroupID) >= 500 and int(instanceOwnerGroupID) != int(fencedUserGroupID):
                            self.logger.debug('Instance Owner Group ID is >= 500 and NOT equal to fencedUserGroupID value of instanceOwnerGroupID is : %s' % instanceOwnerGroupID)
                            self.logger.debug('Value of fencedUserGroupID is : %s' % fencedUserGroupID)  
                            args = [sysadm_group, instanceOwnerGroupID]
                            rc, out, err = util.runShell('add_group %s %s ' % (sysadm_group, instanceOwnerGroupID) )
                        else: 
                            self.logger.debug('Instance Owner Group ID is < 500 OR equal to fencedUserGroupID value of instanceOwnerGroupID is : %s' % instanceOwnerGroupID)    
                            self.logger.debug('Value of fencedUserGroupID is : %s' % fencedUserGroupID)
                            args = [sysadm_group]
                            rc, out, err = util.runShell('add_group %s' % (sysadm_group))
                    else : 
                        self.logger.debug('Instance Owner Group ID is not mentioned in parameters') 
                        args = [sysadm_group]
                        rc, out, err = util.runShell('add_group %s' % (sysadm_group))
                except:       
                    self.logger.debug('Handling Exception, creating group with automated ID')
                    args = [sysadm_group] 
                    rc, out, err = util.runShell('add_group %s' % (sysadm_group))
                #args = [sysadm_group]
                #===========Code changes for RFE 92204 ends==============#
                
                #rc = util.trace_shell_func_call('add_group', *args)
                #command = "ln -sf %s %s" % (iMountPoint, inst_home)
                #self.logger.debug('command string is %s' % command)
                #os.system(command)
                #create user
                #curr_inst_password = maestro.decode(parms['instanceOwnerPassword'])
                curr_inst_password = self.instanceOwnerPassword
                
                #===========Code changes for RFE 92204==============#
                
                try:
                    self.logger.debug('Instance Owner UID: %s' % instanceOwnerUID) 
                    if instanceOwnerUID and instanceOwnerUID != "":
                        self.logger.debug('Parm instanceOwnerUID exists and its value is: %s' % instanceOwnerUID)
                        if int(instanceOwnerUID) >= 500 and int(fencedUserID) != int(instanceOwnerUID):
                            self.logger.debug('Parm instanceOwnerUID exists and its value is >= 500 and not same as fencedUserID value of instanceOwnerUID is: %s' % instanceOwnerUID)
                            self.logger.debug('fencedUserID: %s' % fencedUserID)  
                            args = [self.inst_name, curr_inst_password, sysadm_group, instanceOwnerUID]
                            #rc = util.trace_shell_func_call('add_user', *args)
                            rc, out, err = util.runShell('add_user %s %s %s ' % (curr_inst_password, sysadm_group, instanceOwnerUID))
                        else:
                            self.logger.debug('Parm instanceOwnerUID exists and its value is < 500 OR is same as fencedUserID value of instanceOwnerUID is: %s' % instanceOwnerUID)
                            self.logger.debug('fencedUserID: %s' % fencedUserID)   
                            args = [self.inst_name, curr_inst_password, sysadm_group]
                            rc, out, err = util.runShell('add_user %s %s %s ' % (self.inst_name, curr_inst_password, sysadm_group))
                            #rc = util.trace_shell_func_call('add_user', *args)
                    else : 
                        self.logger.debug('Parm instanceOwnerUID does not exists') 
                        args = [self.inst_name, curr_inst_password, sysadm_group]
                        #rc = util.trace_shell_func_call('add_user', *args)
                        rc, out, err = util.runShell('add_user %s %s %s ' % (self.inst_name, curr_inst_password, sysadm_group))
                except:
                    self.logger.debug("Handling exception, creating group with automated ID")
                    args = [self.inst_name, curr_inst_password, sysadm_group]
                    #rc = util.trace_shell_func_call('add_user', *args)
                    rc, out, err = util.runShell('add_user %s %s %s ' % (self.inst_name, curr_inst_password, sysadm_group))
                
                #===========Code changes for RFE 92204 ends==============#
                
                #commandStr = 'chown %s:%s %s;chown %s:%s %s' % (self.inst_name, sysadm_group, iMountPoint, self.inst_name, sysadm_group, inst_home)
                print('chown    $$$$$ %s %s %s', (self.inst_name, sysadm_group, inst_home))
                commandStr = 'chown %s:%s %s' % (self.inst_name, sysadm_group, inst_home)
                self.logger.debug('command string is %s' % commandStr)
                os.system(commandStr)

    @util.performance_profile_trace
    def create_instance(self, dbms_home):
        #parms = maestro.parms
        user_agent = UserGroupManager(self.instance_json_name, self.logger, self.inst_name)
        # ===================== create required groups ============================#
        sysadm_group = self.instanceOwnerGroup
        fencedUserGroup = self.fencedUserGroup
        fencedUserGroupID=self.fencedUserGroupID
        instanceOwnerGroupID=self.instanceOwnerGroupID
        sysControlGroupID=self.sysControlGroupID
        sysMaintGroupID=self.sysMaintGroupID
        sysMonGroupID=self.sysMonGroupID
        sysControlGroupName=self.sysControlGroupName
        sysMaintGroupName=self.sysMaintGroupName
        sysMonGroupName=self.sysMonGroupName
        instanceOwnerGroup=self.instanceOwnerGroup
        sysctrl_group_id=''
        sysmnt_group_id=''
        sysmon_group_id=''
        group_list = []
        group_list.append(fencedUserGroup)
        group_list.append(sysadm_group)
        port=self.instancePort
        #===========Code changes for RFE 128497==============#
        if sysControlGroupID and sysControlGroupID!="":
            sysctrl_group_id=sysControlGroupID
        else:
            sysctrl_group_id=""        
        if sysMaintGroupID and sysMaintGroupID!="":
            sysmnt_group_id=sysMaintGroupID
        else:
            sysmnt_group_id=""        
        if sysMonGroupID and sysMonGroupID!="":
            sysmon_group_id=sysMonGroupID
        else:
            sysmon_group_id=""
        if sysControlGroupName and sysControlGroupName!="":
            sysctrl_group_name=sysControlGroupName
        else:
            sysctrl_group_name=""
        if sysMaintGroupName and sysMaintGroupName!="":
            sysmnt_group_name=sysMaintGroupName
        else:
            sysmnt_group_name =""
        if sysMonGroupName and sysMonGroupName != "":
            sysmon_group_name=sysMonGroupName
        else:
            sysmon_group_name=""  
        self.logger.debug('sysControlGroupName %s' % sysctrl_group_name)
        self.logger.debug('sysmnt_group_name %s' % sysmnt_group_name)
        self.logger.debug('sysmon_group_name %s' % sysmon_group_name)    
            
        #===========Code changes for RFE 128497 Ends==============#     
        #group_list.append(sysctrl_group_name)
        #group_list.append(sysmnt_group_name)
        #group_list.append(sysmon_group_name)
        #group_list.append('nonssh')
        if sysctrl_group_name != "" :
           group_list.append(sysctrl_group_name)
        if sysmnt_group_name != "" :
           group_list.append(sysmnt_group_name)
        if sysmon_group_name != "" :
           group_list.append(sysmon_group_name)
        group_list.append('nonssh')          
        for my_group in group_list:
            group_agent = DB2Group(groupName=my_group, isSysAdmGrp=True)
            user_agent.addGroup(group_agent, fencedUserGroupID, sysmon_group_id, instanceOwnerGroupID, sysctrl_group_id, sysmnt_group_id, fencedUserGroup, sysctrl_group_name, sysmon_group_name, sysmnt_group_name)
        # ===================== create required users ============================#
        inst_password = self.instanceOwnerPassword
        #inst_password = maestro.decode(parms['instanceOwnerPassword'])
        inst_user = DB2User(userName=self.inst_name, \
                          password=inst_password, \
                          groups=[sysadm_group],\
                          permission=['SYSADM'],\
                          description="DB2 instance user", \
                          sshAccess=True, \
                          isInstanceAdmin=True, \
                          isDatabaseAdmin=False, \
                          instanceName=self.inst_name)
        print("ANSHU inst_user, self.instanceOwnerUID, self.fencedUserID, self.dbuserid %s %s %s %s" % (inst_user, self.instanceOwnerUID, self.fencedUserID, self.dbuserid))
        user_agent.addUser(inst_user, self.instanceOwnerUID, self.fencedUserID, self.dbuserid)

        fencedUser = self.fencedUser
        #fencedUserPassword = maestro.decode(parms['fencedUserPassword'])
        fencedUserPassword = self.fencedUserPassword
        fenc_user = DB2User(userName=fencedUser, \
                          password=fencedUserPassword, \
                          groups=[fencedUserGroup],\
                          description="DB2 fence user", \
                          sshAccess=True, \
                          isInstanceAdmin=True, \
                          isDatabaseAdmin=False, \
                          instanceName=self.inst_name)
        user_agent.addUser(fenc_user, self.instanceOwnerUID, self.fencedUserID, self.dbuserid)

        self.inst_profile_content = user_agent.getDirectory()
           
        if  sysctrl_group_name != "" and sysmnt_group_name != "" and sysmon_group_name !="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup,
                "SYSCTRL": sysctrl_group_name,
                "SYSMAINT": sysmnt_group_name,
                "SYSMON": sysmon_group_name
            }
        elif sysctrl_group_name != "" and sysmnt_group_name != "" and sysmon_group_name =="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup,
                "SYSCTRL": sysControlGroupName,
                "SYSMAINT": sysMaintGroupName
            }
         
        elif sysctrl_group_name != "" and sysmnt_group_name == "" and sysmon_group_name =="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM":instanceOwnerGroup,
                "SYSCTRL": sysControlGroupName
            }
        elif sysctrl_group_name == "" and sysmnt_group_name == "" and sysmon_group_name =="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup
            }
        elif sysctrl_group_name == "" and sysmnt_group_name != "" and sysmon_group_name !="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup,
                "SYSMAINT": sysMaintGroupName,
                "SYSMON": sysMonGroupName
            }
        elif  sysctrl_group_name != "" and sysmnt_group_name == "" and sysmon_group_name !="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup,
                "SYSCTRL": sysControlGroupName,
                "SYSMON":sysMonGroupName
            }
        elif  sysctrl_group_name == "" and sysmnt_group_name != "" and sysmon_group_name =="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM": instanceOwnerGroup,
                "SYSMAINT": sysMaintGroupName
            }
        elif  sysctrl_group_name == "" and sysmnt_group_name == "" and sysmon_group_name !="":
            self.inst_profile_content["system_permission"] = {
                "SYSADM":instanceOwnerGroup,
                "SYSMON":sysMonGroupName
            }       
        
                              
        #self.inst_profile_content["system_permission"] = {
        #        "SYSADM": parms['instanceOwnerGroup'],
        #        "SYSCTRL": sysctrl_group_name,
        #        "SYSMAINT": sysmnt_group_name,
        #        "SYSMON": sysmon_group_name
        #    }

        #if 'sqlType' in parms:
        #    inst_sqltype = parms['sqlType']
        #else:
        inst_sqltype = ''
        inst_type = 'ese'
        self.inst_profile_content['instanceType'] = inst_type
        self.inst_profile_content['sqlType'] = inst_sqltype
        inst_port = port
        print("ANSHU %s" % self.shell_script)
        script = os.path.join(self.shell_script, 'create_inst.sh')
        args = []
        args.extend(['inst_name=%s' % self.inst_name])
        args.extend(['inst_type=%s' % inst_type])
        args.extend(['inst_port=%s' % str(inst_port)])
        args.extend(['inst_password="%s"' % inst_password])
        args.extend(['dbms_home="%s"' % dbms_home])
        args.extend(['sqltype=%s' % inst_sqltype])
        args.extend(['sysadm_group=%s' % sysadm_group])
        args.extend(['db2fadm_group=%s' % fencedUserGroup])
        args.extend(['db2fenc=%s' % fencedUser])
        args.extend(['fencedUserPassword="%s"' % fencedUserPassword])
        #===========Code changes for RFE 128497==============# 
        args.extend(['sysctrl_group_name="%s"' % sysctrl_group_name])
        args.extend(['sysmnt_group_name="%s"' % sysmnt_group_name])
        args.extend(['sysmon_group_name="%s"' % sysmon_group_name])
        args.extend(['sysctrl_group_id="%s"' % sysctrl_group_id])
        args.extend(['sysmnt_group_id="%s"' % sysmnt_group_id])
        args.extend(['sysmon_group_id="%s"' % sysmon_group_id])
        #===========Code changes for RFE 128497 Ends==============#
        ###Changes for RFE 128506 - Expose or set DB2_parallel_IO
        ### Added db2_parallel_io as argument
        
        '''
	if 'setdb2parallelioid' in parms:
           self.logger.debug('Configuring DB2_PARALLE_IO : %s' % parms['setdb2parallelioid']) 
           if parms['setdb2parallelioid']=="*":
              self.logger.debug('Configuring DB2_PARALLE_IO : %s' % parms['setdb2parallelioid'])
              args.extend(['db2_parallel_io="%s"' % parms['setdb2parallelioid']])
           else:
              if  parms['setdb2parallelioid']=="":
                  self.logger.debug('DB2_PARALLEL_IO is null inside if clause. This value will not be set.')
              elif int(parms['setdb2parallelioid']) > 0:
                  self.logger.debug('Configuring DB2_PARALLE_IO : %s' % parms['setdb2parallelioid'])
                  args.extend(['db2_parallel_io="%s"' % parms['setdb2parallelioid']])
              else:
                  self.logger.debug('DB2_PARALLEL_IO is null inside else clause. This value will not be set.')    
        else:
            self.logger.debug('setdb2parallelioid does not exist, DB2_PARALLEL_IO will not be set.')
        '''
        #rc,out,err=util.runShell('%s/install/db2chgpath' % dbms_home)
        #print('out = %s' % out) 
        #util.trace_call(self.logger, script, *args, echo_stdin = False)
        #util.trace_call(self.logger, script, *args, echo_stdin = False)
        rc,out,err=util.runShell('%s inst_name=%s inst_type=%s inst_port=%s inst_password="%s" dbms_home="%s" sqltype=%s sysadm_group=%s db2fadm_group=%s db2fenc=%s fencedUserPassword="%s" sysctrl_group_name="%s" sysmnt_group_name="%s" sysmon_group_name="%s" sysctrl_group_id="%s" sysmnt_group_id="%s" sysmon_group_id="%s"' % (script, self.inst_name, inst_type, str(inst_port), inst_password, dbms_home, inst_sqltype, sysadm_group, fencedUserGroup, fencedUser, fencedUserPassword, sysctrl_group_name, sysmnt_group_name, sysmon_group_name, sysctrl_group_id, sysmnt_group_id, sysmon_group_id))

        print('out = %s' % out) 
        print('err = %s' % err)
        #####Store the instance owner, fence user, 
        self.logger.debug('create instance: finished')
        print('create instance: finished')

    def update_profile(self, update_json=None):
        self.logger.debug("DB2_Instance.update_profile")
        '''
        if update_json == None:
            #parms = maestro.parms
            #vm_template_id = maestro.node['id'][:maestro.node['id'].rindex('.')]
            vm_template_id = 'DB2'
            self.inst_profile_content.update({
                "osType": subprocess.Popen(['uname', '-s'], stdout = subprocess.PIPE).communicate()[0].replace('\n', ''),
                "db2Level": util.get_db2_level(),
                "fencedUserGroup": self.fencedUserGroup,
                "fencedUser": self.fencedUser,
                "instanceOwner": self.instanceOwner,
                'instanceOwnerGroup': self.instanceOwnerGroup,
                "instanceMountPoint": self.instanceMountPoint,
                "vmTemplateID": vm_template_id,
                "instancePort": self.instancePort,
                "databases": []
            })
          '''
            #upload instance_profile
            #self.storehouse_util.updateDelta(self.inst_profile_content)
        '''else:
            self.storehouse_util.updateDelta(update_json)
        self.storehouse_util.upload()
        '''

    '''
    @util.performance_profile_trace
    def configure_TSM(self):
        parms = maestro.parms
        ###################################################################
        #                 Get TSM Server info and configure TSM                           #
        ###################################################################
        func_agent_sh = os.path.join(self.shell_script, 'func_agent.sh')
        isTSMConfigured = util.trace_call(self.logger, func_agent_sh, 'chk_if_tsm_client_configured', nocheck = 1)
        is_tsm_enabled = False
        if isTSMConfigured != 0:
            self.logger.debug("TSM client is not configured for DB2 database! The database will remain in circular log mode and will not support backup!")
        elif isTSMConfigured == 0:
            tsm_server_address = ''
            tsm_server_port = ''
            adminusername = ''
            adminpassword = ''
            tsm_node_name = ''
            db2domain = ''

            try:
                cred_file = '/tmp/.tsm_credential'
                f = file(cred_file, 'r')
                lst = f.read().strip()
                self.logger.debug('tsm_credential: ' + str(lst))
                tsm_server_address, tsm_server_port, adminusername, adminpassword, db2domain = eval(lst)
                f.close()

                role_id = maestro.node['id'][:maestro.node['id'].rindex('.')]
                deployment_id = maestro.node['deployment.id']
                tsm_node_name = role_id + '_' + deployment_id
                public_ip = maestro.node['instance']['public-ip']
                args = []
                args.extend([self.inst_name, adminusername, adminpassword, tsm_node_name, db2domain, public_ip])
                rc = util.trace_shell_func_call('configure_tsm', *args)
                if rc == 0:
                    #util.trace_call(logger, func_agent_sh, 'config_instance_for_tsm', self.inst_name)
                    self.inst_profile_content['tsm'] = {'address': tsm_server_address, 'port': tsm_server_port, 'nodeName': tsm_node_name, 'nodePassword': util.encode(adminpassword), 'db2domain': db2domain}
                    parms['tsm'] = self.inst_profile_content['tsm']
                    parms['tsm']['adminusername'] = adminusername
                    parms['tsm']['adminpassword'] = util.encode(adminpassword)
                    is_tsm_enabled = True
                else:
                    raise Exception('TSM configure failed')
            except Exception as e:
                print (e)
                maestro.check_status(1, 'Failed to configure TSM')
            finally:
                if os.path.exists(cred_file):
                    os.remove(cred_file)
        return is_tsm_enabled
    '''
        
    @util.performance_profile_trace
    def install(self, dbms_home):
        print("******ANSHU dbms_home = %s" % dbms_home)
        if self.isInstanceExists():
            self.logger.info("DB2 instance already installed, skip the installation process!")
        else:
            '''if not self.storehouse_util.exist():
                self.logger.debug("Warning: instance profile does not exist in storehouse, will generate a new instance profile.")
                self.storehouse_util.generate({}, new_collection='..')'''
            self.storehouse_util.generate({}, new_collection='..')
            self.prepareInstancePath()
            self.create_instance(dbms_home)
            #is_tsm_enabled = self.configure_TSM()
            is_tsm_enabled = False
            self.inst_profile_content['isTSMEnabled'] = is_tsm_enabled
            self.update_profile()

    @util.performance_profile_trace
    def restart(self):
        if self.hasHADRDB():
            util.trace_shell_func_call('start_all_instances_hadr', self.inst_name)
        else:
            util.trace_shell_func_call('restart_instance', self.inst_name)
            self.start_text_search()
    
    @util.performance_profile_trace
    def start(self):
        if not self.hasHADRDB():
            util.trace_shell_func_call('start_instance', self.inst_name)
        else:
            rc = util.trace_shell_func_call('start_ha_domain')
            rc = util.trace_shell_func_call('start_resource_group', self.inst_name)
        util.startCrontab()

    @util.performance_profile_trace
    def stop(self, force = False):
        if not self.hasHADRDB():
            rc = util.trace_shell_func_call('chk_if_user_exist', self.inst_name)
            if rc == 0:
                if force:
                    util.trace_shell_func_call('stop_instance', self.inst_name, 'force')
                else:
                    util.trace_shell_func_call('stop_instance', self.inst_name)
        else:
            rc = util.trace_shell_func_call('stop_resource_group', self.inst_name)
            rc = util.trace_shell_func_call('stop_rp_node')
       
    @util.performance_profile_trace
    def start_text_search(self):
        util.trace_shell_func_call('start_text_search', self.inst_name)

    def isTSMConfigured(self):
        return 'isTSMEnabled' in self.inst_profile_content and self.inst_profile_content['isTSMEnabled']

    @util.performance_profile_trace
    def stopHADomain(self, hostName):
        db2HAdomain_online = util.trace_shell_func_call('check_db2HAdomain_status')
        # If db2HAdomain still online, stop all nodes
        if db2HAdomain_online == 0:
            index = hostName.find(".")
            if index > -1:
                shortHostName = hostName[:index]
            else:
                shortHostName = hostName
            cmd = ['stoprpnode', '-f', shortHostName]
            #maestro.trace_call(self.logger, cmd)
            runShell(cmd)
        else:
            self.logger.debug("db2HADomain is offline") 

    def startHADomain(self):
        self.logger.debug("startHADomain")
        try:
            cmd = ['startrpdomain', 'db2HAdomain']
            #maestro.trace_call(self.logger, cmd)
            runShell(cmd)
            time.sleep(60)
            rc = util.trace_shell_func_call('check_db2HAdomain_status')
            # If db2HAdomain is offline, exit...
            if rc != 0: 
                self.logger.debug('Failed to start db2HAdomain')
        except:
            traceback.print_exc()

    def hasHADRDB(self):
        if self.inst_profile_content != None and 'databases' in self.inst_profile_content:
            for db_profile in self.inst_profile_content['databases']:
                if 'hadrProfileName' in db_profile:
                    return True
        return False
    
    '''
    def getHADRManagerList(self):
        self.logger.debug("getHADRManagerList")
        from HADRManager import HADRManager
        hadr_manager_list = {}
        if self.inst_profile_content == {}:
            self.downloadProfile()
        for db_profile in self.inst_profile_content['databases']:
            self.logger.debug(db_profile)
            db_name = db_profile['databaseName'].upper()
            if 'hadrProfileName' in db_profile:
                hadr_manager = HADRManager(self.inst_name, db_name, db_profile['hadrProfileName'])
                hadr_manager_list[db_name] = hadr_manager
                self.logger.debug("%s does have hadr profile" % db_name)
                self.logger.debug("hadrProfileName: %s" % db_profile['hadrProfileName'])
            else:
                self.logger.debug("%s does not have hadr profile" % db_name)
        return hadr_manager_list
    '''
   
    def isOnline(self):
        db2instance_online = util.trace_shell_func_call('chk_if_instance_alive', self.inst_name)
        if db2instance_online == 0:
            return True
        else:
            return False

    def makeAllHADRDatabasesStandby(self, primary_db_name_list=None):
        self.logger.debug("makeAllHADRDatabasesStandby")
        if primary_db_name_list == None:
            primary_db_list = util.trace_shell_func_call_with_output('get_primary_db_list', self.inst_name)
            if len(primary_db_list.strip()) == 0:
                self.logger.debug("every db here is standby")
                return True
            else:
                if " " in primary_db_list.strip(): 
                    primary_db_name_list = primary_db_list.strip().split(" ")
                else:
                    primary_db_name_list = [primary_db_list.strip()]
        self.logger.debug(primary_db_name_list)
        hadr_manager_list = self.getHADRManagerList()
        for db_name in hadr_manager_list:
            self.logger.debug("hadr manager list contains db: %s" % db_name)
            if db_name in primary_db_name_list:
                hadr_manager = hadr_manager_list[db_name]
                result = hadr_manager.switchRole("STANDBY")
                if result :
                    self.logger.debug("makeAllHADRDatabasesStandby Successful.")
                    rc = 0
                    pass
                else:
                    self.logger.debug("makeAllHADRDatabasesStandby Failed.")
                    rc = 1
        if rc == 0:
            return True
        else:
            return False
    
    def makeAllHADRDatabasesPrimary(self, standby_db_name_list=None):
        self.logger.debug("makeAllHADRDatabasesPrimary")
        if standby_db_name_list == None:
            standby_db_list = util.trace_shell_func_call_with_output('get_standby_db_list', self.inst_name)
            self.logger.debug(standby_db_list)
            if len(standby_db_list.strip()) == 0:
                self.logger.debug("every db here is primary")
                self.logger.debug("makeAllHADRDatabasesPrimary successful")
                return True
            else:
                self.logger.debug("There are databases which are still in standby state")
                if " " in standby_db_list.strip(): 
                    standby_db_name_list = standby_db_list.strip().split(" ")
                else:
                    standby_db_name_list = [standby_db_list.strip()]
        self.logger.debug(standby_db_name_list)
        hadr_manager_list = self.getHADRManagerList()
        rc = 1
        for db_name in hadr_manager_list:
            if db_name in standby_db_name_list:
                hadr_manager = hadr_manager_list[db_name]
                self.logger.debug("Calling switchRole to change db: %s state from STANDBY to PRIMARY" % db_name)
                result = hadr_manager.switchRole("PRIMARY")
                if result == 0:
                    self.logger.debug("switchRole successful for database: %s to change state from STANDBY to PRIMARY" % db_name)
                    self.logger.debug("makeAllHADRDatabasesPrimary successful")
                    rc = 0
                    pass
                else:
                    self.logger.debug("switchRole failed for database: %s to change state from STANDBY to PRIMARY" % db_name)
                    self.logger.debug("makeAllHADRDatabasesPrimary failed")
                    rc = 1
        if rc == 0:
            return True
        else:
            return False
    
