#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#import maestro
import json
import os
import util
import random
#import commands

from DB2Group import DB2Group
from DB2User import DB2User
from ParallelSSH import ParallelSSH
import util
import common
from StorehouseUtil import StorehouseUtil

class UserGroupManager:
    def __init__(self, jsonFileName, logger, currentConsumer):
        #self.instanceName = instanceName
        #vmTemplateID = util.getRoleName()
        #self.jsonFileName = '%s_%s_instance_profile.json' % (vmTemplateID, self.instanceName)
        self.jsonFileName = jsonFileName
        self.PROFILE_LOCK = '%s.lck' % self.jsonFileName
        self.PROFILE_TIMEOUT = 1800  # 30min
        self.logger = logger
        self.currentConsumer = currentConsumer

        print('=========init dbaas_user_group_profile.json================')
        local_file_database_detail_path = "/dbaas/"
        self.profileName = os.path.join(local_file_database_detail_path, self.jsonFileName)
        self.remote_profile_url = self.profileName
        self.storehouseUtil = StorehouseUtil(self.profileName, self.remote_profile_url)
        '''if os.environ.has_key('DEPLOYMENT_URL'):
            self.storeHouseURL = os.environ['DEPLOYMENT_URL']

        self.remote_profile_url = self.storeHouseURL + '/instances' + '/' + self.jsonFileName
        self.storehouseUtil = StorehouseUtil(self.profileName, self.remote_profile_url)

        if self.storehouseUtil.exist():
            if self.downloadProfile():
                self.loadProfile()
            else:
                print("Error: fail to download instance profile because instance profile does not exist in storehouse.")
        else:
            print("Error: fail to initial instance profile because instance profile does not exist in storehouse.")
            print("Warning: instance profile does not exist in storehouse, will generate a new instance profile with users, groups and permission info.")
            self.create()
        ''' 
        self.create()
        self.servers = None

    @staticmethod
    def getInstance(jsonFileName, logger = None, currentConsumer = ''):
        UserGroupManager.__lock.acquire()
        if not UserGroupManager.__inst:
            UserGroupManager.__inst = object.__new__(UserGroupManager)
            UserGroupManager.__inst.__init__(jsonFileName, logger, currentConsumer)
        UserGroupManager.__lock.release()
        return UserGroupManager.__inst

    '''def getStoreHouseProfileURL(self):
        return self.storeHouseURL
    '''
    def getDirectory(self):
        return self.profile_content

    def getProfileName(self):
        return self.profileName

    def setProfileName(self, value):
        self.profileName = value

    def setServers(self, servers):
        self.servers = servers

#========manage the profile_content (create/load/download/upload/save)==========
    # Create a profile_content in the memory
    def create(self):
        self.profile_content = {
                        'users':{},
                        'groups':{},
                        'system_permission':{'SYSADM':'', 'SYSCTRL':'', 'SYSMAINT':'', 'SYSMON':''}
                        }
        self.users = self.profile_content['users']
        self.groups = self.profile_content['groups']

        # NOTE: Please be aware that the existing profile in storehouse will be overwritten if using the generate() function.
        self.storehouseUtil.generate(self.profile_content)

    # Load the profile_content content to memory from the local disk
    
    def loadProfile(self, reload = False):
        if reload:
            with open(self.profileName, 'r') as f:
                self.profile_content = json.load(f)

        if self.profile_content.has_key('users'):
            self.users = self.profile_content['users']
        else:
            self.profile_content['users'] = {}
            self.users = self.profile_content['users']

        if self.profile_content.has_key('groups'):
            self.groups = self.profile_content['groups']
        else:
            self.profile_content['groups'] = {}
            self.groups = self.profile_content['groups']

        if self.profile_content.has_key('system_permission'):
            self.system_permission = self.profile_content['system_permission']
        else:
            self.profile_content['system_permission'] = {'SYSADM':'', 'SYSCTRL':'', 'SYSMAINT':'', 'SYSMON':''}
            self.system_permission = self.profile_content['system_permission']

    # Download dbaas profile_content from storehouse
    '''
    def downloadProfile(self):
        self.profile_content = self.storehouseUtil.download()
        if self.profile_content == None:
            return False
        return True

    # Upload the profile_content to storehouse
    def uploadProfile(self):
        self.storehouseUtil.generate(self.profile_content)

    # Delete the profile_content from storehouse
    def deleteRemoteProfile(self):
        self.storehouseUtil.delete()

    # delete the profile_content from the local disk
    def deleteProfile(self):
        if os.path.exists(self.profileName):
            os.remove(self.profileName)
    '''
    def printProfile(self):
        print(json.dumps(self.getDirectory(), sort_keys = True, indent = 4))

#==================DB2Group management================
    def getGroups(self):
        return self.groups

    def setGroups(self, value):
        self.groups = value

    def getGroupByName(self, groupName):
        if groupName in self.groups:
            returnVal = DB2Group(groupName)
            if not 'accountType' in self.groups[groupName]:
                if self.getProperty('ldapStatus', 'disabled') == "disabled":
                    self.groups[groupName]['accountType'] = 'OS'
                else:
                    self.groups[groupName]['accountType'] = 'LDAP'

            returnVal.loadFromDict(self.groups[groupName])
            return returnVal
        else:
            return None

    def hasGroupOnMachine(self, groupname):
        #rc = util.trace_shell_func_call('chk_if_group_exist', groupname)
        rc, out, err = util.runShell('chk_if_group_exist %s' % groupname)
        if rc == 0:
            return True
        else:
            return False

    # add the group into the OS and profile, or add LDAP group into profile
    def addGroup(self, new_group, fencedUserGroupID, sysMonGroupID, instanceOwnerGroupID, sysControlGroupID, sysMaintGroupID, fencedUserGroup, sysControlGroupName, sysMonGroupName, sysMaintGroupName):
        #========COde changes for RFE 92204==============
        #parms = maestro.parms
        #========COde changes for RFE 92204 ends==============
        print('group account type is %s' % new_group.getAccountType())

        # check whether group exists in the profile
        if new_group.getGroupName() in self.groups:
            print('the group existed in the profile')
            existing_group = self.getGroupByName(new_group.getGroupName())
            if existing_group.hasConsumer(self.currentConsumer):
                print(new_group)
                rc = False
                message = 'Error: Group %s already exits in %s!' % (new_group.getGroupName(), self.currentConsumer)
            else:
                existing_group.addConsumer(self.currentConsumer)
                rc = True
                message = 'Group %s already exits in OS, will be added to %s!' % (new_group.getGroupName(), self.currentConsumer)
                new_group = existing_group
        else:
            print('Begin to add %s in %s' % (new_group.getGroupName(), new_group.getAccountType()))
            if new_group.getAccountType() == 'LDAP':
                if not self.hasGroupOnMachine(new_group.getGroupName()):
                    rc = False
                    message = 'Error: group %s does not exist in the LDAP server!' % (new_group.getGroupName())
                else:
                    rc = True
                    message = 'Group %s already exits in LDAP server, will be added to %s!' % (new_group.getGroupName(), self.currentConsumer)
            else:  # OS group
                if not self.hasGroupOnMachine(new_group.getGroupName()):
                    print('Create new OS group')
                    
                    #============Code added for RFE 92204=================
                    
                    try:
                        if fencedUserGroup and new_group.getGroupName() == fencedUserGroup:
                            print('This is fencedGroup creation request and value is fencedUserGroup: %s' % fencedUserGroup)
                            if fencedUserGroupID:
                                print('Parm fencedUserGroupID id exists and its value is: %s' % fencedUserGroupID)
                                if int(fencedUserGroupID) >= 500 and (self.isFencedGroupvalid(instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID)):
                                    print('Parm user id exists and its value is >= 500 and not same as instanceOwnerGroupID value of fencedUserGroupID is: %s' % fencedUserGroupID)
                                                                                                                   
                                    new_group.setGroupId(fencedUserGroupID)
                                else:
                                                                                                                                                                                                      
                                                                                                                  
                                    new_group.setGroupId(self.generateUID()) 
                            else:   
                                  print('Parm fencedUserGroupID does not exists')
                                  new_group.setGroupId(self.generateUID())
                           
                         #============Code added for RFE 128497 starts=================   
                        elif sysControlGroupName and ((new_group.getGroupName() == sysControlGroupName)):
                            print('This is sysControlGroupName creation request and value is sysControlGroupName: %s' % sysControlGroupName)
                            if sysControlGroupID:
                                print('Parm sysControlGroupID id exists and its value is: %s' % sysControlGroupID)
                                if int(sysControlGroupID) >= 500 and (self.isSysctrlGroupvalid(instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID)):
                                    print('Parm user id exists and its value is >= 500 : %s' % sysControlGroupID)
                                    new_group.setGroupId(sysControlGroupID)
                                else:
                                    new_group.setGroupId(self.generateGID()) 
                            else:   
                                  print('Parm sysControlGroupID does not exists')
                                  new_group.setGroupId(self.generateGID())
                           
                        elif sysMaintGroupName and ((new_group.getGroupName() == sysMaintGroupName)):
                            print('This is sysMaintGroupName creation request and value is sysMaintGroupName: %s' % sysMaintGroupName)
                            if sysMaintGroupID:
                                print('Parm sysMaintGroupID id exists and its value is: %s' % sysMaintGroupID)
                                if int(sysMaintGroupID) >= 500 and (self.isSysmaintGroupvalid(instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID)):
                                    print('Parm user id exists and its value is >= 500 : %s' % sysMaintGroupID)
                                    new_group.setGroupId(sysMaintGroupID)
                                else:
                                    new_group.setGroupId(self.generateGID()) 
                            else:   
                                print('Parm sysMaintGroupID does not exists')
                                new_group.setGroupId(self.generateGID())
                           
                        elif sysMonGroupName and ((new_group.getGroupName() == sysMonGroupName)):
                            print('This is sysMonGroupName creation request and value is sysMonGroupName: %s' % sysMonGroupName)
                            if sysMonGroupID:
                                print('Parm sysMonGroupID id exists and its value is: %s' % sysMonGroupID)
                                if int(sysMonGroupID) >= 500 and (self.isSysmonGroupvalid(fencedUserGroupID, sysMonGroupID, instanceOwnerGroupID, sysControlGroupID, sysMaintGroupID)):
                                    print('Parm user id exists and its value is >= 500 : %s' % sysMonGroupID)
                                    new_group.setGroupId(sysMonGroupID)
                                else:
                                    new_group.setGroupId(self.generateGID()) 
                            else:   
                                print('Parm sysMonGroupID does not exists')
                                new_group.setGroupId(self.generateGID())
                        else:
                              print('if different group comes')
                              new_group.setGroupId(self.generateGID())          
                                     
                    except:    
                          print('Handling exception, creating group with automated ID')
                          new_group.setGroupId(self.generateGID())  
                    
                    #============Code added for RFE 92204 ends================= 
                    
                    # create new group
                    rc, message = self.executeCmd(new_group.addGroup())
                else:
                    print('add the group id')
                    new_group.setGroupId(self.getGIDFromOS(new_group.getGroupName()))
                    rc = True
                    message = 'Group %s already exits in OS, will be added to %s!' % (new_group.getGroupName(), self.currentConsumer)
                if rc:
                    new_group.addConsumer(self.currentConsumer)
        # store the group in the profile
        if rc:
            self.groups[new_group.getGroupName()] = new_group.getDirectory()
            print(self.groups[new_group.getGroupName()])
            #self.uploadProfile()
        
        self.logger.info('add group %s in %s, result is %s, message is %s' % (new_group.getGroupName(), self.currentConsumer, rc, message))
        return rc, message
    
    def isFencedGroupvalid(self, instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID):
        #parms = maestro.parms
        self.logger.info("Inside isFencedGroupvalid...")
        fencedvalidflag=True
        if instanceOwnerGroupID :
            if(fencedUserGroupID != instanceOwnerGroupID):
               fencedvalidflag=True
            else:
                return False
        if sysControlGroupID:
            if(fencedUserGroupID != sysControlGroupID):
               fencedvalidflag=True
            else:
                return False  
        if sysMaintGroupID:
            if(fencedUserGroupID != sysMaintGroupID):
               fencedvalidflag=True
            else:
                return False 
        if sysMonGroupID:
            if(fencedUserGroupID != sysMonGroupID):
               fencedvalidflag=True
            else:
                return False      
        return fencedvalidflag
    
    def isInstanceGroupvalid(self, instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID):
        #parms = maestro.parms
        self.logger.info("Inside isInstanceGroupvalid")
        instancevalidflag=True
        if fencedUserGroupID:
            if(instanceOwnerGroupID != fencedUserGroup):
               instancevalidflag=True
            else:   
                return False
        if sysControlGroupID:
            if(instanceOwnerGroupID !=sysControlGroupID):
               instancevalidflag=True
            else:   
                return False  
        if sysMaintGroupID:
            if(instanceOwnerGroupID != sysMaintGroupID):
               instancevalidflag=True
            else:   
                return False 
        if sysMonGroupID:
            if(instanceOwnerGroupID != sysMonGroupID):
               instancevalidflag=True
            else:  
                return False      
        return instancevalidflag
    
    def isSysctrlGroupvalid(self, instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID):
        parms = maestro.parms
        self.logger.info("Inside isSysctrlGroupvalid")
        sysctrlvalidflag=True
        if fencedUserGroupID:
            if(sysControlGroupID != fencedUserGroupID):
               sysctrlvalidflag=True
            else:   
               return False
        if instanceOwnerGroupID:
            if(sysControlGroupID != instanceOwnerGroupID):
               sysctrlvalidflag=True
            else:   
                return False  
        if sysMaintGroupID:
            if(sysControlGroupID != sysMaintGroupID):
               sysctrlvalidflag=True
            else:   
                return False 
        if sysMonGroupID:
            if(sysControlGroupID != sysMonGroupID):
               sysctrlvalidflag=True
            else:  
                return False      
        return sysctrlvalidflag
    
    def isSysmaintGroupvalid(self, instanceOwnerGroupID, fencedUserGroupID, sysControlGroupID, sysMaintGroupID, sysMonGroupID):
        #parms = maestro.parms
        self.logger.info("Inside isSysmaintGroupvalid")
        sysmaintvalidflag=True
        if fencedUserGroupID:
            if(sysMaintGroupID != fencedUserGroupID):
               sysmaintvalidflag=True
            else:   
               return False
        if instanceOwnerGroupID:
            if(sysMaintGroupID != instanceOwnerGroupID):
               sysmaintvalidflag=True
            else:   
                return False  
        if sysControlGroupID:
            if(sysMaintGroupID != sysControlGroupID):
               sysmaintvalidflag=True
            else:   
                return False 
        if sysMonGroupID:
            if(sysMaintGroupID != sysMonGroupID):
               sysmaintvalidflag=True
            else:  
                return False      
        return sysmaintvalidflag
    
    def isSysmonGroupvalid(self, fencedUserGroupID, sysMonGroupID, instanceOwnerGroupID, sysControlGroupID, sysMaintGroupID):
        #parms = maestro.parms
        self.logger.info("Inside isSysmonGroupvalid")
        sysmonvalidflag=True
        if fencedUserGroupID:
            if(sysMonGroupID != fencedUserGroupID):
               sysmaintvalidflag=True
            else:   
               return False
        if instanceOwnerGroupID:
            if(sysMonGroupID != instanceOwnerGroupID):
               sysmaintvalidflag=True
            else:   
                return False  
        if sysControlGroupID:
            if(sysMonGroupID != sysControlGroupID):
               sysmaintvalidflag=True
            else:   
                return False 
        if sysMaintGroupID:
            if(sysMonGroupID != sysMaintGroupID):
               sysmaintvalidflag=True
            else:  
                return False      
        return sysmaintvalidflag

    #remove the group from the consumer( database or instance)
    
    def removeGroup(self, groupName):
        if self.groups.has_key(groupName):
            existing_group = self.groups[groupName]

            if existing_group.removeConsumer(self.currentConsumer):
                if len(existing_group.getconsumers()) == 0:
                    rc, message = self.executeCmd(existing_group.delGroup())
                    if rc:
                        self.groups.remove(groupName)
                        #remove the group from the user profile
                        for item in self.users:
                            curGroup = self.users[item]['groups']
                            if groupName in curGroup:
                                curGroup.remove(groupName)
                else:
                    rc = True
                    print(existing_group)
                    message = 'Deleted group %s from %s!' % (groupName, self.currentConsumer)
            else:
                rc = False
                message = 'Error: Group %s does not exist in %s!' % (groupName, self.currentConsumer)
        else:
            rc = False
            message = 'Error: Group %s does not exist!' % (groupName)

        '''
        if rc:
            self.uploadProfile()
        '''
        self.logger.info('remove group %s from %s, result is %s, message is %s' % (groupName, self.currentConsumer, rc, message))
        return rc, message

    def removeGroups(self):
        for groupName in self.groups:
            self.removeGroupByName(groupName, self.currentConsumer)

    def updateGroup(self, group):
        if self.groups.has_key(group.getGroupName()):
            self.groups[group.getGroupName()] = group.getDirectory()
            self.uploadProfile()
            return True
        else:
            return False

    def getGIDFromOS(self, groupName):
        #return util.trace_shell_func_call_with_output("get_gid", groupName)
        rc, out, err=util.runShell("get_gid %s" % groupName)
        return out.strip()

    def generateGID(self):
        rc, out, err=util.runShell("generate_gid")
        return out.strip()
        #return util.trace_shell_func_call_with_output("generate_gid")

    def getGroupsByConsumer(self, consumer):
        groups_for_consumer = {}
        for curr_group_profile in self.groups:
            cur_group = DB2Group()
            cur_group.loadFromDict(curr_group_profile)
            if cur_group.hasConsumer(consumer):
                groups_for_consumer[cur_group.getUserName()] = cur_group

        return groups_for_consumer

#==================DB2User management================
    def getUsers(self):
        return self.users

    def getUserByName(self, userName):
        currUser = DB2User(userName)
        if userName in self.users:
            if not self.users[userName].has_key('accountType'):
                if self.getProperty('ldapStatus', 'disabled') == "disabled":
                    self.users[userName]['accountType'] = 'OS'
                else:
                    self.users[userName]['accountType'] = 'LDAP'

            currUser.loadFromDict(self.users[userName])
            return currUser
        else:
            return None

    def addUser(self, new_user, instanceOwnerUID, fencedUserID, dbuserid):
        #========COde changes for RFE 92204==============
        #parms = maestro.parms
        #========COde changes for RFE 92204 ends==============
        print('user account type is %s' % new_user.getAccountType())
        # For IPAS will allow db default owner same as instance user.
        # check whether user exists in the profile
        print('$$$$$$$$$$$$$$$$$new_user, instanceOwnerUID, fencedUserID, dbuserid$$$$ %s $$$$$ %s $$$$ %s $$$  %s' % (new_user, instanceOwnerUID, fencedUserID, dbuserid))
        skip=True
        if not skip:
        #if self.users.has_key(new_user.getUserName()):
            rc = True
            print('the user existed in the profile')
            existing_user = self.getUserByName(new_user.getUserName())
            if existing_user.hasConsumer(self.currentConsumer):
                print(existing_user)
                message = 'Error: User %s already exits in %s!' % (existing_user.getUserName(), self.currentConsumer)
                rc = False
            else:
                message = 'User %s already exits in OS, will be added to %s!' % (existing_user.getUserName(), self.currentConsumer)
                print(message)
                if len(new_user.getGroups()) > 0:
                    print('add user to new group')
                    rc, message = self.executeCmd(existing_user.appendToGroups(new_user.getGroups()))
                    print('appendToGroups result is: rc=%s, message=%s' % (rc, message))

                existing_user.addConsumer(self.currentConsumer)

            # set the user's ssh (LDAP or OS user) 
            if rc and existing_user.getSshAllow() != new_user.getSshAllow():
                print('Set the ssh for the user %s, enable ssh is %s' % (new_user.getUserName(), new_user.getSshAllow()))
                if new_user.getSshAllow():
                    rc, message = self.executeCmd(new_user.enableSSH())
                else:
                    rc, message = self.executeCmd(new_user.disableSSH())

            new_user = existing_user
        else:
            print('Begin to add %s in %s' % (new_user.getUserName(), new_user.getAccountType()))
            if new_user.getAccountType() == 'LDAP': #LADP user
                if not self.hasUserOnMachine(new_user.getUserName()):
                    rc = False
                    message = 'Error: user %s does not exist in the LDAP server!' % (new_user.getUserName())
                else:
                    message = 'User %s already exits in LDAP server, will be added to %s!' % (new_user.getUserName(), self.currentConsumer)
            else:  # OS user
                if not self.hasUserOnMachine(new_user.getUserName()):
                    print('create new OS user %s' % new_user.getUserName())
                    print('create new OS user')
                    #========COde changes for RFE 92204==============
                    # Based on the description field, check which type adduser request
                    # if description="DB2 fence user" its a fence user
                    # if description="DB2 instance user" it is instance user
                    # if description="default database owner" it is database user
                    
                    try:
                       print('User Description is : %s' % new_user.getDescription())
                       print('User Description is : %s' % new_user.getDescription())
                    
                       if new_user.getDescription() == "DB2 fence user":
                          if fencedUserID and fencedUserID!="":
                             print('Parm fenced user id exists and its value is: %s' % fencedUserID)
                             print('Parm fenced user id exists and its value is: %s' % fencedUserID)
                             if int(fencedUserID) >= 500 and int(fencedUserID) != int(instanceOwnerUID):
                                print('Parm fencedUserID exists and its value is >= 500 and not same as instanceOwnerUID value of fencedUserID is: %s' % fencedUserID)
                                print('instanceOwnerUID: %s' % instanceOwnerUID)  
                                new_user.setUserId(int(fencedUserID))
                             else:
                                print('Automatically generating fencedUserID as Parm fencedUserID exists and either its value is < 500 OR is same as instanceOwnerUID, value of fencedUserID is: %s' % fencedUserID)
                                print('instanceOwnerUID: %s' % instanceOwnerUID)
                                new_user.setUserId(self.generateUID()) 
                          else:   
                              print('Parm fencedUserID does not exists, so automatically generating ID')
                              new_user.setUserId(self.generateUID())
                       elif new_user.getDescription() == "default database owner":
                          if dbuserid and dbuserid != "":
                             print('Parm dbuserid exists and its value is: %s' % dbuserid)
                             if int(dbuserid) >= 500 and int(dbuserid) != instanceOwnerUID and int(dbuserid) != fencedUserID:
                                print('Parm dbuserid exists and its value is >= 500 and not same as instanceOwnerUID and  fencedUserID, value of dbuserid is: %s' % dbuserid)
                                print('instanceOwnerUID: %s' % instanceOwnerUID)  
                                print('fencedUserID: %s' % fencedUserID)
                                new_user.setUserId(int(dbuserid))
                             else:
                                print('Automatically generating dbuserid as Parm dbuserid exists and either its value is < 500 OR is same as instanceOwnerUID or fencedUserID , value of dbuserid is: %s' % dbuserid)
                                print('instanceOwnerUID: %s' % instanceOwnerUID)
                                print('fencedUserID: %s' % fencedUserID)
                                new_user.setUserId(int(self.generateUID())) 
                          else:   
                              print('Parm dbuserid does not exists, so automatically generating ID')
                              new_user.setUserId(self.generateUID())
                       else:
                             print("Description is neither DB2 fenced user nor default database owner. In this case generate UID automatically")
                             #new_user.setUserId(self.generateUID())     
                             new_user.setUserId(502)     
                    except:
                          print('Handling exception, creating user with automated ID')
                          new_user.setUserId(self.generateUID())
                    #new_user.setUserId(self.generateUID())
                    #========COde changes for RFE 92204 ends==============
                    
                    #rc, message = self.executeCmd(new_user.addUser(), echo_stdin = False)
                    rc = new_user.addUser()
                    #print('addUser result is: rc=%s, message=%s' % (rc, message))
                    print('addUser result is: rc=%s' % (rc))
                else:
                    # For an exist local OS user
                    print('Verify the password for user %s' % new_user.getUserName())

                    rc, message = self.verifyPasswd(new_user.getUserName(), new_user.getPassword())
                    print('verify password result is rc=%s message=%s' % (rc, message))

                    # Get the user id from the OS
                    new_user.setUserId(self.getUIDFromOS(new_user.getUserName()))

                    #add user to new groups
                    if rc and len(new_user.getGroups()) > 0:
                        print('add user to new group')
                        rc, message = self.executeCmd(new_user.appendToGroups(new_user.getGroups()))
                        print('appendToGroups result is: rc=%s, message=%s' % (rc, message))

                # set the user's ssh (LDAP or OS user) 
                print('Set the ssh for the user %s, ssh enabled is %s' % (new_user.getUserName(), new_user.getSshAllow()))
                if new_user.getSshAllow():
                    rc, message = self.executeCmd(new_user.enableSSH())
                else:
                    rc, message = self.executeCmd(new_user.disableSSH())

                print('enable/disable result is: rc=%s, message=%s' % (rc, message))

                # set user's consume with current instance or database
                new_user.addConsumer(self.currentConsumer)

        # store the user in the profile
        if rc:
            print('store the profile: start')
            self.users[new_user.getUserName()] = new_user.getDirectory()
            print(self.users[new_user.getUserName()])
            #self.uploadProfile()
            print('store the profile: end')
        
        self.logger.info('add user %s in %s, result is %s, message is %s' % (new_user.getUserName(), self.currentConsumer, rc, message))
        return rc, message

    def removeUser(self, userName):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)

            if existing_user.removeConsumer(self.currentConsumer):
                if len(existing_user.getconsumers()) == 0:
                    message = 'Deleted user %s from %s!' % (userName, self.currentConsumer)
                    rc, message = self.executeCmd(existing_user.delUser())
                    print('rc = %s, message = %s' % (rc, message))
                    if rc:
                        del self.users[userName]
                else:
                    print(existing_user)
                    rc = True
                    message = 'Deleted user %s from %s!' % (userName, self.currentConsumer)
            else:
                rc = False
                message = 'Error: user %s does not exist in %s!' % (userName, self.currentConsumer)
        else:
                rc = False
                message = 'Error: user %s does not exist!' % (userName)

        '''
        if rc:
            self.uploadProfile()
        '''
        self.logger.info('remove user %s from %s, result is %s, message is %s' % (userName, self.currentConsumer, rc, message))
        return rc, message

    def removeUsers(self):
        for userName in self.users:
            self.removeUserByName(userName, self.currentConsumer)

    def appendUserGroupMembership(self, userName, groupList):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)
            rc, message = self.executeCmd(existing_user.appendToGroups(groupList))
            if rc:
                self.users[userName]['groups'] = existing_user.getDirectory()['groups']
                #self.uploadProfile()
        else:
            rc = False
            message = 'Error: User %s does not exist!' % (userName)
            print(message)

        return rc, message

    def removeUserGroupMembership(self, userName, groupList):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)
            rc, message = self.executeCmd(existing_user.removeFromGroups(groupList))

            if rc:
                self.users[userName]['groups'] = existing_user.getDirectory()['groups']
                #self.uploadProfile()
        else:
            rc = False
            message = 'Error: User %s does not exist!' % (userName)
            print(message)

        return rc, message

    def updateUserGroupMembership(self, userName, groupList):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)
            rc, message = self.executeCmd(existing_user.changeGroups(groupList))
            if rc:
                self.users[existing_user.getUserName()]['groups'] = existing_user.getDirectory()['groups']
                print(existing_user)
                #self.uploadProfile()
        else:
            rc = False
            message = 'Error: User %s does not exist!' % (existing_user.getUserName())
            print(message)

        return rc, message

    def updateSSHAccess(self, userName, ssh_access):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)

            if ssh_access:
                rc, message = self.executeCmd(existing_user.enableSSH())
            else:
                rc, message = self.executeCmd(existing_user.disableSSH())

            if rc:
                self.users[existing_user.getUserName()]['sshAccess'] = existing_user.getSshAllow()
                print(existing_user)
                self.uploadProfile()
            else:
                print('Fail to update the ssh access!')
        else:
            rc = False
            message = 'Error: User %s does not exist!' % (userName)
            print(message)
        return rc, message

    def resetUserPassword(self, userName, newPassword):
        if self.users.has_key(userName):
            existing_user = self.getUserByName(userName)
            rc, message = self.executeCmd(existing_user.resetPassword(newPassword), echo_stdin = False)
            if rc:
                self.users[existing_user.getUserName()]['password'] = newPassword
                #self.users[existing_user.getUserName()]['password'] = maestro.encode(newPassword)
                #self.uploadProfile()
        else:
            rc = False
            message = 'Error: User %s does not exist!' % (userName)
            print(message)

        return rc, message

    def updateUser(self, user):
        if self.users.has_key(user.getUserName()):
            self.users[user.getUserName()] = user.getDirectory()
            #self.uploadProfile()
            return True
        else:
            return False

    def generateUID(self):
        #return util.trace_shell_func_call_with_output("generate_uid")
        rc, out = common.generate_uid()
        print("generateUID &&&&&&&&&& %s" % str(out))
        return out.strip()

    def getUIDFromOS(self, userName):
        rc, out, err = util.runShell('get_uid %s' % userName)
        return out.strip()
        #return util.trace_shell_func_call_with_output("get_uid", userName)

    def getUserGID(self, userName):
        rc, out, err = util.runShell('get_user_gid %s' % userName)
        return out.strip()
        #return util.trace_shell_func_call_with_output("get_user_gid", userName)

    # Checks to see if user already exists.
    def hasUserOnMachine(self, username):
        #rc = util.trace_shell_func_call('chk_if_user_exist', username)
        rc, out, err = util.runShell('chk_if_user_exist %s' % username)
        if rc == 0:
            return True
        else:
            return False

    #======================Clone user & groups==================================
#     /**
#     * Generates a random password that contains at least one number, at least one lower-case
#     * letter, and at least one upper-case letter. The minimum length is 8 characters, and the
#     * maximum length is 64 characters.
#     * 
#     * @return a randomly generated password
#     */
    @staticmethod
    def generateRandomPassword():
        symbols0 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
        symbols1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        symbols2 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

        length0 = 2 + random.randint(0, 5)
        length1 = 4 + random.randint(0, 5)
        length2 = 4 + random.randint(0, 5)
        bufferStr = []

        # Add some numeric chars
        for idx in range(0, length0):
            ind = random.randint(0, 9)
            bufferStr.extend(symbols0[ind])

        # Add lower case chars   
        for idx in range(0, length1):
            bufferStr.extend(symbols1[random.randint(0, 25)])

        # Add upper case chars
        for idx in range(0, length2):
            bufferStr.extend(symbols2[random.randint(0, 25)])

        # Shuffle the characters a bit
        for i in [len(bufferStr) - 1, 0]:
            index = random.randint(0, i);
            temp = bufferStr[i];
            bufferStr[i] = bufferStr[index];
            bufferStr[index] = temp;

        return ''.join(bufferStr)

    def verifyPasswd(self, userName, password):
        shellPath = os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell')
        shellFile = os.path.join(shellPath, 'exp_checkpasswd.sh')
        chglc = 'export LC_ALL=C;'
        commandStr = '%s%s %s %s' % (chglc, shellFile, userName, password)
        #status, text = commands.getstatusoutput(commandStr)
        rc, text, err=util.runShell(commandStr)
        #exit_code = status >> 8  # high byte
        exit_code = rc >> 8  # high byte

        if exit_code == 0:
            return True, 'The user name and password are correct'
        elif exit_code == 1:
            return False, 'The password is wrong %s' % text
        elif exit_code == 2:
            return False, 'The user name does not exist %s' % text
        else:
            return False, 'The user name or password has problem %s' % text

    def getUsersByConsumer(self, consumer):
        users_for_consumer = {}
        for curr_user_profile in self.users:
            curr_user = DB2User()
            curr_user.loadFromDict(curr_user_profile)
            if curr_user.hasConsumer(consumer):
                users_for_consumer[curr_user.getUserName()] = curr_user

        return users_for_consumer
    
    def getPermissionGroupName(self, permissionKey):
        groupName = ''
        if permissionKey in self.system_permission:
            groupName =  self.system_permission.get(permissionKey)
        return groupName

#======================Execute the Shell command============================
    def executeCmd(self, commandStr, **kwargs):
        if commandStr != None and commandStr:
            if self.servers:
                sshShell = ParallelSSH(self.servers, self.logger)
                return sshShell.ssh("func_agent.sh " + commandStr, **kwargs)
            else:
                rc, message = util.trace_stderr_call(commandStr, **kwargs)
                if rc == 0:
                    return True, message
                else:
                    return False, message
        else:
            return False, 'Error! The command is empty.'

    def executeCmdForSpecialServers(self, serverList, commandStr, **kwargs):
        if commandStr != None and commandStr:
            sshShell = ParallelSSH(serverList, self.logger)
            return sshShell.ssh("func_agent.sh " + commandStr, **kwargs)
        else:
            return False, 'Error! The command is empty.'
