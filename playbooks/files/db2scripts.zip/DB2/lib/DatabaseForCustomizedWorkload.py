#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import maestro
import os
import shutil
import urlparse
import util

from DatabaseForSystemWorkload import \
    DatabaseForSystemWorkload, InstallationException

class DatabaseForCustomizedWorkload(DatabaseForSystemWorkload):
    def __init__(self, inst_name, db_name, logger = None):
        DatabaseForSystemWorkload.__init__(self, inst_name, db_name, logger)
        self.install_start_msg = "DBAAS_PROVISION_WORKLOAD_CUSTOMIZED_START" # workload name

    #Prepare workload standard  and Tune OS
    @util.performance_profile_trace
    def preCreateDatabase(self):
        self.source = 'workloadStandardApproach'
        deploy_url = maestro.node['deployment.url']  # 'https://172.16.65.117:9444/storehouse/user/deployments/d-6326b22b-0706-4b88-9966-6e0f97ad2f0f'
        deploy_urls = urlparse.urlparse(deploy_url)
        
        sh_url = '%s://%s/storehouse' % (deploy_urls[0], deploy_urls[1])
        if self.workload_name.endswith(".zip"):
            self.current_workload_path = os.path.basename(self.workload_name)[0:-4]  # remove .zip from the file name
            workload_exec_url = '%s/user/dbworkloads/%s' % (sh_url, self.workload_name)
        else:
            workload_meta_url = '%s/user/dbworkloads/%s/%s.json' % (sh_url, self.workload_name, self.workload_name)
            tmpdir = '/dbaas'
            workload_meta_json = util.read_Json_FromStoreHouse(workload_meta_url, tmpdir)
            workload_exec_url = '%s/user/dbworkloads/%s/artifact/%s' % (sh_url, workload_meta_json['id'], workload_meta_json['workload_file'])
            self.current_workload_path = workload_meta_json['workload_file'][:-4]

        self.workload_exec_dir = os.path.join(self.dbaasdir, 'workloads', self.db_name)
        if not os.path.exists(self.workload_exec_dir):
            os.makedirs(self.workload_exec_dir)

        self.logger.debug('Workload type: custom workload standard')

        self.logger.debug('Workload executable URL %s, local dir %s' % (workload_exec_url, self.workload_exec_dir))

        # Download and unpack workload exec
        maestro.downloadx(workload_exec_url, self.workload_exec_dir)

        create_db_script = os.path.join(self.workload_exec_dir, 'create_db', 'create_db.sh')
        if not os.path.exists(create_db_script):
            raise InstallationException('Failed to find the create_db.sh under create_db directory in the zip file')

        # Change permission for workload dir
        if self.workload_exec_dir:
            util.trace_shell_func_call('fix_workload', self.workload_exec_dir)

        self.source = 'workloadStandardApproach'

        # the default user name and password
        self.defaultUser = ''
        if 'customizedDatabaseUser' in self.db_parms:
            self.defaultUser = self.db_parms['customizedDatabaseUser']
        self.defaultUser_password = ''
        if 'customizedDatabaseUserPassword' in self.db_parms:
            self.defaultUser_password = maestro.decode(self.db_parms['customizedDatabaseUserPassword'])

    #  cleanup the tempory files in the prepare phase
    @util.performance_profile_trace
    def cleanupTemporaryFiles(self):
        if self.workload_exec_dir and self.workload_exec_dir != "":
            shutil.rmtree(self.workload_exec_dir + "/")
