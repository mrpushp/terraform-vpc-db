#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import sys
import os
import maestro
import logging
import json
import util
import traceback
from ParallelSSH import ParallelSSH

scriptdir = maestro.node['scriptdir']
libdir = os.path.join(maestro.node['scriptdir'], 'DB2', 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
from HADRProfile import HADRProfile
from SSHManager import SSHManager
from StorehouseUtil import StorehouseUtil
from DB2_Instance import DB2_Instance
from DatabaseForSystemWorkload import DatabaseForSystemWorkload
from DB2_Instance import DB2_Instance

class HADRManager(object):

    HADR_PORT = 55555
    GSPort = 12348
    TSPort = 12347
    RMCPort = 657
    SSHPort = 22
    SCSIPort = 3260

    def __init__(self, inst_name, db_name, hadrProfileName, logger=None):
        if logger is None:
            self.logger = logging.getLogger('HADRManager.py')
        else:
            self.logger = logger
        self.shellDir = os.path.join(scriptdir, 'DB2', 'shell')
        self.func_agent_sh = os.path.join(self.shellDir, 'func_agent.sh')
        self.inst_name = inst_name
        self.db_name = db_name
        self.hadrProfileName = hadrProfileName
        self.hadrProfile = HADRProfile(self.hadrProfileName)
        self.inst_agent = DB2_Instance(self.inst_name)
        self.instanceProfile = self.inst_agent.getInstanceProfile()
        self.database_agent = DatabaseForSystemWorkload(self.inst_name, self.db_name)
               
    def getValueFromParms(self, key, parms):
        return parms[key] if (parms is not None and key in parms) \
            else (maestro.parms[key] if key in maestro.parms else None)

    def __initHADRRole(self, renew=False):
        if renew or self.hadrProfile.primaryNode == None or self.hadrProfile.standbyNode == None:
            self.hadrProfile.getHADRNodeInfo()

    def isPrimary(self, renew=False):
        self.__initHADRRole(renew)
        if self.hadrProfile.primaryNode.publicIP == maestro.node['instance']['public-ip']:
            return True
        else:
            return False

    def createHADRProfile(self, parms):
        self.logger.debug('Start to upload hadr_profile.json')
        if not self.hadrProfile.generate(parms):
            raise Exception('Failed to create new HADR profile in Store House!')

    def updateDBProfileForHADR(self):
        if 'databases' in self.instanceProfile:
            for database_profile in self.instanceProfile['databases']:
                if database_profile['databaseName'] == self.db_name:
                    database_profile['hadrProfileName'] = self.hadrProfileName
                    break
        self.inst_agent.uploadProfile()

    @util.performance_profile_trace
    def openPortForHADR(self, portList=None):
        #open icmp to allow ping
        maestro.firewall.open_in(protocol="icmp")
        maestro.firewall.open_out(protocol="icmp")
        if portList is None:
            return
        for port in portList:
            maestro.firewall.open_tcpin(network='public', dport=port)
            maestro.firewall.open_tcpout(network='public', dport=port)
            maestro.firewall.open_tcpin(network='private', dport=port)
            maestro.firewall.open_tcpout(network='private', dport=port)
        udpList = [self.GSPort, self.TSPort, self.RMCPort]
        for port in udpList:
            if port in portList:
                maestro.firewall.open_in(protocol='udp', dport=port, network='public')
                maestro.firewall.open_out(protocol='udp', dport=port, network='public')
                maestro.firewall.open_in(protocol='udp', dport=port, network='private')
                maestro.firewall.open_out(protocol='udp', dport=port, network='private')

    def initInstanceProfile(self):
        if self.instanceProfile is None:
            vmTemplateID = maestro.node['id'][:maestro.node['id'].rindex('.')]
            jsonFileName = '%s_%s_instance_profile.json' % (vmTemplateID, self.inst_name)
            instanceProfileURL = os.path.join(maestro.node['deployment.url'], 'instances', jsonFileName)
            instanceProfileLocal = os.path.join(HADRProfile.DBAAS_TEMP_DIR, jsonFileName)
            self.instProSHUtil = StorehouseUtil(instanceProfileLocal, instanceProfileURL)
            self.instanceProfile = self.instProSHUtil.downloadWithoutTrace()

    def overwriteInstanceProfile(self):
        if self.instanceProfile is not None:
            self.instProSHUtil.generate(self.instanceProfile)

    def checkTSMConfigured(self):
        if self.instanceProfile is None:
            self.initInstanceProfile()
        self.isTSMConfigured = self.instanceProfile.has_key('isTSMEnabled') and self.instanceProfile['isTSMEnabled']

    def getPortList(self, hadrPort1, hadrPort2):
        if self.instanceProfile is None:
            self.initInstanceProfile()
        allPortList = [hadrPort1, hadrPort2, HADRManager.GSPort, \
                       HADRManager.TSPort, HADRManager.RMCPort, \
                       HADRManager.SSHPort, HADRManager.SCSIPort]
        if 'portList' in self.instanceProfile:
            portList = [port for port in list(set(allPortList) - set(self.instanceProfile['portList']))]
            self.instanceProfile['portList'].extend(portList)
        else:
            portList = allPortList
            self.instanceProfile['portList'] = allPortList
        self.inst_agent.uploadProfile()
        return portList

    @util.performance_profile_trace
    def initSSHForPrimary(self):
        self.logger.debug('initSSHForPrimary begin')
        sshManager = SSHManager('_'.join(['ssh', self.hadrProfile.standbyNode.publicIP, \
                                          self.hadrProfile.standbyNode.instanceName, self.db_name, 'key.json']))
        userList = [('root', 'root'), (self.inst_name, self.hadrProfile.primaryNode.instanceOwnerGroup)]
        sshManager.setupForPrimary(userList=userList)
        self.logger.debug('initSSHForPrimary end')

    @util.performance_profile_trace
    def initSSHForStandby(self, parms):
        self.logger.debug('initSSHForStandby begin')
        fileName = '_'.join(['ssh', maestro.node['instance']['public-ip'], self.inst_name, self.db_name, 'key.json'])
        sshManager = SSHManager(fileName)
        userList = [('root', 'root'), (self.inst_name, self.getValueFromParms('instanceOwnerGroup', parms))]
        sshManager.setupForStandBy(userList=userList)
        self.logger.debug('initSSHForStandby end')

    @util.performance_profile_trace
    def configureTSMProxy(self, as_node_name, hadrRole):
        self.logger.debug('Start to configure TSM proxy node.')
        try:
            if self.inst_agent.isTSMConfigured() and 'tsm' in self.instanceProfile:
                adminusername = self.instanceProfile['tsm']['adminusername']
                adminpassword = maestro.decode(self.instanceProfile['tsm']['adminpassword'])
                db2domain = self.instanceProfile['tsm']['db2domain']
                script = os.path.join(self.shellDir, 'configure_tsm_hadr.sh')
                util.trace_call(self.logger, script, self.inst_name, self.db_name, adminusername, adminpassword, db2domain, as_node_name, hadrRole)
                self.instanceProfile['tsm']['asnodename'] = as_node_name
        except Exception as e:
            print e
            maestro.check_status(1, 'Failed to configure TSM proxy node for HADR')
        self.logger.debug('Succeed to configure TSM proxy node')

    @util.performance_profile_trace
    def __backupForHADR(self):
        self.logger.debug('__backupForHADR begin')
        try:
            result, messsage = self.database_agent.backup('B')
            if result:
                rc = 0
            else:
                rc = 1
            maestro.check_status(rc, 'Failed while calling backup_db')
        except:
            traceback.print_exc()
            raise Exception("Failed to backup databases for HADR")
        finally:
            self.logger.debug('__backupForHADR end')

    @util.performance_profile_trace
    def __restoreForHADR(self):
        self.logger.debug('Start to restore image to standby database from TSM')
        dbpath = maestro.parms['dataMountPoint']
        out_file = os.path.join('/dbaas', 'backup.baseline.%s' % self.db_name)
        f = file(out_file, 'r')
        timestamp = eval(f.read())
        f.close()
        clone_db_sh = os.path.join(self.shellDir, 'clone_db_hadr.sh')
        remote_clone_db_sh = clone_db_sh.replace(self.hadrProfile.primaryNode.nodeName, self.hadrProfile.standbyNode.nodeName)
        cmdStr = ' '.join(['ssh', '%s@%s' % (self.hadrProfile.standbyNode.instanceName, self.hadrProfile.standbyNode.publicIP), \
                        remote_clone_db_sh, self.hadrProfile.standbyNode.instanceName, self.db_name, timestamp[0], dbpath])
        clone_db_cmd = ['su', '-', 'root', '-c',  cmdStr]
        self.logger.debug(clone_db_cmd)
        rc = maestro.trace_call(self.logger, clone_db_cmd)
        if rc != 0:
            raise Exception("Failed to restore databases for HADR")
#         self.logger.debug('Succeed to restore image to standby database from TSM')
#         reset_standby_tsm_node_sh = os.path.join(self.shellDir, 'reset_standby_tsm_node.sh')
#         remote_reset_standby_tsm_node_sh = reset_standby_tsm_node_sh.replace(self.hadrProfile.primaryNode.nodeName, self.hadrProfile.standbyNode.nodeName)
#         tsm_node_name = self.instanceProfile['tsm']['nodeName']
#         standby_tsm_node_name = tsm_node_name.replace(self.hadrProfile.primaryNode.nodeName[:self.hadrProfile.primaryNode.nodeName.rindex('.')], self.hadrProfile.standbyNode.nodeName[:self.hadrProfile.standbyNode.nodeName.rindex('.')])
#         cmdStr = ' '.join(['ssh', '%s@%s' % (self.hadrProfile.standbyNode.instanceName, self.hadrProfile.standbyNode.privateIP), remote_reset_standby_tsm_node_sh, self.hadrProfile.standbyNode.instanceName, self.db_name, standby_tsm_node_name])
#         reset_standby_tsm_node_cmd = ['su', '-', 'root', '-c',  cmdStr]
#         rc = maestro.trace_call(self.logger, reset_standby_tsm_node_cmd)
#         if rc != 0:
#             raise Exception("Failed to reset standby TSM node name.")  
    @util.performance_profile_trace    
    def resetStandbyTSMNode(self, as_node_name, tsm_admin, tsm_admin_pwd):
        reset_standby_tsm_node_sh = os.path.join(self.shellDir, 'reset_standby_tsm_node.sh')
        remote_reset_standby_tsm_node_sh = reset_standby_tsm_node_sh.replace(self.hadrProfile.primaryNode.nodeName, self.hadrProfile.standbyNode.nodeName)
        tsm_node_name = self.instanceProfile['tsm']['nodeName']
        standby_tsm_node_name = tsm_node_name.replace(self.hadrProfile.primaryNode.nodeName[:self.hadrProfile.primaryNode.nodeName.rindex('.')], self.hadrProfile.standbyNode.nodeName[:self.hadrProfile.standbyNode.nodeName.rindex('.')])
        cmdStr = ' '.join(['ssh', '%s@%s' % (self.hadrProfile.standbyNode.instanceName, self.hadrProfile.standbyNode.publicIP), remote_reset_standby_tsm_node_sh, self.hadrProfile.standbyNode.instanceName, self.db_name, standby_tsm_node_name, as_node_name, tsm_admin, tsm_admin_pwd])
        reset_standby_tsm_node_cmd = ['su', '-', 'root', '-c',  cmdStr]
        rc = maestro.trace_call(self.logger, reset_standby_tsm_node_cmd)
        if rc != 0:
            raise Exception("Failed to reset standby TSM node name.")

    @util.performance_profile_trace
    def __backupRestoreWithNamePipes(self):
        self.logger.debug('__backupRestoreWithNamedPipes')
        self.__initHADRRole()
        restoreScript = os.path.join(self.shellDir, 'restore.sh')
        dbpath = maestro.parms['dataMountPoint']
        remoteRestoreScript = restoreScript.replace(self.hadrProfile.primaryNode.nodeName, self.hadrProfile.standbyNode.nodeName)
        rc = util.trace_call(self.logger, self.func_agent_sh, 'restore_backup_with_named_pipe', self.hadrProfile.standbyNode.publicIP, self.hadrProfile.primaryNode.publicIP, self.db_name, remoteRestoreScript, self.inst_name, self.hadrProfile.standbyNode.instanceName, dbpath, user = self.inst_name)
        maestro.check_status(rc, "Failed to backup restore with named pipes")

    @util.performance_profile_trace
    def __configureHADR(self):
        self.logger.debug('__configureHADR begin')
        self.__initHADRRole()
        configure_hadr_sh = os.path.join(self.shellDir, 'do_hadr_setup.sh')
        sync_mode = self.hadrProfile.syncMode        
        virtip = self.db2vip
        if virtip is None:
            virtip = "notdefined"
        self.logger.debug('virtual ip is %s' % virtip)
                
        cmd = [configure_hadr_sh,
               '-hadr_type', 'PRIMARY', \
               '-hadr_sync_mode', sync_mode, \
               '-standby_db2_host', self.hadrProfile.standbyNode.hostName,
               '-standby_root_username', 'root', \
               '-hadr_database', self.db_name, \
               '-primary_db2_instance', self.inst_name, \
               '-hadr_db2_group', self.hadrProfile.primaryNode.instanceOwnerGroup, \
               '-hadr_port_1', self.hadrProfile.primaryNode.hadrPort1, \
               '-hadr_port_2', self.hadrProfile.primaryNode.hadrPort2, \
               '-standby_db2_instance', self.hadrProfile.standbyNode.instanceName,\
               '-standby_group',  self.hadrProfile.standbyNode.instanceOwnerGroup, \
               '-standby_hadr_port_1', self.hadrProfile.primaryNode.hadrPort2, \
               '-standby_hadr_port_2', self.hadrProfile.primaryNode.hadrPort1, \
               '-primary_private_ip', self.hadrProfile.primaryNode.privateIP, \
               '-standby_private_ip', self.hadrProfile.standbyNode.privateIP, \
               '-primary_public_ip', self.hadrProfile.primaryNode.publicIP, \
               '-standby_public_ip', self.hadrProfile.standbyNode.publicIP, \
               '-primary_db2_host_full', self.hadrProfile.primaryNode.hostName,\
               '-standby_db2_service_port', self.hadrProfile.standbyNode.instancePort, \
               '-primary_db2_service_port', self.hadrProfile.primaryNode.instancePort,\
               '-virtual_ip', virtip,\
               '-standby_node_name', self.hadrProfile.standbyNode.nodeName]
        rc = maestro.trace_call(self.logger, cmd)
        if rc != 0:
            raise Exception('Failed to configure HADR')
        self.logger.debug('__configureHADR end')

    @util.performance_profile_trace
    def __configureAutoTakeOver(self):
        self.logger.debug('__configureAutoTakeOver begin')
        if self.isTSAResourceExist() > 0: #0: exist 1: non
            load_type = 'INIT'
        else:
            load_type = 'RELOAD'
        virtip = self.db2vip
        if virtip is None:
            virtip = "notdefined"
        self.logger.debug('Virtual ip is %s' % virtip)
        configure_db2haicu_sh = os.path.join(maestro.node['scriptdir'], 'DB2', 'shell', 'do_db2haicu_setup.sh')
        parms = maestro.parms
        #crit_rsrc_prot_method = parms['critRsrcProtMethod']
        crit_rsrc_prot_method = parms.get("critRsrcProtMethod","3")
        cmd = [configure_db2haicu_sh, '-hadr_type', 'PRIMARY', \
               '-hadr_database', self.db_name, \
               '-primary_private_ip', self.hadrProfile.primaryNode.privateIP, \
               '-standby_private_ip', self.hadrProfile.standbyNode.privateIP, \
               '-primary_db2_instance', self.inst_name, \
               '-standby_db2_instance', self.hadrProfile.standbyNode.instanceName, \
               '-primary_public_ip', self.hadrProfile.primaryNode.publicIP, \
               '-standby_public_ip', self.hadrProfile.standbyNode.publicIP, \
               '-virtual_ip', virtip, \
               '-load_type', load_type, \
               '-crit_rsrc_prot_method', crit_rsrc_prot_method]

        rc = maestro.trace_call(self.logger, cmd)
        if rc != 0:
            raise Exception('Failed to configure auto takeover')
        self.logger.debug('__configureAutoTakeOver end')

    @util.performance_profile_trace
    def isStandbyReady(self):
        try:
            shellPath = os.path.join(maestro.node['scriptdir'], 'DB2', 'shell')
            shellScript = os.path.join(shellPath, 'hadr_monitor.sh')
            remoteScript = shellScript.replace(self.hadrProfile.primaryNode.nodeName, self.hadrProfile.standbyNode.nodeName)
            cmd = ['ssh', 'root@%s' % self.hadrProfile.standbyNode.privateIP, remoteScript, self.db_name, self.standby_inst_name]
            self.logger.debug(cmd)
            rc, status = maestro.trace_stderr_call(self.logger, cmd)
            self.logger.debug(status)
            currentStatus = json.loads(status)
            self.logger.debug("Role: %s, Status: %s" % (currentStatus['role'], currentStatus['hadr_status']))
            if currentStatus['role'].upper() == 'STANDBY':
                return True
            else:
                return False
        except:
            traceback.print_exc()
            return False

    def update_etc_host(self):
        self.logger.debug('update_etc_host')
        if '.' not in self.hadrProfile.primaryNode.hostName:
            primary_short_hostname = self.hadrProfile.primaryNode.hostName
        else:
            primary_short_hostname = self.hadrProfile.primaryNode.hostName[:self.hadrProfile.primaryNode.hostName.index('.')]
        if '.' not in self.hadrProfile.standbyNode.hostName:
            standby_short_hostname = self.hadrProfile.standbyNode.hostName
        else:
            standby_short_hostname = self.hadrProfile.standbyNode.hostName[:self.hadrProfile.standbyNode.hostName.index('.')]  
        
        rc = util.trace_call(self.logger, self.func_agent_sh, 'update_etc_hosts', self.hadrProfile.standbyNode.publicIP, 
                            self.hadrProfile.standbyNode.hostName, standby_short_hostname, nocheck = True)
        
        sshShell = ParallelSSH([self.hadrProfile.standbyNode.publicIP], self.logger)
        rc1, status1 = sshShell.ssh("func_agent.sh %s %s %s %s" % ('update_etc_hosts', self.hadrProfile.primaryNode.publicIP, 
                                    self.hadrProfile.primaryNode.hostName, primary_short_hostname))
        
        
    ######################################################################
    #Entrance for HADR Primary DB setup for versions prior to 1.2.3.0
    ######################################################################
    
    #To provide backward compatibility for 1.2.2.0 script package
    @util.performance_profile_trace
    def hadrPriamrySetup(self, parms):
        self.hadrPrimarySetup(parms)
        
    ######################################################################
    #Entrance for HADR Primary DB setup 1.2.3.0 and later
    ######################################################################

    @util.performance_profile_trace
    def hadrPrimarySetup(self, parms):
        self.logger.debug('hadrPrimarySetup')
        self.db2vip = self.getValueFromParms('db2vip', parms)
        self.createHADRProfile(parms)
        self.updateDBProfileForHADR()
        portList = self.getPortList(self.hadrProfile.primaryNode.hadrPort1, \
                                    self.hadrProfile.primaryNode.hadrPort2)
        self.logger.debug('port list for primary node is: %s' % portList)
        self.openPortForHADR(portList)
        self.initSSHForPrimary()
        self.update_etc_host()
        if '.' in self.hadrProfile.standbyNode.hostName:
            shortHostName = self.hadrProfile.standbyNode.hostName[:self.hadrProfile.standbyNode.hostName.index('.')]
        else:
            shortHostName = self.hadrProfile.standbyNode.hostName
        shortHostName = shortHostName.replace('-', '')
        if self.inst_agent.isTSMConfigured():
            as_node_name = '-'.join([maestro.node['deployment.id'], \
                                     shortHostName, self.hadrProfile.standbyNode.instanceName])
            # The maximum length of node name is 64
            if len(as_node_name) > 64:
                as_node_name = '-'.join([maestro.node['deployment.id'], maestro.node['instance']['public-ip']])
            self.configureTSMProxy(as_node_name, HADRProfile.ROLE_PRIMARY)
#             self.__backupForHADR()
#             self.__restoreForHADR()
#         else:
        self.__backupRestoreWithNamePipes()
        if self.inst_agent.isTSMConfigured():
            self.resetStandbyTSMNode(as_node_name, self.instanceProfile['tsm']['adminusername'], maestro.decode(self.instanceProfile['tsm']['adminpassword']))
        self.__configureHADR()
        self.__configureAutoTakeOver()
        iSCSI_IP = self.getValueFromParms('tsaIscsiIP', parms)
        iSCSI_IQN = self.getValueFromParms('tsaIscsiIQN', parms)
        self.logger.debug('iSCSI_IP is: %s, iSCSI_IQN is: %s' % (iSCSI_IP, iSCSI_IQN))
        if (iSCSI_IP and iSCSI_IQN) :
            self.logger.debug('iSCSI target Setup')            
            iSCSI_init_sh=os.path.join(self.shellDir, 'hadr', 'tsa_iSCSI_init.sh')
            util.trace_call(self.logger, iSCSI_init_sh, iSCSI_IP, iSCSI_IQN)
            iSCSI_config_sh=os.path.join(self.shellDir, 'hadr', 'tsa_iSCSI_config.sh')
            util.trace_call(self.logger, iSCSI_config_sh)


    ######################################################################
    #Entrance for HADR Standby DB setup
    ######################################################################
    @util.performance_profile_trace
    def hadrStandbySetup(self, parms):
        self.logger.debug('hadrStandbySetup')
        self.updateDBProfileForHADR()
        hadrPort1 = self.getValueFromParms('localHADRSevPort', parms)
        hadrPort2 = self.getValueFromParms('remoteHADRSevPort', parms)
        if hadrPort1 is None or hadrPort2 is None:
            raise Exception('Can not get HADR ports')
        portList = self.getPortList(hadrPort1, hadrPort2)
        self.logger.debug('port list for standby node is: %s' % portList)
        self.openPortForHADR(portList)
        self.initSSHForStandby(parms)
        if self.inst_agent.isTSMConfigured():
            as_node_name = '-'.join([maestro.node['deployment.id'], \
                                     maestro.node['instance']['public-ip'], self.inst_name])
            # The maximum length of node name is 64
            if len(as_node_name) > 64:
                as_node_name = '-'.join([maestro.node['deployment.id'], maestro.node['instance']['public-ip']])
            self.configureTSMProxy(as_node_name, HADRProfile.ROLE_STANDBY)
        iSCSI_IP = self.getValueFromParms('tsaIscsiIP', parms)
        iSCSI_IQN = self.getValueFromParms('tsaIscsiIQN', parms)
        self.logger.debug('iSCSI_IP is: %s, iSCSI_IQN is: %s' % (iSCSI_IP, iSCSI_IQN))
        if (iSCSI_IP and iSCSI_IQN) :
            self.logger.debug('iSCSI target Setup')
            iSCSI_init_sh=os.path.join(self.shellDir, 'hadr', 'tsa_iSCSI_init.sh')
            util.trace_call(self.logger, iSCSI_init_sh, iSCSI_IP, iSCSI_IQN)
           

    def isTSAResourceExist(self):
        self.logger.debug("isTSAResourceCreated")
        rc = util.trace_call(self.logger, self.func_agent_sh, 'check_tsa_resource', self.inst_name, nocheck = True)
        self.logger.debug("isTSAResourceCreated, rc = %d" % (rc))
        return rc

    def getCouterpartStatus(self):
        if self.hadrProfile.primaryNode.publicIP == maestro.node['instance']['public-ip']:
            counterpart_node = self.hadrProfile.standbyNode
        else:
            counterpart_node = self.hadrProfile.primaryNode
        role = util.trace_shell_func_call_with_output('check_remote_db_role', self.inst_name, self.db_name, counterpart_node.publicIP)
        return role
#            maestro.check_status(1, "Fail to stop HADR")

    def getCounterpartNodeInfo(self):
        self.logger.debug("getCounterpartNodeInfo")
        primaryNode, standbyNode = self.hadrProfile.getHADRNodeInfo()
        if primaryNode.publicIP == maestro.node['instance']['public-ip']:
            return standbyNode
        else:
            return primaryNode
            
    def switchRole(self, hadr_role):
        self.logger.debug("switchRole begin, db = %s,change to hadr_role = %s" % (self.db_name, hadr_role))
        rc = 0
        current_role = util.trace_shell_func_call_with_output('check_db_role', self.inst_name, self.db_name)
        self.logger.debug("return value of current_role is : %s" %current_role)
        if current_role == "STANDARD":
            rc = -1
        elif current_role == hadr_role:
            self.logger.debug("do nothing")
        elif current_role == "STANDBY" and hadr_role == "PRIMARY":
            self.logger.debug("In switchRole, db = %s, hadr_role = %s, current_role = %s" %(self.db_name, hadr_role, current_role))
            rc = util.trace_shell_func_call('takeover_hadr', self.inst_name, self.db_name)
            if rc == 0:
                self.logger.debug('Succeeded to take over hadr on standby')
                #self.logger.debug('Calling HADRProfile.changePrimaryRole to Update hadr profile to reflect the new status')
                #self.hadrProfile.changePrimaryRole(self.hadrProfile.standbyNode.publicIP)
            else:
                self.logger.debug('Failed to take over hadr')
        elif current_role == "PRIMARY" and hadr_role == "STANDBY":
            self.logger.debug("In switchRole, db = %s, hadr_role = %s, current_role = %s" %(self.db_name, hadr_role, current_role))
            from ParallelSSH import ParallelSSH
            sshShell = ParallelSSH([self.getCounterpartNodeInfo().publicIP], self.logger)
            rc, status2 = sshShell.ssh("func_agent.sh %s %s %s" % ('takeover_hadr', self.inst_name, self.db_name))
            if rc:
                self.logger.debug("switchRole succeeded, rc=%s" % rc)
            else:
                self.logger.debug("switchRole failed, rc=%s" % rc)
                self.logger.debug("Remote take over failed")
        else:
            self.logger.debug("in switchRole final match, current_role = %s" % current_role)
        self.logger.debug("switchRole end")
        return rc
        
