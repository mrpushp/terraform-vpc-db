#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import os
import logging
import maestro
import sys
import platform


class SSHManager(object):

    def __init__(self, fileName):
        self.logger = logging.getLogger("SSHManager.py")
        self.SHELL_DIR = os.path.join(maestro.node['scriptdir'], 'DB2', 'shell', 'network')
        self.localSSHKeyFile = os.path.join("/dbaas", fileName)
        self.sshkey_file_url = maestro.node['deployment.url'] + '/' + fileName
        self.suffix = fileName[fileName.index('_') + 1 : fileName.rindex('_')]

        libdir = os.path.join(maestro.node['scriptdir'], 'DB2', 'lib')
        if not libdir in sys.path:
            sys.path.append(libdir)
        from StorehouseUtil import StorehouseUtil
        self.shUtil = StorehouseUtil(self.localSSHKeyFile, self.sshkey_file_url)

    def __generateSSHKeys(self):
        self.logger.debug("__generateSSHKeys")
        generate_ssh_sh = os.path.join(self.SHELL_DIR, 'generateSSHKey.sh')
        keyFileName = 'id_rsa_%s' % (self.suffix)
        self.logger.debug(keyFileName)
        rc = maestro.trace_call(self.logger, [generate_ssh_sh, keyFileName])
        return rc

    def __uploadSSHKeys(self):
        self.logger.debug("__uploadSSHKeys")
        if platform.system() == "Linux":
            privateKeyFile = '/root/.ssh/id_rsa_%s' % (self.suffix)
            publicKeyFile = '/root/.ssh/id_rsa_%s.pub' % (self.suffix) 
        else:
            privateKeyFile = '/.ssh/id_rsa_%s' % (self.suffix)
            publicKeyFile = '/.ssh/id_rsa_%s.pub' % (self.suffix)
        with open(privateKeyFile, 'r') as privateKeyHandle:
            privateKey = privateKeyHandle.read()
        with open(publicKeyFile, 'r') as publicKeyHandle:
            publicKey = publicKeyHandle.read()
        keySetJson = {}
        keySetJson['public_key'] = publicKey
        keySetJson['private_key'] = privateKey
        rc = self.shUtil.generate(keySetJson)
        return keySetJson

    def __setupPasswordLessSSH(self, userList=None, keySet = None):
        self.logger.debug("__setupPasswordLessSSH")
        if keySet == None:
            try:
                self.shUtil.download()
                keySet = self.shUtil.jsonObject
            except:
                return
        if userList == None:
            userList = [('root', 'root'), (maestro.parms['instanceOwner'], maestro.parms['instanceOwnerGroup'])]
        [self.__setupSSHforUSer(user, group, keySet) for (user, group) in userList]

    def __setupSSHforUSer(self, user, group, keySet):
        self.logger.debug("__setupSSHforUSer")
        publickey = keySet['public_key']
        privatekey = keySet['private_key']
        if (user == "root"):
            if platform.system() == "Linux":
                homeDir = "/" + user + "/.ssh"
            else:
                homeDir = "/.ssh"
        else:
            homeDir = "/home/" + user + "/.ssh"

        if(not os.path.exists(homeDir)):
            os.makedirs(homeDir)

        id_rsa_file_name = homeDir + "/id_rsa_%s" % (self.suffix)
        id_rsa_pub_file_name = homeDir + "/id_rsa_%s.pub" % (self.suffix)
        id_rsa_file_fd = open(id_rsa_file_name, "w")
        id_rsa_file_fd.write(privatekey)
        id_rsa_file_fd.close()
        id_rsa_pub_file_fd = open(id_rsa_pub_file_name, "w")
        id_rsa_pub_file_fd.write(publickey)
        id_rsa_pub_file_fd.close()
        setup_ssh_cmd = [os.path.join(self.SHELL_DIR, 'setupPasswordlessSSH.sh'), user, group, homeDir, id_rsa_file_name]
        self.logger.debug(setup_ssh_cmd)
        rc = maestro.trace_call(self.logger, setup_ssh_cmd)
        if rc != 0 :
            raise Exception('Setup Passwordless SSH failed for user %s.' % (user))
        cmdStr = ' '.join([os.path.join(self.SHELL_DIR, 'setup_ssh_agent.sh'),user, group, homeDir, id_rsa_file_name])
        setup_ssh_agent = ['su', '-', user, '-c', cmdStr]
        self.logger.debug(setup_ssh_agent)
        rc = maestro.trace_call(self.logger, setup_ssh_agent)
        if rc != 0 :
            raise Exception('Setup ssh agent failed for user %s.' % (user))

    def setupForPrimary(self, userList=None):
        self.logger.debug('setupForPrimary begin')
        self.__setupPasswordLessSSH(userList=userList)
        self.shUtil.delete()
        self.logger.debug('setupForPrimary end')

    def setupForStandBy(self, userList=None):
        self.logger.debug('setupForStandBy begin')
        self.__generateSSHKeys()
        keySet = self.__uploadSSHKeys()
        self.__setupPasswordLessSSH(userList=userList, keySet=keySet)
        self.logger.debug('setupForStandBy end')
