#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#####################################
#   DB2 user definition             #
#####################################
import util
import copy
import json
#import maestro
from time import gmtime, strftime
import common

scriptdir = '/tmp/db2scripts'
class DB2User:
    def __init__(self, userName = '', uid = '', password = '', description = '', \
                 sshAccess = False, accountType = 'OS', groups = [], permission = [], \
                 isInstanceAdmin = False, isDatabaseAdmin = False, instanceName = ''):
        self.userName = userName
        self.userId = uid
        #self.password = maestro.decode(password)
        self.password = password
        self.description = description
        self.sshAccess = sshAccess  # True | False
        self.accountType = accountType  # 'OS' or 'LDAP'
        self.groups = groups  # [grp1, ... grpn]
        self.permission = permission  # [SYSADM, SYSCTL, SYSMNT, SYSMON]
        self.isInstanceAdmin = isInstanceAdmin  # True | False
        self.isDatabaseAdmin = isDatabaseAdmin  # True | False
        self.consumers = []
        self.instanceName = instanceName
        self.createdOn = strftime("%Y-%m-%d %H:%M:%S", gmtime())  # Time
        self.updatedOn = strftime("%Y-%m-%d %H:%M:%S", gmtime())  # Time

    def is_instance_admin(self):
        return self.isInstanceAdmin

    def is_database_admin(self):
        return self.isDatabaseAdmin

    def set_is_instance_admin(self, value):
        self.isInstanceAdmin = value

    def set_is_database_admin(self, value):
        self.isDatabaseAdmin = value

    def __str__(self):
        tempDictory = copy.copy(self.getDirectory())
        tempDictory['password'] = '******'
        return 'The user %s profile: %s' % (self.userName, json.dumps(tempDictory, sort_keys = True, indent = 4))

    def getDirectory(self):
        self.dictory = {'userName': self.userName,
                     'uid': self.userId,
                     #'password': maestro.encode(self.password),
                     'password': self.password,
                     'description': self.description,
                     'sshAccess': self.sshAccess,
                     'accountType': self.accountType,
                     'groups': self.groups,
                     'permission': self.permission,
                     'consumers': self.consumers,
                     'isInstanceAdmin': self.isInstanceAdmin,
                     'isDatabaseAdmin': self.isDatabaseAdmin,
                     'createdOn': self.createdOn,
                     'updatedOn': self.updatedOn
                     }
        return self.dictory

    def loadFromDict(self, existing_user):
        self.userName = existing_user['userName']
        #self.password = maestro.decode(existing_user['password'])
        self.password = existing_user['password']
        self.userId = existing_user['uid']
        self.description = existing_user['description']
        self.sshAccess = existing_user['sshAccess']
        self.accountType = existing_user['accountType']
        self.groups = existing_user['groups']
        self.permission = existing_user['permission']
        self.consumers = existing_user['consumers']
        self.isInstanceAdmin = existing_user['isInstanceAdmin']
        self.isDatabaseAdmin = existing_user['isDatabaseAdmin']
        self.createdOn = existing_user['createdOn']
        self.updatedOn = existing_user['updatedOn']

    def getUserName(self):
        return self.userName

    def getUserId(self):
        return self.userId

    def setUserId(self, userId):
        self.userId = userId

    def getSshAllow(self):
        return self.sshAccess

    def setSshAllow(self, sshAccess):
        self.sshAccess = sshAccess

    def getGroups(self):
        return self.groups

    def setGroups(self, value):
        del self.groups[:]
        self.groups.extend(value)

    def delGroups(self):
        del self.groups[:]

    def addGroup(self, groupName):
        try:
            indexPos = self.groups.index(groupName)
            if indexPos >= 0:
                return False
            else:
                return True
        except ValueError:
            self.groups.append(groupName)
            return True

    def removeGroup(self, groupName):
        try:
            self.groups.index(groupName)
            self.groups.remove(groupName)
            return True
        except ValueError:
            return False

    def getPassword(self):
        return self.password

    def setPassword(self, password):
        #self.password = maestro.decode(password)
        self.password = password

    def getAccountType(self):
        return self.accountType

    def setAccountType(self, accountType):
        self.accountType = accountType

    def getDescription(self):
        return self.description

    def setDescription(self, value):
        self.description = value

    def getconsumers(self):
        return self.consumers

    def setconsumers(self, value):
        self.consumers = value

    def addConsumer(self, new_consumer):
        try:
            self.consumers.index(new_consumer)
            return True
        except ValueError:
            self.consumers.append(new_consumer)
            return True

    def removeConsumer(self, consumer):
        try:
            self.consumers.index(consumer)
            self.consumers.remove(consumer)
            return True
        except ValueError:
            return False

    def hasConsumer(self, consumer):
        try:
            self.consumers.index(consumer)
            return True
        except ValueError:
            return False

    def getCreatedOn(self):
        return self.createdOn

    def setCreatedOn(self, value):
        self.createdOn = value

    def getUpdatedOn(self):
        return self.updatedOn

    def setUpdatedOn(self, value):
        self.updatedOn = value

    def delDescription(self):
        del self.description

    def delconsumers(self):
        del self.consumers

    def delCreatedOn(self):
        del self.createdOn

    def delUpdatedOn(self):
        del self.updatedOn

    # sample: add_user_with_id user1 501 password group1,group2,group3 OS db2inst1 True
    def addUser(self, userGID = ''):
        if self.isInstanceAdmin or self.isDatabaseAdmin:
            isAdmin = "True"
        else:
            isAdmin = "False"
        print("user: adduser")
        if userGID == '':
            return common.add_user_with_id(self.userName,  self.userId, self.password, ",".join(self.groups), self.accountType, self.instanceName, isAdmin)
            #return 'add_user_with_id %s %s %s "%s" %s %s %s' % (self.userName, self.userId, self.password, ",".join(self.groups), self.accountType, self.instanceName, isAdmin)
        else:
            #return 'add_user_with_id %s %s %s "%s" %s %s %s' % (self.userName, self.userId, self.password, userGID, self.accountType, self.instanceName, isAdmin)
            return common.add_user_with_id(self.userName, self.userId, self.password, userGID, self.accountType, self.instanceName, isAdmin)

    # sample: delete_user user1 OS
    def delUser(self):
        return 'delete_user %s %s' % (self.userName, self.accountType)

    # sample: addOSProfile db2inst1 user1 True
    def addOSProfile(self):
        #return 'addOSProfile %s %s %s' % (self.instanceName, self.userName, self.isAdmin)
        cmd='%s/DB2/shell/defaultOSProfile.sh %s %s %s' % (scriptdir, self.instanceName, self.userName, self.isAdmin)
        rc, out,err=util.runShell(cmd)
        return rc

    # sample: changeUsermod user1 755
    def chmodUserHome(self, chmod = '755'):
        return 'changeUsermod %s %s' % (self.userName, chmod)

    # sample: disable_ssh_for_user user1
    def disableSSH(self):
        self.sshAccess = False
        return 'disable_ssh_for_user %s' % self.userName
    # sample: enable_ssh_for_user user1
    def enableSSH(self):
        self.sshAccess = True
        return 'enable_ssh_for_user %s' % self.userName
    # sample: change_user_greoup user1 group2,group3
    def changeGroups(self, group_list):
        return 'change_user_groups %s %s' % (self.userName, ','.join(group_list))

    # sampale: add_user_to_groups user1 group5,group6
    def appendToGroups(self, group_list):
        for groupName in group_list:
            self.addGroup(groupName)

        return 'add_user_to_groups %s %s' % (self.userName, ','.join(group_list))

    #sample: remove_user_from_groups user1 group2,group3
    def removeFromGroups(self, group_list):
        for groupName in group_list:
            self.removeGroup(groupName)

        return 'remove_user_from_groups %s %s' % (self.userName, ','.join(group_list))
    #sample: change_user_pwd user1 password1
    def resetPassword(self, newpassword):
        self.password = newpassword
        return 'change_user_pwd %s %s' % (self.userName, newpassword.replace('$', '\$'))
