#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import os
import tempfile
import fcntl
import logging

class Lock(object):
    def __init__(self, lock_name):
        self.lock_name = lock_name
        self.is_locked = False
        self.logger = logging.getLogger()
        self.lockfile = os.path.join(tempfile.gettempdir(), "%s.lock" % lock_name)
        self.pid = repr(os.getpid())
        self.logger.debug("lock file is %s, process id is %s " % (self.lockfile, self.pid))
        
    def acquire(self):
        if not self.is_locked:
            self.logger.debug("wait for the lock %s by %s" % (self.lock_name, self.pid))
            self.f_lock = open(self.lockfile, 'w')
            try:
                fcntl.lockf(self.f_lock, fcntl.LOCK_EX)
            except IOError:
                self.logger.debug("Another operation is running")
            self.is_locked = True
            self.logger.debug("acquire the lock %s by %s" % (self.lock_name, self.pid))
        else:
            self.logger.debug("Already acquired the lock %s by %s" % (self.lock_name, self.pid))

    def release(self):
        if self.is_locked:
            fcntl.lockf(self.f_lock, fcntl.LOCK_UN)
            self.logger.debug("release the lock %s by %s" % (self.lock_name, self.pid))
            self.is_locked = False
        else:
            self.logger.debug("there is no lock %s by %s, so skip to release" % (self.lock_name, self.pid))

    def __enter__(self):
        self.acquire()
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self.release()
