#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import maestro
import os
from StorehouseUtil import StorehouseUtil
import logging


class NodeInfo(object):

    def __init__(self, privateIP, publicIP, hostName, nodeName):
        self.privateIP = privateIP
        self.hostName = hostName
        self.nodeName = nodeName
        self.publicIP = publicIP

    def __cmp__(self, otherNodeInfo):
        if (otherNodeInfo == None):
            return -1
        if (self.privateIP == otherNodeInfo.privateIP) and (self.hostName == otherNodeInfo.hostName) and (self.nodeName == otherNodeInfo.nodeName):
            return 0
        else:
            return -1

    def __str__(self):
        return "<NodeInfo>[IP:%s][HostName:%s][NodeName:%s]" % (self.privateIP, self.hostName, self.nodeName)


class HADRNodeInfo(NodeInfo):
    def __init__(self, privateIP, publicIP, hostName, nodeName, initialHADRRole, hadrPort1, hadrPort2, instanceName, instancePort, instanceOwnerGroup):
        super(HADRNodeInfo, self).__init__(privateIP, publicIP, hostName, nodeName)
        self.initialHADRRole = initialHADRRole
        self.hadrPort1 = hadrPort1
        self.hadrPort2 = hadrPort2
        self.instanceName = instanceName
        self.instancePort = instancePort
        self.instanceOwnerGroup = instanceOwnerGroup

    def __cmp__(self, otherNodeInfo):
        if super(HADRNodeInfo, self).__cmp__(otherNodeInfo) == 0:
            if self.initialHADRRole == otherNodeInfo.initialHADRRole and self.instanceName == otherNodeInfo.instanceName \
                and self.instancePort == otherNodeInfo.instancePort and self.hadrPort1 == otherNodeInfo.hadrPort1 \
                and self.hadrPort2 == otherNodeInfo.hadrPort2 \
                and self.instanceOwnerGroup == otherNodeInfo.instanceOwnerGroup:
                return 0
        return -1

    def isTheSameInstance(self, publicIP, instanceName):
        if self.publicIP == publicIP and self.instanceName == instanceName:
            return True
        else:
            return False

    def convertToJson(self):
        res = {}
        res['privateIP'] = self.privateIP
        res['publicIP'] = self.publicIP
        res['hostName'] = self.hostName
        res['nodeName'] = self.nodeName
        res['initialHADRRole'] = self.initialHADRRole
        res['hadrPort1'] = self.hadrPort1
        res['hadrPort2'] = self.hadrPort2
        res['instanceOwner'] = self.instanceName
        res['instancePort'] = self.instancePort
        res['instanceOwnerGroup'] = self.instanceOwnerGroup
        return res


class HADRProfile(object):
    DBAAS_TEMP_DIR = '/dbaas'
    ROLE_PRIMARY = "PRIMARY"
    ROLE_STANDBY = "STANDBY"

    def __init__(self, fileName):
        self.logger = logging.getLogger('HADRProfile.py')
        if not os.path.exists(HADRProfile.DBAAS_TEMP_DIR):
            os.makedirs(HADRProfile.DBAAS_TEMP_DIR)
        self.hadrProfileName = fileName
        self.URL = os.path.join(maestro.node['deployment.url'], 'hadr', self.hadrProfileName)
        self.LOCAL_FILE = os.path.join(HADRProfile.DBAAS_TEMP_DIR, self.hadrProfileName)
        self.shUtil = StorehouseUtil(self.LOCAL_FILE, self.URL)
        self.clearDeltaToDelete()
        self.clearDeltaToUpdate()
        self.primaryNode = None
        self.standbyNode = None        

    #Only for Primary Script Package
    def initHADRProfileForGenerate(self, parms):
        #parameters need be stored in HADR profile
        #primaryIP (primary's public ip)
        #syncMode (sync, nearsync)
        #dbName
        #Node List in HADR pair, and each node contains : publicIP, privateIP,
        #hostName, nodeName,
        #initialHADRRole, hadrPort1, hadrPort2, instanceName, instancePort
        #node key is publicIP
        self.hadrProfile = {}
        self.hadrProfile['databaseName'] = self.getValueFromParms('databaseName', parms)

        self.syncMode = self.getValueFromParms('hadrSyncMode', parms)
        if self.syncMode is None:
            raise Exception('Can not get HADR database sync mode!')
        self.hadrProfile['hadrSyncMode'] = self.syncMode

        self.primaryIP = maestro.node['instance']['public-ip']
        self.hadrProfile['primaryIP'] = self.primaryIP

        #initialize Primary node
        publicIP = self.primaryIP
        privateIP = maestro.node['instance']['private-ip']
        hostName = maestro.node['parts']['host']['host']
        deployment = maestro._get_deployment_doc()
        if hostName is None or hostName == '' or hostName == 'hostname-TBD':
            nodeName, hostName = self.getNodeValuesFromDeploymentByIP('public-hostname', publicIP, deployment)
        nodeName = maestro.node['id']
        initialHADRRole = HADRProfile.ROLE_PRIMARY
        hadrPort1 = self.getValueFromParms('localHADRSevPort', parms)
        hadrPort2 = self.getValueFromParms('remoteHADRSevPort', parms)
        instanceName = self.getValueFromParms('instanceName', parms)
        instancePort = self.getValueFromParms('instancePort', parms)
        instanceOwnerGroup = self.getValueFromParms('instanceOwnerGroup', parms)

        if None in [hadrPort1, hadrPort2, instanceName, instancePort, instanceOwnerGroup]:
            raise Exception('Can not get all information of Primary Node!')
        hadrNodes = {}
        self.primaryNode = HADRNodeInfo(privateIP, publicIP, hostName, nodeName, initialHADRRole, hadrPort1, hadrPort2, instanceName, instancePort, instanceOwnerGroup)
        hadrNodes[publicIP] = self.primaryNode.convertToJson()

        #initialize Standby node
        publicIP = self.getValueFromParms('standbyIP', parms)
        if publicIP is not None and '/' in publicIP:
            publicIP = publicIP[:publicIP.rindex('/')]
        nodeName, privateIP = self.getNodeValuesFromDeploymentByIP('private-ip', publicIP, deployment)
        hostName = self.getValueFromParms('standbyHostName', parms)
        if hostName is None or hostName == '' or hostName == 'hostname-TBD':
            nodeName, hostName = self.getNodeValuesFromDeploymentByIP('public-hostname', publicIP, deployment)
        initialHADRRole = HADRProfile.ROLE_STANDBY
        hadrPort1 = self.getValueFromParms('remoteHADRSevPort', parms)
        hadrPort2 = self.getValueFromParms('localHADRSevPort', parms)
        instanceName = self.getValueFromParms('standbyInstanceName', parms)
        instancePort = self.getValueFromParms('standbyInstancePort', parms)
        instanceOwnerGroup = self.getValueFromParms('standbyInstanceOwnerGroup', parms)
        if None in [publicIP, nodeName, privateIP, hostName, hadrPort1, hadrPort2, instanceName, instancePort, instancePort]:
            raise Exception('Can not get all information of Standby Node!')
        self.standbyNode = HADRNodeInfo(privateIP, publicIP, hostName, nodeName, initialHADRRole, hadrPort1, hadrPort2, instanceName, instancePort, instanceOwnerGroup)
        hadrNodes[publicIP] = self.standbyNode.convertToJson()
        self.hadrProfile['hadr_nodes'] = hadrNodes
        self.hadrProfile['hadr_status'] = ''
        self.hadrProfile['db2vip'] = self.getValueFromParms('db2vip', parms)

    def getValueFromParms(self, key, parms):
        return parms[key] if (parms is not None and key in parms) else (maestro.parms[key] if key in maestro.parms else None)

    def getNodeValuesFromDeploymentByIP(self, key, IP, deployment=None):
        if deployment is None:
            deployment = maestro._get_deployment_doc()
        for node in deployment['instances']:
            if deployment['instances'][node]['public-ip'] == IP:
                return node, deployment['instances'][node][key]
        return None, None

    def has_key(self, key):
        return self.shUtil.has_key(key)

    def generate(self, parms):
        self.logger.debug("generate")
        self.initHADRProfileForGenerate(parms)
        rc, etag = self.shUtil.generate(self.hadrProfile, '.')
        print "generate:%s" % str(rc)
        return rc

    def exist(self):
        return self.shUtil.exist()

    def download(self):
        return self.shUtil.download()

    def downloadWithoutTrace(self):
        return self.shUtil.downloadWithoutTrace()
    '''
    structure of updateDelta is the same with the storehouse target json file
    '''
    def setDeltaToUpdate(self, updateDelta):
        self.updateDelta = updateDelta

    def clearDeltaToUpdate(self):
        self.updateDelta = {}

    '''
    i.e, target file is:
        {
          "a": {
                "b":"b1",
                "bb":"bb1"
                },
          "c":{"ccc"},
          "d":"ddd"
          }
    and you want to delete "a:b" and "c" items, and make them:
        {
          "a": {
                "bb":"bb1"
                },
          "d":"ddd"
          }
    then deleteDelta should be [ ["a", "b"] , ["c"] ]
    '''
    def setDeltaToDelete(self, deleteDelta):
        self.deleteDelta.update(deleteDelta)

    def clearDeltaToDelete(self):
        self.deleteDelta = {}

    def update(self):
        self.shUtil.updateDelta(self.updateDelta)
        self.shUtil.deleteDelta(self.deleteDelta)
        self.shUtil.upload()
        self.clearDeltaToUpdate()
        self.clearDeltaToDelete()

    def __str__(self):
        return str(self.jsonObject)

    def getHADRNodeInfo(self):
        # assume there could be more than 1 standby
        self.logger.debug("getHADRNodeInfo")
        hadrProfile = self.download()
        nodes = hadrProfile['hadr_nodes']
        for key in nodes.keys():
            publicIP = nodes[key]['publicIP']
            privateIP = nodes[key]['privateIP']
            hostName = nodes[key]['hostName']
            nodeName = nodes[key]['nodeName']
            initialHADRRole = nodes[key]['initialHADRRole']
            hadrPort1 = nodes[key]['hadrPort1']
            hadrPort2 = nodes[key]['hadrPort2']
            instanceName = nodes[key]['instanceOwner']
            instancePort = nodes[key]['instancePort']
            instanceOwnerGroup = nodes[key]['instanceOwnerGroup']
            newNode = HADRNodeInfo(privateIP, publicIP, hostName, nodeName, initialHADRRole, hadrPort1, hadrPort2, instanceName, instancePort, instanceOwnerGroup)
            if publicIP == hadrProfile['primaryIP']:
                self.primaryNode = newNode
            else:
                self.standbyNode = newNode
        self.dbName = hadrProfile['databaseName']
        self.syncMode = hadrProfile['hadrSyncMode']
        self.primaryIP = hadrProfile['primaryIP']
        self.db2vip = hadrProfile['db2vip']

        return self.primaryNode, self.standbyNode

    def changePrimaryRole(self, newPrimaryPublicIP):
        self.logger.debug('in changePrimaryRole,Changing role of standbyIP to primary in SH hadr profile %s' % newPrimaryPublicIP)
        hadrProfile = self.download()
        nodes = hadrProfile['hadr_nodes']
        for publicIP in nodes.keys():
            if publicIP == newPrimaryPublicIP:
                nodes[publicIP]['role'] = HADRProfile.ROLE_PRIMARY
                hadrProfile['primaryIP'] = newPrimaryPublicIP
            else:
                hadrProfile['standbyIP'] = publicIP
        self.setDeltaToUpdate(hadrProfile)
        self.update()
