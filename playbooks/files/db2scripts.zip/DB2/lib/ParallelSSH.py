#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#import commands
import subprocess
import json
import os
import threading
import re
import platform

class ParallelSSH:
    def __init__(self, servers, logger, userName = '', password = ''):
        self.servers = []

        for server_name in servers:
            self.servers.append(server_name)

        self.logger = logger
        self.shellPath = os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell')
        self.userName = userName
        self.password = password

    def getExecuteCommand(self, commandStr):
        if commandStr and len(commandStr.strip()) > 0:
            #the command with the absolute path
            if commandStr.split()[0].startswith('/'):
                execute_commandStr = commandStr
            elif commandStr.split()[0].endswith('.sh'):
                #command with DBaaS script
#                prefix_path = os.path.normpath(self.shellPath)
                shell_script = '/opt/IBM/maestro/agent/usr/servers'
                prefix_path = '$(dirname $(find %s -name func_agent.sh | awk "/\/opt\/IBM\/maestro\/agent\/usr\/servers\/.*\.[0-9]+\/scripts\/DB2\/shell\//"))' % shell_script
                #self.logger.debug('prefix_path is %s' % (prefix_path))
                execute_commandStr = '%s/%s' % (prefix_path, commandStr)
            else:
                #the OS system command
                execute_commandStr = commandStr
        return execute_commandStr

    def ssh(self, commandStr, **kwargs):
        rc, status, output = self.sshWithOutput(commandStr, **kwargs)
        return rc, status

    def sshWithOutput(self, commandStr, **kwargs):
        if platform.system() == 'Linux':
            exec_profile_cmd = ". /root/.bash_profile"
        else:
            exec_profile_cmd = ". /.profile"
        
        if commandStr and len(commandStr.strip()) > 0:
            if 'user' in kwargs:
                user = kwargs['user']
                try:
                    del kwargs['user']
                except:
                    self.logger.debug("except in del kwargs[user]")
                    
                commandTemplate = '%s && /usr/bin/ssh %s \'su - %s -c "%s"\'' % \
                    (exec_profile_cmd, '%s', user, self.getExecuteCommand(commandStr))
            else:
                #self.logger.debug("no users in kwargs")
                commandTemplate = '%s && /usr/bin/ssh %s \'%s\'' % \
                    (exec_profile_cmd, '%s', self.getExecuteCommand(commandStr))
            #self.logger.debug("commandTemplate is %s" % commandTemplate)
            return self.sshTasks(commandTemplate, **kwargs)
            #return self.sshTasks(Makeup_command, **kwargs)
        else:
            return False, 'Error: command is null', {}

    def scp(self, localFile, username, remoteFile):
        if platform.system() == 'Linux':
            exec_profile_cmd = ". /root/.bash_profile"
        else:
            exec_profile_cmd = ". /.profile"
        if os.path.isfile(localFile):
            commandTemplate = '%s && /usr/bin/scp %s %s@%s:%s' % (exec_profile_cmd, localFile, username, '%s', remoteFile)
        else:
            commandTemplate = '%s && /usr/bin/scp -r %s %s@%s:%s' % (exec_profile_cmd, localFile, username, '%s', remoteFile)
        return self.sshTasks(commandTemplate)

    def sshWithPassword(self, commandStr):
        if commandStr and len(commandStr.strip()) > 0:
            commandTemplate = '%s/exp_ssh.sh %s %s %s "%s"' % (self.shellPath, self.userName, self.password, '%s', self.getExecuteCommand(commandStr))

            return self.sshTasks(commandTemplate)
        else:
            return False, 'Error: command is null'

    def scpWithPassword(self, localFile, remoteFile):
        commandTemplate = '%s/exp_scp.sh %s %s %s@%s %s' % (self.shellPath, localFile, self.userName, '%s', remoteFile, self.password)
        return self.sshTasks(commandTemplate)

    def sshWithKey(self, commandStr):
        if commandStr and len(commandStr.strip()) > 0:
            commandTemplate = '%s/exp_ssh_key.sh %s %s %s %s' % (self.shellPath, self.password, self.userName, '%s', self.getExecuteCommand(commandStr))

            return self.sshTasks(commandTemplate)
        else:
            return False, 'Error: command is null'

    def scpWithKey(self, localFile, remoteFile):
        commandTemplate = '%s/exp_scp_key.sh %s %s %s %s' % (self.shellPath, localFile, self.userName, '%s', remoteFile, self.password)
        return self.sshTasks(commandTemplate)

    def sshTasks(self, commandTemplate, **kwargs):
        echo_stdin = True
        if 'echo_stdin' in kwargs:
            echo_stdin = kwargs['echo_stdin']
            del kwargs['echo_stdin']

        echo_stdout = True
        if 'echo_stdout' in kwargs:
            echo_stdout = kwargs['echo_stdout']
            del kwargs['echo_stdout']

        commandArgsMap = None
        if 'commandArgsMap' in kwargs:
            commandArgsMap = kwargs['commandArgsMap']
            del kwargs['commandArgsMap']

        self.logger.debug("servers are '%s' " % self.servers)

        #prepare the tasks
        tasks = []
        for ipaddr in self.servers:
            if ipaddr.find(':') > 0:
                #if re.search('(ssh |exp_ssh.sh|exp_ssh_key.sh)', os.path.basename(commandStr)):
                #if re.search('(ssh |exp_ssh.sh|exp_ssh_key.sh)', os.path.basename(commandTemplate)):
                if re.search('(ssh |exp_ssh.sh|exp_ssh_key.sh)', commandTemplate):
                    new_addr = ipaddr
                else:
                    new_addr = '[%s]' % ipaddr
            else:
                new_addr = ipaddr
            commandStr = commandTemplate % new_addr
            if echo_stdin:
                self.logger.debug('commandStr is %s' % commandStr)

            if commandArgsMap:
                commandStr = '%s %s' % (commandStr, commandArgsMap[ipaddr])
                self.logger.debug('command is: %s' % commandStr)

            tasks.append(ShellTask(commandStr = commandStr))

        #start the tasks
        executor = ThreadedExecutor()
        futures = []

        for task_item in tasks:
            futures.append(executor.submit(task_item))

        stdoutServers = {}
        successCount = 0
        item_indx = 0
        for future_item in futures:
            exit_code, text = future_item.result()
            stdoutServers[self.servers[item_indx]] = text
            item_indx = item_indx + 1
            if exit_code == 0:
                successCount += 1
            else:
                if echo_stdout:
                    self.logger.debug('exit code is: %d, execute message is %s' % (exit_code, text))

        if successCount == len(tasks):
            if echo_stdout:
                exit_message = json.dumps(stdoutServers, sort_keys = True, indent = 4)
                self.logger.debug(exit_message)
            else:
                exit_message = 'Success to execute command on all nodes'

            return True, exit_message, stdoutServers
        else:
            if echo_stdout:
                exit_message = json.dumps(stdoutServers, sort_keys = True, indent = 4)
                self.logger.error(exit_message)
            else:
                exit_message = 'Failed to execute command on node'

            return False, exit_message, stdoutServers
        return True, 'Success', stdoutServers

class ThreadedExecutor(object):
    def submit(self, curTask):
        thread = threading.Thread(target = curTask)
        thread.start()
        return curTask.future

class ShellTask(object):
    def __init__(self, *args, **kwargs):
        self.future = ShellFuture()
        self.args = args
        self.kwargs = kwargs

    def __call__(self):
        exit_code, message = self.execute()
        self.future._set_result(exit_code)
        self.future._set_error(message)

    def execute(self):
        cmd = self.kwargs['commandStr']
        status, text = commands.getstatusoutput(cmd)
        exit_code = status >> 8 # high byte
#            signal_num = status % 256 # low byte
        return exit_code, text

class ShellFuture(object):
    def __init__(self):
        self._event = threading.Event()
        self._result = None
        self._error_happened = False
        self._error = None

    def result(self):
        self._event.wait()
        return self._result, self._error

    def _set_result(self, result):
        self._result = result
        self._event.set()

    def _set_error(self, error):
        self._error = error
        self._error_happened = True
        self._event.set()
