#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import os
import subprocess
import logging
import datetime
import time
import inspect
import stat
#import maestro
import json
#import commands
import base64
import platform
import shutil
import glob
import zipfile
#import requests
import logging

#from StorehouseUtil import StorehouseUtil

_logger = logging.getLogger()

scriptdir = '/tmp/db2scripts'

#Only support: none return value, or only one return object
#example:
#DEBUG Process ID 10800, Function testb: start
#DEBUG Process ID 10800, Function testb: end, elapsed time 0s      
def performance_profile_trace(func):
    def profile_wrapper(*args, **kwargs):
        method_args = inspect.getargspec(func).args
        defined_in_class = bool(method_args and method_args[0] == 'self')

        if defined_in_class:
            self = args[0]
            _logger.debug("Class %s, Function %s: start" % (self.__class__.__name__, func.__name__))
        else:
            _logger.debug("Function %s: start" % (func.__name__))

        starttime = datetime.datetime.now()

        #execute the real function
        value = func(*args, **kwargs)

        endtime = datetime.datetime.now()
        used_time = (endtime - starttime).seconds
        if defined_in_class:
            _logger.debug("Process ID %s, Class %s, Function %s: end, elapsed time %ds" % (os.getpid(), self.__class__.__name__, func.__name__, used_time))
        else:
            _logger.debug("Process ID %s, Function %s: end, elapsed time %ds" % (os.getpid(), func.__name__, used_time))

        return value

    return profile_wrapper

#@performance_profile_trace
def trace_call(_logger, *popenargs, **kwargs):
    nocheck = None
    if 'nocheck' in kwargs:
        nocheck = kwargs['nocheck']
        del kwargs['nocheck']

    notfound_ignore = None
    if 'notfound_ignore' in kwargs:
        notfound_ignore = kwargs['notfound_ignore']
        del kwargs['notfound_ignore']

    echo_stdin = True
    if 'echo_stdin' in kwargs:
        echo_stdin = kwargs['echo_stdin']
        del kwargs['echo_stdin']

    if 'user' in kwargs:
        user = kwargs['user']
        del kwargs['user']

        dirname = os.path.split(popenargs[0])[0]
        if dirname:
            if not os.path.isfile(popenargs[0]) and notfound_ignore:
                return 0

        popenarg = ''
        for arg in popenargs:
            popenarg += ' "%s"' % arg

        command = ['su', '-', user, '-c', 'cd %s; %s;' % (dirname, popenarg)]
        if echo_stdin:
            _logger.debug(command)
        #rc = maestro.trace_call(_logger, command, **kwargs)
        rc, out, err=runShell(command)
    else:
        dirname = os.path.split(popenargs[0])[0]
        if dirname:
            if not os.path.isfile(popenargs[0]) and notfound_ignore:
                return 0
        command = popenargs

        if echo_stdin:
            _logger.debug(command)
        #rc = maestro.trace_call(_logger, popenargs, **kwargs)
        rc, out, err=runShell(popenargs)

    if nocheck:
        return rc

    if echo_stdin:
        #maestro.check_status(rc, 'Failed while executing: %s' % [command])
        if rc !=0:
            _logger.debug('Failed while executing: %s' % [command])
            return rc
    else:
        #maestro.check_status(rc, 'Failed  to execute the command, rc=%s' % rc)
        if rc !=0:
            _logger.debug('Failed while executing: %s' % [command])
            return rc
    return rc

def get_func_agent_args(function_name):
    scriptdir = os.path.normpath(os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell'))
    func_agent_sh = os.path.join(scriptdir, 'func_agent.sh')
    shell_args = [func_agent_sh, function_name]

    return shell_args

def subprocess_execute(command, time_out = 7200):
    """executing the command with a watchdog"""
    # launching the command
    c = subprocess.Popen(command)

    # now waiting for the command to complete
    t = 0
    while t < time_out and c.poll() is None:
        time.sleep(1)  # (comment 1)
        t += 1

    # there are two possibilities for the while to have stopped:
    pid = c.pid
    if c.poll() is None:
        # in the case the process did not complete, we kill it
        _logger.debug('timeout %s, kill the process' % time_out)
        os.system("ps -o pid= --ppid %d | xargs kill -9" % pid)
        c.terminate()
        # and fill the return code with some error value
        returncode = -1  # (comment 2)
    else:
        # in the case the process completed normally
        returncode = c.poll()

    return returncode

def trace_shell_func_call(function_name, *popenargs, **kwargs):
    shell_args = []
    shell_args.extend(get_func_agent_args(function_name))
    shell_args.extend(popenargs)

    echo_stdin = True
    if 'echo_stdin' in kwargs:
        echo_stdin = kwargs['echo_stdin']
        del kwargs['echo_stdin']
    if echo_stdin:
        _logger.debug(shell_args)

    rc = 0
    timeout = 7200 # 2 hours
    if 'timeout' in kwargs:
        if kwargs['timeout']:
            timeout = kwargs['timeout']
        del kwargs['timeout']
        rc = subprocess_execute(shell_args, timeout)
    else:
        #rc = maestro.trace_call(_logger, shell_args, **kwargs)
        rc, out, err=runShell(shell_args)
    return rc

def trace_stderr_call(function_name, *popenargs, **kwargs):
    shell_args = []
    shell_args.extend(get_func_agent_args(function_name))
    shell_args.extend(popenargs)

    echo_stdin = True
    if 'echo_stdin' in kwargs:
        echo_stdin = kwargs['echo_stdin']
        del kwargs['echo_stdin']

    echo_stdout = True
    if 'echo_stdout' in kwargs:
        echo_stdout = kwargs['echo_stdout']
        del kwargs['echo_stdout']

    if echo_stdin:
        _logger.debug(shell_args)

    #status, text = commands.getstatusoutput(" ".join(shell_args))
    #exit_code = status >> 8 # high byte
    rc, text, err = runShell(" ".join(shell_args))
    exit_code = rc >> 8 # high byte

    if echo_stdout:
        _logger.debug("exit code is: '%s', return message is: '%s'" %(exit_code, text))

    return exit_code, text

def trace_shell_func_call_with_output(function_name, *args, **kwargs):
        shell_args = []
        shell_args.extend(get_func_agent_args(function_name))

        shell_args.extend(args)
        echo_stdin = True
        if 'echo_stdin' in kwargs:
            echo_stdin = kwargs['echo_stdin']
            del kwargs['echo_stdin']

        if echo_stdin:
            print(shell_args)
        
        print("*********%s **********" % shell_args)
        p = subprocess.Popen(shell_args, stdout = subprocess.PIPE)

        value = ""
        while True:
            line = p.stdout.readline()
            if not line or line == "\r" or line == "\n\r" or line == "\n":
                break
            value = value + " " + line.strip()
        value_strip = value.strip()
        _logger.debug('return value=%s' % value_strip)
        return value_strip

def read_Json_FromStoreHouse(workload_meta_url, local_dir):
    file_name = os.path.basename(workload_meta_url)
    workload_meta_file = file_name
    # Download
    #maestro.download(workload_meta_url, workload_meta_file)
    downloadFile(workload_meta_url, '/tmp', workload_meta_file)
    # Load
    workload_meta_fd = file(workload_meta_file, 'r')
    json_content = json.load(workload_meta_fd)
    workload_meta_fd.close()
    # Remove
    os.remove(workload_meta_file)
    return json_content

# if v1 < v2, return -1; if v1 > v2, return 1; else return 0
def compare_versions (v1, v2):
    v1Arr = v1.split('.')
    v2Arr = v2.split('.')
    for index in range(0, 4):
        if int(v1Arr[index]) < int(v2Arr[index]):
            return -1
        elif int(v1Arr[index]) > int(v2Arr[index]):
            return 1
    return 0

def parse_fixPack_version(db2_package_path):
    #if it's a special build, need to get version info from meta in SH
    if db2_package_path.find("special") >= 0:
        deployment_url = os.environ['DEPLOYMENT_URL']
        index = deployment_url.find("deployments")
        user_url = deployment_url[:index]
        special_meta_url = user_url + "db2/fixpacks/" + db2_package_path + ".json"
        local_file_path = "/dbaas/"
        local_file = os.path.join(local_file_path, db2_package_path + ".json")
        storehouseUtil = StorehouseUtil(local_file, special_meta_url)
        metaData = storehouseUtil.download()
        _logger.debug('Parse version for special build, db2 level is: ''%s''' % (metaData['level']))
        if metaData.has_key('level'):
            return metaData['level']
    else:
        db2_package = db2_package_path
        version = db2_package.split('_')[0]
        fixpack = version.split('fp')[1]
        mainVersion = version.split('fp')[0].split('v')[1]
        if db2_package.startswith('v10'):
            versionNum = mainVersion + '.0.' + fixpack
        elif db2_package.startswith('v11'):
            versionNum = mainVersion + '.' + fixpack
        #print versionNum
        return versionNum
  

# for example: db2_hybrid_en_9.7.0.5-aix64-20120112.tgz
def parse_fixPack_Payload_version(db2_package):
    versionNum = db2_package.split("_")[-1].replace(".tgz", "")
    return versionNum

def get_db2_level():
    return trace_shell_func_call_with_output('get_db2_level')

def get_dbms_home():
    return trace_shell_func_call_with_output('get_dbms_home')

def get_db2_version(db2level):
    versions = db2level.split('.')
    return versions[0] + "." + versions[1]

# foo({'Node type':'Database Server with local and remote clients', 'Max number of concurrently active databases (NUMDB)':'8'})
def strip_cfg(d):
    new_d = {}
    for key in d:
        new_key = key.split('(')[-1].split(')')[0]
        if new_key:
            new_d[new_key] = d[key].split('(')[0]
    return new_d

def encode(s):
    ch = []
    for char in s:
        ch.append(chr(ord(char) ^ 0x5f))
    return "<xor>" + base64.b64encode(''.join(ch))

def getRoleName():
    #return maestro.node['id'][:maestro.node['id'].rindex('.')]
    #DB2LUW 
    #DB2_11_1
    #Ideally a check on version should be done to determine role name , I a hardcoding for now to support only 11.5 
    return 'DB2_11_5'
     

def startCrontab():
    if os.path.isfile('/etc/init.d/crond'):
        rc = trace_call(_logger, '/etc/init.d/crond', 'status', nocheck = 1)
        if rc != 0:
            _logger.debug('Starting crond')
            trace_call(_logger, '/etc/init.d/crond', 'start')

def _safe_move(srcfile, destdir):
    if os.path.isfile(srcfile):
        destfile = os.path.join(destdir, os.path.basename(srcfile))
        if os.path.isfile(destfile):
            os.remove(destfile)
        shutil.move(srcfile, destdir)   
        
def setupTagFile():
    #scriptdir = maestro.node['scriptdir']
    #Declare globally
    itlmdir = os.path.join(scriptdir, 'DB2', 'itlm')
    
    CFG_DIR = os.getenv('0CONFIG_HOME', '/0config')
    
    versiondir = os.path.join(CFG_DIR, 'itlm', 'db2pattern', 'properties', 'version')
    if not os.path.exists(versiondir):
        os.makedirs(versiondir)
    
#     DB2_with_BLU_Acceleration_Pattern-1.2.0
    swtagfiles = glob.iglob(itlmdir + '/DB2_with_BLU_Acceleration_Pattern*.swtag')
    for swtagfile in swtagfiles:
        _safe_move(swtagfile, versiondir)
    
    fxtagfiles = glob.iglob(itlmdir + '/DB2_with_BLU_Acceleration_Pattern*.fxtag')
    for fxtagfile in fxtagfiles:
        _safe_move(fxtagfile, versiondir)
        
    for root, dirs, files in os.walk(os.path.join(CFG_DIR, 'itlm')):
        os.chmod(root, stat.S_IRWXU)
        #os.chmod(root, '0444')
        for fname in files:
            full_path = os.path.join(root, fname)
            #os.chmod(full_path, '0444')
            os.chmod(full_path, stat.S_IRWXU)

def runShell(cmd, silent=False):
        """Run a shell command but don't throw an exception for a bad return code.
        :param cmd command to run
        :param silent (boolean) Print debug output to stdout? 
        :returns tuple containing the return code, output and error
        """
        if not silent:
            _logger.debug("Enter runShell(cmd=%s, silent=%s)-->" % (cmd, silent))
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        rc = p.wait()
        (out,err) = p.communicate()
        #rc = p.returncode            
        
        if not silent:
            _logger.debug( "cmd=%s\nrc=%s\nout=%s\nerr=%s" % (cmd, rc, out, err))

        return (rc, out, err)
    
def runShellWithoutPipe(cmd, silent=False):
        """Run a shell command but don't throw an exception for a bad return code.
        :param cmd command to run
        :param silent (boolean) Print debug output to stdout? 
        :returns tuple containing the return code, output and error
        """
        _logger.debug("Enter runShell(cmd=%s, silent=%s)-->" % (cmd, silent))
        
        if not silent:
            f = open(LOG_FILENAME, "a+")
            p = subprocess.Popen(cmd, shell=True, stdout=f, stderr=f)            
        else:
            p = subprocess.Popen(cmd, shell=True, stdout=None, stderr=None)
        
        p.communicate()
        rc = p.returncode 
        _logger.debug("Exit runShell(cmd=%s, rc=%s)-->" % (cmd, rc))
                   
        return (rc)  


##############################

def subprocess_execute(command, time_out = 7200):
    """executing the command with a watchdog"""
    # launching the command
    c = subprocess.Popen(command)

    # now waiting for the command to complete
    t = 0
    while t < time_out and c.poll() is None:
        time.sleep(1)  # (comment 1)
        t += 1

    # there are two possibilities for the while to have stopped:
    pid = c.pid
    if c.poll() is None:
        # in the case the process did not complete, we kill it
        _logger.debug('timeout %s, kill the process' % time_out)
        os.system("ps -o pid= --ppid %d | xargs kill -9" % pid)
        c.terminate()
        # and fill the return code with some error value
        returncode = -1  # (comment 2)
    else:
        # in the case the process completed normally
        returncode = c.poll()

    return returncode

def run_cmds(cmdList):
    """
    Take a list of commands and run each of them, checking for output to validate that they ran successfully
    If they fail (RC != 0) rerun, max 4 retries
    """
    for cmd in cmdList:
        i = 0
        suc = False
        while not suc and i < 5:
            out = subprocess.call(cmd, shell=True)
            if out == 0: suc = True
            i = i + 1
        if i == 5:
            print("Command %s Failed" % cmd)
            sys.exit()
            
    return

def downloadFile(url, destination, file):
    if not os.path.exists(destination):
        os.makedirs(destination)
    os.chmod(destination, stat.S_IRWXO)
    os.chdir(destination)
    '''response = requests.get(url, stream=True)
    f = open(os.path.join(destination,file), "wb")
    for data in response.iter_content(chunk_size=512):
        if chunk:  # filter out keep-alive new chunks
            f.write(data)
    f.close()
    '''
    
def extractFile(file, destination):
    '''with zipfile.ZipFile(file,"r") as ref:
        ref.extractall(destination)
    '''
    cmd='tar -zxf %s -C %s' % (file, destination)
    runShell(cmd)
