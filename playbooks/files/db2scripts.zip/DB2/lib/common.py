import util
import os

scriptdir = '/tmp/db2scripts'

def install_dbms(installDir):
    # ref. http://publib.boulder.ibm.com/infocenter/db2luw/v9/topic/com.ibm.db2.udb.uprun.doc/doc/t0023683.htm
    cmd='%s/bin/db2greg -addservrec service=DB2,specialinstallnumber=0' % installDir
    rc, out, err = util.runShell(cmd)
    # ref. http://publib.boulder.ibm.com/infocenter/db2luw/v9r7/topic/com.ibm.db2.luw.admin.cmd.doc/doc/r0023668.html
    cmd='ln -sf %s/install/db2ls /usr/local/bin/db2ls' % installDir
    rc, out, err = util.runShell(cmd)
    return rc


def get_shell():
    cmd='declare >/dev/null 2>&1 && echo bash || echo ksh'
    rc, out, err = util.runShell(cmd)
    return str(out).strip()

def chk_if_bash():
    if get_shell().find('bash'):
        return 0
    else:
        return 1

def chk_if_ksh():
    if get_shell().find('ksh'):
        return 0
    else:
        return 1

def get_os():
    cmd='uname -s |tr A-Z a-z'
    rc, out, err = util.runShell(cmd)
    return str(out).strip()


def get_platform ():
   cmd='uname -m |tr A-Z a-z'
   rc, out, err = util.runShell(cmd)
   return out.strip()

def chk_if_linux ():
    if get_os().find('linux'):
        print("Linux")
        return 0
    else:
        print("not linux")
        return 1

def chk_if_aix ():
    if get_os().find('aix'):
        print("AIX")
        return 0
    else:
        print("non AIX")
        return 1

# linux and aix compatible
def linuaix ():
    if chk_if_bash() == 0:
        cmd='alias awk=\'awk --posix\''
        util.runShell(cmd)

def install_tsamp(arg1, arg2):
    tsampDir='%s/tsamp64' % arg1
    rc=-1
    '''
    if chk_if_linux() == 0:
        cmd='cat /etc/redhat-release |awk -F" " \'{print $7}\''
        rc, out, err = util.runShell(cmd)
        version_info = out.strip()
        if float(version_info) > 7.0:
            tsampDir=os.path.join(arg1,'tsamp64')
        else:
            if arg2 != 1:
                tsampDir=os.path.join(arg1,'tsamp32')
            else: 
                tsampDir=os.path.join(arg1,'tsamp64')
        #for backward compatibility with 1.2.1.0 where
        #we do not have 64 and 32 bit tsamp dirs
        if not os.path.exists(tsampDir):
            tsampDir=os.path.join(arg1,'tsamp')
    else:
        tsampDir=os.path.join(arg1,'tsamp')
        # to fix defect 235183
        # prereqSAM file need to updated
        os.chdir(tsampDir)
        cmd='sed \'s/$GREP -Ev ".*64.*"/$GREP -E "32-bit"/g\' prereqSAM > prereqSAM.an'
        rc, out, err = runShell(cmd)
        cmd='sed \'s/$GREP -Ev ".*64.*"/$GREP -E "32-bit"/g\' installSAM > installSAM.an'
        rc, out, err = runShell(cmd)
        cmd='mv prereqSAM.an prereqSAM'
        rc, out, err = runShell(cmd)
        cmd='mv installSAM.an installSAM' 
        rc, out, err = runShell(cmd) 
        cmd='chmod 555 prereqSAM installSAM'  
        rc, out, err = runShell(cmd)    
    '''
    
    if os.path.exists(tsampDir):
       os.chdir(tsampDir)
       print("current directory is ******* %s" % tsampDir)
       cmd='%s/installSAM --noliccheck --silent' % tsampDir
       rc, out, err = util.runShell(cmd)
    return rc

def openPorts(tcpPorts, udpPorts, openicmp):
    iptableStr='iptables'
    #internal ports
    for port in udpPorts:
        cmdStr = '/sbin/%s -I INPUT -p udp -m udp --dport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I INPUT -p udp -m udp --sport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I OUTPUT -p udp -m udp --sport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I OUTPUT -p udp -m udp --dport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
    
    #external ports
    for port in tcpPorts:
        cmdStr = '/sbin/%s -I INPUT -p tcp -m tcp --dport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I INPUT -p tcp -m tcp --sport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I OUTPUT -p tcp -m tcp --sport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
        cmdStr = '/sbin/%s -I OUTPUT -p tcp -m tcp --dport %s -j ACCEPT' % (iptableStr, port)
        util.runShell(cmdStr)
    
    if openicmp:
        cmdStr = '/sbin/%s -I OUTPUT -p icmp -o tun0 -j ACCEPT' % (iptableStr)
        runShell(cmdStr)
        cmdStr = '/sbin/%s -I INPUT -p icmp -i tun0 -j ACCEPT' % (iptableStr)
        runShell(cmdStr)
    
    util.runShell("/sbin/service %s save" % iptableStr)
    util.runShell("/sbin/service %s restart" % iptableStr) 
    util.runShell("%s --line-numbers -n -L" % iptableStr) 
    
def add_user_with_id(user_name, userID, user_password, group_list, user_type, instance_name, default_user_model):
    print('%s %s %s %s %s %s %s :::'%(user_name, userID, user_password, group_list, user_type, instance_name, default_user_model))
    user_type='OS'
    default_user_model=False
    home_dir='/home/%s' % user_name
    cmd='useradd -m -d %s -u %s %s' % (home_dir, userID, user_name) 
    rc, ot, err= util.runShell(cmd)
    print("out %s  err %s", (ot,err))
    if rc != 0:
        print('Failed while creating OS user')
        return rc
    change_user_pwd(user_name,user_password)
    #if [[ -n ${instance_name} ]] ; then
    #addOSProfile ${instance_name} ${user_name} ${default_user_model}
    if default_user_model:
        cmd='chmod 755 /home/%s' % username
        util.runShell(cmd)
    cmd='id %s' % user_name
    rc,out,err=util.runShell(cmd)
    print("out %s  err %s", (out,err))
    return rc

# linux, aix compatible
def change_user_pwd (user, password):
    rc=2
    if chk_if_ksh():
        cmd='echo "%s:%s" |chpasswd -c' % (user,password)
        rc,out,err=util.runShell(cmd)
    else:
        cmd='echo "%s:%s" |chpasswd' % (user,password)
        rc,out,err=util.runShell(cmd)
    if rc != 0: 
        print("Failed while changing password for user: %s" % user)
    return rc

'''
def addOSProfile (instance_name, user_name, default_user_model):
    #default_user_model=False
    if chk_if_linux() == 0:
    	user_profile="/home/%s/.bash_profile" % user_name
    else:
    	user_profile="/home/%s/.profile" % user_name

    cmd=". /home/%s/sqllib/db2profile" % instance_name
    command='grep -q "%s" "%s"' % (cmd, user_profile)   
    rc, out, err = util.runShell(command)
    if rc!=0 :
    	command='echo "%s" >> "%s"' % (cmd,user_profile)
        rc, out, err = util.runShell(command)
        if rc!=0 :
            print("Failed while updating file "%s"' % user_profile
            return rc
	cmd='id -g %s' % user_name
        rc, out,err = util.runShell(cmd)
        id=out.strip()
    	cmd='chown %s:%s "%s"' % (user_name,id,user_profile)
	rc, out,err = util.runShell(cmd)
    	if default_user_model_user:
        	cmd='chmod 755 /home/%s' % user_name
		runShell(cmd)
    	return 0
'''

def generate_uid ():
    cmd=''
    if chk_if_linux() == 0:
        cmd='getent passwd | awk -F \':\' \'{if($3>=500) print $3}\' | sort -n | awk \'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}\''
    else:
        cmd='lsuser -C ALL | awk -F \':\' \'{if($2>=500 && $2 != "id") print $2}\' | sort -n | awk \'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}\''
    rc,out,err=util.runShell(cmd)
    return (rc,str(out).replace("b","").replace("\n",""))

def generate_gid ():
    cmd=''
    if chk_if_linux() ==0:
        cmd='getent group | awk -F \':\' \'{if($3>=500) print $3}\' | sort -n | awk \'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}\''
    else:
        cmd='lsgroup -C ALL | awk -F \':\' \'{if($2>=500 && $2 != "id") print $2}\' | sort -n | awk \'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}\''
    rc,out,err=util.runShell(cmd)
    return (rc, out.strip())

