#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import logging
import maestro
import os
import sys
import traceback

logger = logging.getLogger("instanceOperation.py")

libdir = os.path.join(maestro.node['scriptdir'], 'DB2', 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
import nls, util
from UserGroupManager import UserGroupManager
from DB2User import DB2User
from DB2_DBMS import DB2_DBMS
from GlobalLock import Lock
import copy

nls.install()

message = ''
returnMsg = ''
rc = False
LOCK_NAME = 'instance_operation_lock'

with Lock(LOCK_NAME):

    try:
        inst_name = maestro.parms['instanceOwner']
        op_parms = maestro.operation['parms']
        operation_action = maestro.operation['method']

        vmTemplateID = util.getRoleName()
        jsonFileName = '%s_%s_instance_profile.json' % (vmTemplateID, inst_name)
        user_group_manager = UserGroupManager(jsonFileName, logger, inst_name)
        #===========================================Actions========================================#
        # createUser | deleteUser | resetPassword | updateSSHAccess | updateDB2Fixpack             #
        #==========================================================================================#

        #===========================================createUser========================================#
        if operation_action == 'createUser':
            user_name = op_parms['userName']
            logger.debug('Creating a new user: ''%s''' % (user_name))
            if op_parms['sshAccess'] == "Allow":
                ssh_access = True
            else:
                ssh_access = False
            encodedpassword = op_parms['password']
            user_password = maestro.decode(encodedpassword)
            if op_parms.has_key('authLevel'):
                group_name = op_parms['authLevel']
            else:
                group_name = []
            if 'sysControlGroupName' in maestro.parms:
                sysctrl_group_name=maestro.parms['sysControlGroupName']
                
            else:
                sysctrl_group_name=""   
            if 'sysMaintGroupName' in maestro.parms:
               sysmnt_group_name=maestro.parms['sysMaintGroupName']
                  
            else:
                sysmnt_group_name =""  
            if 'sysMonGroupName' in maestro.parms:
               sysmon_group_name=maestro.parms['sysMonGroupName']
               
            else:
                sysmon_group_name=""
            auth_level="['SYSADM'"
            def_group="[maestro.parms['instanceOwnerGroup']"
            if(sysctrl_group_name!=""):
                auth_level=auth_level+",'SYSCTRL'"
                def_group=def_group+",sysctrl_group_name"
            if(sysmnt_group_name!=""):
                auth_level=auth_level+",'SYSMAINT'"
                def_group=def_group+",sysmnt_group_name"
            if(sysmon_group_name!=""):
                auth_level=auth_level+",'SYSMON'"
                def_group=def_group+",sysmon_group_name"
            auth_level=auth_level+"]"
            def_group=def_group+"]" 
            logger.debug('auth_level'+auth_level)
            logger.debug('def_group'+def_group)   
            
            #===========Code changes for RFE 128497 Ends==============#
            _groups = []
            _permission = []
            if len(group_name) > 0:
                for i in range(len(group_name)):
                    if group_name[i] in auth_level:
                        index = auth_level.index(group_name[i])
                        _groups.append(def_group[index])
                        _permission.append(group_name[i])
            newUser = DB2User(userName = user_name, \
                              password = user_password, \
                              sshAccess = ssh_access, \
                              groups = _groups, \
                              permission = _permission, \
                              instanceName = inst_name)
            rc, message = user_group_manager.addUser(newUser)
            logger.debug(message)
            if rc:
                returnMsg = "Successfully create new user %s" % (user_name)
            else:
                returnMsg = "Failed to create new user %s" % (user_name)
        #===========================================updateSSHAccess========================================#
        elif operation_action == 'updateSSHAccess':
            user_name = op_parms['userName']
            logger.debug('Updating SSH Access for user: ''%s''' % (user_name))
            if op_parms['sshAccess'] == "Allow":
                ssh_access = True
            else:
                ssh_access = False
            user = user_group_manager.getUserByName(user_name)
            if user is None or user == '':
                user = DB2User(userName = user_name, sshAccess = ssh_access)
            user.setSshAllow(ssh_access)
            rc, message = user_group_manager.updateSSHAccess(user_name, ssh_access)
            logger.debug(message)
            if rc:
                #returnMsg = nls.msg('2110I', user_name)
                returnMsg = "Successfully updated user '%s'" % (user_name)
            else:
                #returnMsg = nls.msg('2111E', user_name)
                returnMsg = "Failed to update user '%s'" % (user_name)
        #===========================================deleteUser========================================#
        elif operation_action == 'deleteUser':
            user_name = op_parms['userName']
            logger.debug('Deleting user: ''%s''' % (user_name))
            if user_group_manager.users.has_key(user_name):
                rc, message = user_group_manager.removeUser(user_name)
                logger.debug(message)
                if rc:
                    #returnMsg = nls.msg('2112I', user_name)
                    returnMsg = "Successfully deleted the user: '%s'" % (user_name)
                else:
                    #returnMsg = nls.msg('2113E', user_name)
                    returnMsg = "Failed to delete the user: '%s'" % (user_name)
            else:
                rc = False
                #returnMsg = nls.msg('2114E', user_name)
                returnMsg = "Failed to delete the user '%s' because that user does not exist in the system" % (user_name)
        #===========================================resetPassword========================================#
        elif operation_action == 'resetPassword':
            user_name = op_parms['userName']
            encodedpassword = op_parms['newPassword']
            user_password = maestro.decode(encodedpassword)
            rc, message = user_group_manager.resetUserPassword(user_name, user_password)
            logger.debug(message)
            if rc:
                #returnMsg = nls.msg('2115I', user_name)
                returnMsg = "Successfully reset password for user '%s'" % (user_name)
                #export new password
                user = user_group_manager.getUserByName(user_name)
                if user.is_database_admin() or user.is_instance_admin():
                    need_export = False
                    if 'DATABASES' in maestro.export:
                        databases = copy.deepcopy(maestro.export['DATABASES'])
                        for db in user.getconsumers():
                            if db in databases['databases'] and databases['databases'][db]['database_user'] == user_name:
                                databases['databases'][db]['database_user_password'] = encodedpassword
                                databases['databases'][db]['Action'] = 'ChangePassword'
                                need_export = True
                    if need_export:
                        maestro.export['DATABASES'] = databases
            else:
                #returnMsg = nls.msg('2116E', user_name)
                returnMsg = "Failed to reset password for user '%s'" % (user_name)
        #===========================================updateDB2Fixpack========================================#            
        elif operation_action == 'updateDB2Fixpack':
            if 'databaseFixpack' in op_parms and op_parms['databaseFixpack'] != 'default_db2_image':
                fixpack_version = util.parse_fixPack_version(op_parms['databaseFixpack'])
                db2_major_version = util.get_db2_version(fixpack_version)
                dbms = DB2_DBMS()
                fixpackPath = op_parms['databaseFixpack']
                rc, message = dbms.upgrade(fixpackPath)
                logger.debug(message)
                if rc:
                    returnMsg = "Successfully upgrade db2 fixpack to the latest version: '%s'" % (fixpack_version)
                else:
                    returnMsg = "Failed to upgrade db2 fixpack to version: '%s'" % (fixpack_version)
            else:
                returnMsg = 'Missed the fixpack'  
    except:
        traceback.print_exc()
        #returnMsg = nls.msg('2121E')
        rc = False
        returnMsg = 'Failed because of unknown Exception'
    finally:
        maestro.operation['successful'] = rc
        maestro.operation['return_value'] = returnMsg
