#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import logging
import maestro
import os
import sys

logger = logging.getLogger("DB2/stop.py")

scriptdir = maestro.node['scriptdir']
basedir = os.path.join(scriptdir, 'DB2')
libdir = os.path.join(basedir, 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
if not basedir in sys.path:
    sys.path.append(basedir)

import util
from DB2_Instance import DB2_Instance
from DatabaseForSystemWorkload import DatabaseForSystemWorkload

def _exec_handlers(handlers_dir):
    if os.path.exists(handlers_dir):
        for f in os.listdir(handlers_dir):
            if f.endswith('.py') and os.path.isfile(os.path.join(handlers_dir, f)) and f != '__init__.py':
                idx = f.rfind('.py')
                module_name = f[0:idx]
                __import__(module_name)
                
if maestro.isDestroy():
    before_destroy_handlers_dir = scriptdir + '/DB2/before_destroy_handlers'
    if not before_destroy_handlers_dir in sys.path:
        sys.path.append(before_destroy_handlers_dir)
    _exec_handlers(before_destroy_handlers_dir)

inst_name = maestro.parms['instanceOwner']
inst_agent = DB2_Instance(inst_name)
# check db2 instance is stopped
db2instance_online = util.trace_shell_func_call('chk_if_instance_alive', inst_name)
if db2instance_online == 0:
    inst_agent.stop()
else:
    logger.debug('db2 instance is stopped')

#backuo export info
if 'DATABASES' in maestro.export:
    logger.debug("DATABASES in maestro.export")
    import json
    export_json_file = "/tmp/export_json_file.json"
    with open(export_json_file, 'w') as f:
        json.dump(maestro.export['DATABASES'], f, sort_keys = True, indent = 4)
        f.flush()
    maestro.storage.backup(export_json_file)
else:
    logger.debug("no DATABASES in maestro.export")

logger.debug("DB2/stop.py done")
