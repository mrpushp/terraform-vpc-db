#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

. "$(dirname "$0")"/common.sh
func=$1
shift

funcnames=$(list_funcname)
check_status $? "Failed to get function list."

echo "${funcnames}" |grep -q "^${func}$"
check_status $? "Not found the function: ${func}"

# execute the function
${func} "$@"
exit $?
