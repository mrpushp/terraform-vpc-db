#!/bin/sh

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
user=$1
group=$2
ssh_dir=$3
private_key_dir=$4

if [ -f ~/.agent.env ]; then
        . ~/.agent.env >/dev/null
        if ! kill -0 $SSH_AGENT_PID >/dev/null 2>&1; then
                echo "Stale agent file found. Spawning new agent..."
                eval `ssh-agent |tee ~/.agent.env`
        fi
else
        echo "Starting ssh-agent..."
        eval `ssh-agent |tee ~/.agent.env`
fi

if [[ ! -d ${private_key_dir} ]] ; then
    ssh-add ${private_key_dir}
else
	for private_key in `ls ${private_key_dir}/id_rsa* | awk '$1 !~ /.pub$/'`
	do
	    ssh-add ${private_key}
	done
fi

OSNAME=$(uname)
if [ "${OSNAME}" == "Linux" ]; then
	user_profile=${HOME}/.bash_profile
elif [ "${OSNAME}" == "AIX" ] ; then
	if [ "${user}" == "root" ]; then
		user_profile=/.profile
	else
		user_profile=${HOME}/.profile
	fi
fi

if ! grep -q 'if [ -f ~/.agent.env ]; then' ${user_profile}; then
	echo 'if [ -f ~/.agent.env ]; then' >>${user_profile}
	echo '        . ~/.agent.env >/dev/null' >>${user_profile}
	echo '        if ! kill -0 $SSH_AGENT_PID >/dev/null 2>&1; then' >>${user_profile}
	echo '                eval `ssh-agent |tee ~/.agent.env` >/dev/null 2>&1' >>${user_profile}               
	echo "				for private_key in \`ls ${ssh_dir}/id_rsa* | awk '"'$1 !~ /.pub$/'"'\`" >>${user_profile}
	echo '				do'  >>${user_profile}
	echo '				    ssh-add ${private_key} >/dev/null 2>&1'  >>${user_profile}
	echo '				done' >>${user_profile}
	echo '        fi' >>${user_profile}
	echo 'else' >>${user_profile}
	echo '        eval `ssh-agent |tee ~/.agent.env` >/dev/null 2>&1' >>${user_profile}        
	echo "				for private_key in \`ls ${ssh_dir}/id_rsa* | awk '"'$1 !~ /.pub$/'"'\`" >>${user_profile}
	echo '		  do' >>${user_profile}
	echo '		        ssh-add ${private_key} >/dev/null 2>&1' >>${user_profile}
	echo '		  done' >>${user_profile}
	echo 'fi' >>${user_profile}
fi
