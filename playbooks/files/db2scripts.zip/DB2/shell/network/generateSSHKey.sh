#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

OS=`uname`
key_file_name=${1:?}
echo "the key file name is "$key_file_name
if [ "${OS}" = "Linux" ] ; then
	#****************** Generate id file on local machine*****
	expect -c "
	spawn ssh-keygen -t rsa -f \"/root/.ssh/$key_file_name\"
	while {1} {
	expect {
	
	                eof                                                             {break}
	                \"Overwrite (y/n)? \"                                             {send \"y\r\"}
	                \"Enter passphrase (empty for no passphrase): \"                  {send \"\r\"}
	                \"Enter same passphrase again: \"                                 {send \"\r\"}
	                \"Are you sure you want to continue connecting (yes/no)? \"       {send \"\r\"}
	        }
	}
	"
	#*********************************************************
elif [ "${OS}" = "AIX" ] ; then
	#****************** Generate id file on local machine*****
	expect -c "
	spawn ssh-keygen -t rsa  -f \"/.ssh/$key_file_name\"
	while {1} {
	expect {
	
	                eof                                                             {break}
	                \"Overwrite (y/n)? \"                                             {send \"y\r\"}
	                \"Enter passphrase (empty for no passphrase): \"                  {send \"\r\"}
	                \"Enter same passphrase again: \"                                 {send \"\r\"}
	                \"Are you sure you want to continue connecting (yes/no)? \"       {send \"\r\"}
	        }
	}
	"
	#*********************************************************
fi
