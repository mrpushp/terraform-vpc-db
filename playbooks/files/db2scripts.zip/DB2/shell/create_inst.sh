#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

. "$(dirname "$0")"/common.sh
echo "ANSHU start"
logger_begin
#echo "Params: $*" | pipe_mask_after inst_password= | pipe_mask_after fencedUserPassword=
echo "Params: $*" | pipe_mask_after inst_password= | pipe_mask_after fencedUserPassword=

# Executed by root

usage ()
{
    echo "Usage:"
    echo "$0"
    echo "    inst_name=INST_NAME inst_type=INST_TYPE inst_port=PORT 'inst_password=\"INST_PASSWORD\"'"
    echo "    sysadm_group=db2iadm1 db2fadm_group=db2fadm1 dbms_home=DBMS_HOME [sqltype=SQLTYPE] [db2_workload=DB2_WORKLOAD]"
    return 0
}

eval export "$@"
check_status $? "Failed while setting provision variables"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${dbms_home}/lib64
chmod 777 /tmp
if chk_if_instance_exist "${inst_name}"; then
    echo "The instance already exist"
    exit 0
fi

echo "Creating groups for DB2"
sysadm_group=${sysadm_group:-'db2iadm1'}
db2fadm_group=${db2fadm_group:-'db2fadm1'}

echo "Creating groups for DB2 System-level authorization"
#===========Code changes for RFE 128497 ==============#
sysctrl_group=${sysctrl_group_name}
sysmaint_group=${sysmnt_group_name}
sysmon_group=${sysmon_group_name}
sysctrl_group_id=${sysctrl_group_id}
sysmaint_group_id=${sysmnt_group_id}
sysmon_group_id=${sysmon_group_id}
#===========Code changes for RFE 128497 Ends==============#
set_ssh_denygroup ${NONSSH_GROUP} || exit $?

add_group ${sysadm_group} || exit $?
add_group ${db2fadm_group} || exit $?

#===========Code changes for RFE 128497==============#
echo "sysctrl_group> ${sysctrl_group_name} sysctrl_group_id> ${sysctrl_group_id} "
if  [[(${sysctrl_group} != "") && (${sysctrl_group_id} != "")]]; then
add_group ${sysctrl_group} ${sysctrl_group_id} || exit $?   ## Group of SYSCTRL
elif [[(${sysctrl_group} != "")]]; then
add_group ${sysctrl_group} || exit $?   ## Group of SYSCTRL	
fi
if  [[(${sysmaint_group} != "") && (${sysmaint_group_id} != "")]]; then
add_group ${sysmaint_group} ${sysmaint_group_id} || exit $?	  ## Group of SYSMAINT
elif [[(${sysmaint_group} != "")]]; then
add_group ${sysmaint_group}  || exit $?  ## Group of SYSMAINT
fi
if [[(${sysmon_group} != "") && (${sysmon_group_id} != "")]]; then
add_group ${sysmon_group} ${sysmon_group_id} || exit $? ## Group of SYSMON
elif [[(${sysmon_group} != "")]]; then
add_group ${sysmon_group}  || exit $?  ## Group of SYSMON
fi
#===========Code changes for RFE 128497 Ends==============#

echo "Creating users for DB2"
db2fenc=${db2fenc:-'db2fenc1'}
fencedUserPassword=${fencedUserPassword:-${inst_password}}
add_user "${inst_name}" "${inst_password}" ${sysadm_group} || exit $?
add_user ${db2fenc} "${fencedUserPassword}" ${db2fadm_group} || exit $?

mkdir /home/${inst_name}
chown -R ${inst_name}:${sysadm_group} /home/${inst_name}

if chk_if_bash; then
    cp -a /etc/skel/.bash* /home/"${inst_name}" || exit $?
    chown "${inst_name}":${sysadm_group} /home/"${inst_name}"/.bash* || exit $?
elif chk_if_ksh; then
    touch /home/"${inst_name}"/.profile || exit $?
    chown "${inst_name}":${sysadm_group} /home/"${inst_name}"/.profile || exit $?
fi

config_db2_client_for_user ${inst_name} ${inst_name}

echo "Creating DB2 instance"
${dbms_home}/instance/db2icrt -a server -u ${db2fenc} -s $(lower ${inst_type}) -p ${inst_port} "${inst_name}"
check_status $? 'Failed while executing db2icrt'

echo "Configuring system services file"
service_name="db2c_${inst_name}"
echo "${service_name}  ${inst_port}/tcp # DB2 connection service port" >> /etc/services
cmd="UPDATE DBM CFG USING svcename ${service_name} spm_name NULL"
su - "${inst_name}" -c "db2 -v ${cmd}"
echo $?

echo "Assign system-level authorization groups"
#===========Code changes for RFE 128497 ==============#
if  [[(${sysctrl_group} != "") && (${sysmaint_group} != "") && (${sysmon_group} != "")]]; then
cmd="UPDATE DBM CFG USING SYSADM_GROUP ${sysadm_group} SYSCTRL_GROUP ${sysctrl_group} SYSMAINT_GROUP ${sysmaint_group} SYSMON_GROUP ${sysmon_group}"
elif [[(${sysctrl_group} != "") && (${sysmaint_group} != "") && (${sysmon_group} == "")]]; then
cmd="UPDATE DBM CFG USING SYSADM_GROUP ${sysadm_group} SYSCTRL_GROUP ${sysctrl_group} SYSMAINT_GROUP ${sysmaint_group}"
elif [[(${sysctrl_group} != "") && (${sysmaint_group} == "") && (${sysmon_group} == "")]]; then
cmd="UPDATE DBM CFG USING SYSADM_GROUP ${sysadm_group} SYSCTRL_GROUP ${sysctrl_group}"
elif [[(${sysctrl_group} == "") && (${sysmaint_group} == "") && (${sysmon_group} == "")]]; then
cmd="UPDATE DBM CFG USING SYSADM_GROUP ${sysadm_group}"
fi
#===========Code changes for RFE 128497 Ends==============#
su - "${inst_name}" -c "db2 -v ${cmd}"
echo $?

echo "Configuring DB2 instance"
su - "${inst_name}" -c 'db2set DB2COMM=tcpip'
check_status $? 'Failed while executing db2set'

###Changes for RFE 128506 - Expose or set DB2_parallel_IO
### Added db2_parallel_io as argument

if [ ! -z "${db2_parallel_io}" ]; then
   if [ "${db2_parallel_io}"=="*" ]; then
      echo "Configuring DB2_PARALLEL_IO"
      echo "Value of db2_parallel_io = ${db2_parallel_io}"
      su - "${inst_name}" -c "db2set DB2_PARALLEL_IO=${db2_parallel_io}"
      check_status $? 'Failed while Configuring DB2_PARALLEL_IO'
   else
      if [ "${db2_parallel_io}"==""]; then
         echo "DB2_PARALLEL_IO is set to null inside if. This value will not be set."
      elif [ "${db2_parallel_io}" -gt 0 ]; then
         echo "Configuring DB2_PARALLEL_IO"
         echo "Value of db2_parallel_io = ${db2_parallel_io}"
         su - "${inst_name}" -c "db2set DB2_PARALLEL_IO=${db2_parallel_io}"
         check_status $? 'Failed while Configuring DB2_PARALLEL_IO'
      else
         echo "DB2_PARALLEL_IO is set to null inside else. This value will not be set."   
      fi
   fi
else
   echo "DB2_PARALLEL_IO is set to null. This value will not be set."
fi

case $(upper "${sqltype}") in
    ORACLE)
     echo "db2set DB2_COMPATIBILITY_VECTOR=ORA DB2_DEFERRED_PREPARE_SEMANTICS=YES"
     su - "${inst_name}" -c 'db2set DB2_COMPATIBILITY_VECTOR=ORA; db2set DB2_DEFERRED_PREPARE_SEMANTICS=YES'

     echo "DB2_COMPATIBILITY_VECTOR return code: $?"
     ;;
esac

echo "list dbset"
su - ${inst_name} -c 'db2set -all'

echo "list dbm cfg"
su - ${inst_name} -c 'db2 get dbm cfg'

restart_instance "${inst_name}" || exit $?

enable_auto_instance "${inst_name}" || exit $?
enable_instance_fm "${inst_name}" || exit $?

if ! chk_if_instance_alive "${inst_name}" ; then
    start_instance "${inst_name}" || exit $?
fi

echo 'export DB2NODE=0'>>/etc/profile
. /etc/profile

logger_end
exit 0

