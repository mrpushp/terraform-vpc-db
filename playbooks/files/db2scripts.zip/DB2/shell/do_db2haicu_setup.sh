#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

# Note: Declared both in do_hadr_setup.sh and in ConfigDB2.sh

export DB2_SCRIPTS_PATH=`echo $(cd $(dirname $0); pwd)`
export DB2_SCRIPTS_LOG_PATH="$DB2_SCRIPTS_PATH/log"

OS=`uname`
if [ "${OS}" = "Linux" ] ; then
	. ${HOME}/.bash_profile
elif [ "${OS}" = "AIX" ] ; then
	. ${HOME}/.profile
fi

echo "######################################"
echo "do_db2haicu_setup.sh $@"
echo "######################################"
parse_args="$DB2_SCRIPTS_PATH/hadr/parse_arguments.sh"

hadr_type=`             $parse_args hadr_type             STANDBY     $@`
hadr_database=`         $parse_args hadr_database         SAMPLE      $@`
primary_db2_instance=`  $parse_args primary_db2_instance  db2inst1    $@`
standby_db2_instance=`  $parse_args standby_db2_instance  db2inst1    $@`
primary_private_ip=`    $parse_args primary_private_ip   127.0.0.1    $@`
primary_ip=`    		$parse_args primary_public_ip   127.0.0.1    $@`
standby_private_ip=`    $parse_args standby_private_ip   127.0.0.1    $@`
secondary_ip=`    		$parse_args standby_public_ip   127.0.0.1    $@`
load_type=`    		    $parse_args load_type   		INIT    	  $@`
virtual_ip=`			$parse_args virtual_ip			notdefined    $@`
crit_rsrc_prot_method=` $parse_args crit_rsrc_prot_method 3           $@`  

if [ "$hadr_type" != "PRIMARY" ]; then
  echo "This is not the PRIMARY machine. Exiting."
  exit 1
else
  echo "This is the PRIMARY machine. Proceeding."
fi

#echo "######################################"
#echo "Cleaning up cluster information so that each VM will have a unique internal identifier"
#echo "######################################"
#/usr/sbin/rsct/install/bin/recfgct -n
#echo

# Setting up Haicu
echo "######################################"
echo "Getting primary hostname for haicu"
echo "######################################"
primary_hostname=`su - $primary_db2_instance -c "export LANG=C;db2 get db cfg for $hadr_database" | grep -i HADR_LOCAL_HOST | awk '{print $NF}'`
echo $primary_hostname
if [[ -z "$primary_hostname" ]]; then
	echo "Error: Empty primary hostname"
	exit 1
else
	echo "Primary hostname: $primary_hostname"
fi

primary_hostname_short=`echo $primary_hostname | tr '.' ' ' | awk '{ print $1; }'`
echo "Primary hostname short: $primary_hostname_short"

echo "######################################"
echo "Getting primary ip for haicu"
echo "######################################"

echo ${primary_ip} | grep ":" > /dev/null
if [ 0 -eq $? ]; then
	IPV6='TRUE'
	echo "IPv6 support is enabled"
else
	IPV6='FALSE'
fi

ip_address_validate ()
{
    local _ip=$1
    local rc=0
    
    echo "Validating ip address -> ${_ip}"
    if [[ -z "$_ip" ]]; then
	    echo "Error: Empty IP address!"
	    exit 1
	fi
    if [ "${IPV6}" = "TRUE" ] ; then
    	echo ${_ip} |grep ":" > /dev/null
		rc=$?
		if [ $rc = 1 ]; then
			echo "Invalidate IP address: "${_ip}". Exit..."
			exit 1
		else
			OS=`uname`
			if [ "${OS}" = "Linux" ] ; then
				ping6 -q -c4 "${_ip}"
			elif [ "${OS}" = "AIX" ] ; then
				ping -q -c4 "${_ip}"
			fi
			if [ $? -eq 1 ]; then
			    echo "Bad floatingIP ${_ip}. Address is not pingable."
			    exit 1
			fi
		fi
    else
		echo ${_ip} |grep "^[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}$" > /dev/null
		rc=$?
		if [ $rc = 1 ]; then
		   echo "Invalidate IP address: "${_ip}". Exit..."
		   exit 1
		else
			ping -q -c4 "${_ip}"
			if [ $? -eq 1 ]; then
				echo "Bad floatingIP ${_ip}. Address is not pingable."
				exit 1
			fi
		fi
	fi
	return $rc
}

echo "Primary IP: ${primary_ip}"
#Validate primary IP address
ip_address_validate ${primary_ip}

echo "######################################"
echo "Getting secondary hostname for haicu"
echo "######################################"
secondary_hostname=`su - $primary_db2_instance -c "export LANG=C;db2 get db cfg for $hadr_database" | grep -i HADR_REMOTE_HOST | awk '{print $NF}'`
if [[ -z "$secondary_hostname" ]]; then
		echo "Error: Empty secondary hostname"
		exit 1
else
  	echo "Secondary hostname: $secondary_hostname"
fi

secondary_hostname_short=`echo $secondary_hostname | tr '.' ' ' | awk '{ print $1; }'`
echo "Secondary hostname short: $secondary_hostname_short"

echo "######################################"
echo "Getting secondary ip for haicu"
echo "######################################"
echo "Secondary IP: ${secondary_ip}"
#validate secondary IP address
ip_address_validate ${secondary_ip}

echo "######################################"
echo "Getting public interface name"
echo "######################################"
ip=$(echo ${primary_ip} | sed -e 's/^000?/0?/g;s/^00*//g;s/:00*/:/g;s/:::/::/g')

public_interface=$(for nic in $(ifconfig -a | grep -i -E "flags|Link encap" | awk 'BEGIN{FS="[ :]"}{print $1}'); do ifconfig $nic | grep -q -i $ip && mynic=$nic; done; echo $mynic)
echo "Public interface name: $public_interface"

echo "######################################"
echo "Getting gateway ip for use as quorum device"
echo "######################################"
OS=`uname`
if [ "${OS}" = "Linux" ] ; then
	route -n
	if [ "${IPV6}" = "TRUE" ] ; then
		gateway_ip=`ip -6 route show dev ${public_interface} | grep -i "default" | head -n1 | awk '{print $3}'`
	else
		gateway_ip=`ip route show dev ${public_interface} | grep -i "default" | head -n1 | awk '{print $3}'`
	fi
elif [ "${OS}" = "AIX" ] ; then
	gateway_ip=`netstat -rn | grep ${public_interface} | grep -i "default" | awk '{print $2}'`
	#gateway_ip=`lsconf | grep Gateway: | awk '{ print $2; }'`
fi
echo "Gateway IP: $gateway_ip"
# validate gateway IP address
ip_address_validate $gateway_ip


echo "######################################"
echo "Getting public subnet mask name"
echo "######################################"
OS=`uname`
if [ "${OS}" = "Linux" ] ; then
	public_subnetMask=`netstat -ie | grep -B1 "$primary_ip" | tail -n1 | awk '{print $4}' | awk -F: '{print $2}'`
	echo $public_subnetMask |grep "^[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}$" > /dev/null
	rc=$?
	if [ $rc = 1 ]; then
		#RHEL7 output does not have : labels
		public_subnetMask=`netstat -ie | grep -B1 "$primary_ip" | tail -n1 | awk '{print $4}'`
	fi
elif [ "${OS}" = "AIX" ] ; then
	public_subnetMask=`lsattr -E -a netmask -l $public_interface -F value`
fi

if [ "${IPV6}" = "TRUE" ] ; then
	echo "Warning: set public subnet mask name as NULL when IPv6 enabled."
	public_subnetMask="NULL"
else
	echo $public_subnetMask |grep "^[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}$" > /dev/null
	rc=$?
	if [ $rc = 1 ]; then
	   echo "Fail to get public sub netmask. Exit..."
	   exit 1
	fi
fi
echo "Public subnet mask: $public_subnetMask"

if [[ -e "/etc/db2vip.conf" ]]; then
echo "######################################"
echo "Getting IP and subnet mask for Virtual IP"
echo "######################################"

echo ${virtual_ip} | grep ":" > /dev/null
if [ 0 -eq $? ]; then
	echo "IPv6 IP,So setting NETMASK to null"
	virtual_ip_netmask="NULL"
fi

echo "Virtual IP : $virtual_ip"

echo "######################################"
echo "Running haicu setup with VIP"
echo "######################################"
chmod 755 "$DB2_SCRIPTS_PATH/hadr/haicuVIPSetup.pl"
set -x
"$DB2_SCRIPTS_PATH/hadr/haicuVIPSetup.pl" -n $hadr_database \
			-i $primary_db2_instance -r $standby_db2_instance \
			-a $primary_ip -b $primary_hostname_short \
			-c $secondary_ip -d $secondary_hostname_short \
			-e $gateway_ip -f $public_interface \
			-g $public_subnetMask -h $primary_private_ip \
			-k $standby_private_ip -l $load_type \
			-w $virtual_ip -s $crit_rsrc_prot_method
echo

if [[ "$load_type" = "RELOAD" && "$virtual_ip" != "notdefined" ]];then
echo "Configuring DB: $hadr_database with Virtual IP: $virtual_ip using db2haicu"
flatfile="/tmp/${hadr_database}_flatfile"
output="/tmp/db2haicu_${hadr_database}.out"
cat >> $flatfile <<EOF
4
1
$hadr_database
$virtual_ip
$public_subnetMask
1
2
2
EOF
cmd="db2haicu < $flatfile >> $output"
echo $cmd
success=`su - $primary_db2_instance -c "$cmd"|grep -i successful`
echo $success
fi
set -
echo "######################################"
echo "Done running haicu setup with VIP"
echo "######################################"
echo

echo "######################################"
echo "Set Critical Resource Protection Method (CritRsrcProtMethod) "
echo "######################################"
echo

## For VIP setup we need to export CT_MANAGEMENT_SCOPE variable before changing CritRsrcProtMethod based on technote: https://www-01.ibm.com/support/docview.wss?uid=swg21572667 
export CT_MANAGEMENT_SCOPE=2; chrsrc -c IBM.PeerNode CritRsrcProtMethod=$crit_rsrc_prot_method

else
echo "######################################"
echo "Running haicu setup without VIP"
echo "######################################"
chmod 755 "$DB2_SCRIPTS_PATH/hadr/haicuSetup.pl"
set -x
"$DB2_SCRIPTS_PATH/hadr/haicuSetup.pl" -n $hadr_database \
			-i $primary_db2_instance -r $standby_db2_instance \
			-a $primary_ip -b $primary_hostname_short \
			-c $secondary_ip -d $secondary_hostname_short \
			-e $gateway_ip -f $public_interface \
			-g $public_subnetMask -h $primary_private_ip \
			-k $standby_private_ip -l $load_type -s $crit_rsrc_prot_method
set -
echo

echo "######################################"
echo "Done running haicu setup without VIP"
echo "######################################"

echo "######################################"
echo "Set Critical Resource Protection Method (CritRsrcProtMethod) "
echo "######################################"
echo
## we need to export CT_MANAGEMENT_SCOPE variable before changing CritRsrcProtMethod in some cases, based on technote: https://www-01.ibm.com/support/docview.wss?uid=swg21572667
export CT_MANAGEMENT_SCOPE=2; chrsrc -c IBM.PeerNode CritRsrcProtMethod=$crit_rsrc_prot_method
fi

echo
echo "######################################"
echo "Displaying HA cluster status"
echo "######################################"
lssam
echo

echo "######################################"
echo "Displaying rpnode status"
echo "######################################"
lsrpnode -Q
echo

echo "######################################"
echo "Displaying operation Quorum"
echo "######################################"
lsrsrc -c IBM.PeerNode OpQuorumTieBreaker
echo

echo "######################################"
echo "Displaying Virtual ip's from cluster"
echo "######################################"
lsrg -m|grep db2ip
echo
