#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
# output: bash|ksh
# compatible: bash, ksh88, ksh93
get_shell ()
{
    declare >/dev/null 2>&1 && echo bash || echo ksh
    return 0
}

chk_if_bash ()
{
    [[ $(get_shell) == 'bash' ]]
    return $?
}

chk_if_ksh ()
{
    [[ $(get_shell) == 'ksh' ]]
    return $?
}

get_os ()
{
    uname -s |tr A-Z a-z
    return $?
}

get_platform ()
{
   uname -m |tr A-Z a-z
   return $?
}


chk_if_linux ()
{
    [[ $(get_os) == 'linux' ]]
    return $?
}

chk_if_aix ()
{
    [[ $(get_os) == 'aix' ]]
    return $?
}

# linux and aix compatible
linuaix ()
{
    if chk_if_bash; then
        alias awk='awk --posix'
    fi
}

# must be executed before any other function definition
linuaix

check_status ()
{
    local status=$1
    local message=$2

    if [[ ! ${status} -eq "0" ]] ; then
        logger_error "${message}. Return Code: ${status}"
        exit "${status}"
    fi
}

# Usage:
#     foo <return_code> <file> [...]
# e.g.
#     foo $? /tmp/file 'my_return_value1' 'my_return_value2'
check_succ ()
{
    local rc=${1:?}
    local file=${2:?}
    shift 2

    if [[ ${rc} -eq 0 ]] ; then
        local val vals
        for val in "$@"; do
            vals="${vals}, '${val}'"
        done
        echo "[ $(echo "${vals}" |cut -c3-) ]" > "${file}"
        exit ${rc}
    fi
    return 0
}

check_sqltype()
{
    su - "${1:?}" -c 'db2set |grep "DB2_COMPATIBILITY_VECTOR=ORA"' >/dev/null 2>&1
    return $?
}

# Usage:
#     foo <return_code> <file> <db2_code> <db2_reason_code> [dbaas_code [tokens]]
# e.g.
#     foo $? /tmp/file SQL3022N ""
#     foo $? /tmp/file "" "" DBS1002W
#     foo $? /tmp/file "" "" DBS1101N mydb
check_fail ()
{
    local rc=${1:?}
    local file=${2:?}
    local sqlcode=$3
    local reasoncode=$4
    local dbaascode=$5
    local tokens
    if [[ $# -gt 5 ]] ; then
        shift 5
        tokens="$@"
    fi

    if [[ ${rc} -ne 0 ]] ; then
        local db2_error="'${sqlcode}', '${reasoncode}'"
        local dbaas_error="'${dbaascode}'"
        if [[ -n ${tokens} ]] ; then
            local token
            for token in "${tokens}"; do
                dbaas_error="${dbaas_error}, '${token}'"
            done
        fi
        echo "[ [ ${db2_error} ], [ ${dbaas_error} ] ]" > "${file}"
        exit ${rc}
    fi
    return 0
}

timestamp ()
{
    date '+%m/%d/%Y %H:%M:%S' |cut -c 1-19
    return 0
}

logger ()
{
    printf "[$(timestamp)] $*\n"
    return 0
}

logger_begin ()
{
    logger "Start: $0"
    return 0
}

logger_end ()
{
    logger "  End: $0"
    return 0
}

logger_info ()
{
    logger " INFO: $*"
    return 0
}

logger_warning ()
{
    logger " WARN: $*"
    return 0
}

logger_error ()
{
    logger "ERROR: $*"
    return 0
}

# Description:
#   This function let you be able to use getopts in this way: -a v1 v2 v3 -b v1
#   It will set array OPTARG=(v1 v2 v3) for -a
#   Only works within getopts context
# Usage:
#   foo ${OPTIND} "$@"; v=("${OPTARG[@]}")
get_extra_optarg ()
{
    local optind=${1:?}
    local i tmpvar opt

    # clean array except the first element set by getopts
    tmpvar=${OPTARG[0]}
    unset OPTARG
    OPTARG[0]=${tmpvar}

    # wrong usage
    [[ -z ${optind} ]] && return 1

    i=1
    # if the next is not an option, then append it to array
    while [[ ${optind} -le $# ]]; do
        eval opt=\${${optind}}
        if [[ $(echo "${opt}" |cut -c1) == '-' ]]; then
            break
        fi
        OPTARG[${i}]=${opt} || return $?
        i=$((i+1))
        optind=$((optind+1))
    done
    return 0
}

upper ()
{
    echo "$*" |tr a-z A-Z
    return $?
}

lower ()
{
    echo "$*" |tr A-Z a-z
    return $?
}

trim ()
{
    echo "$*" |pipe_trim
    return $?
}

pipe_trim ()
{
    cat |awk -v regx="(^[\t ]*|[\t ]*$)" -v repl="" '{gsub(regx, repl); print}'
    return $?
}

pipe_mask ()
{
    if [[ -n $1 ]] ; then
        cat |awk -v regx=$1 -v repl="********" '{gsub(regx, repl); print}'
    else
        cat
    fi
    return $?
}

pipe_mask_after ()
{
    if [[ -n $1 ]] ; then
        cat |awk -v regx1=$1 -v regx2="[^ \t]+" -v repl="********" '{p1 = match($0, regx1); r1 = RLENGTH; p2 = match($0, regx1 regx2); r2 = RLENGTH; if (p1 && p2) print substr($0, 1, p1 + r1 - 1) repl substr($0, p2 + r2); else print}'
    else
        cat
    fi
    return $?
}

get_db2_level ()
{
    local rc tmpvar
    tmpvar=$(export LANG=C;/usr/local/bin/db2ls) || return $?
    echo "${tmpvar}" |awk '/\/opt\/ibm\/db2/{print $2}' | tail -1
    return $?
}

get_dbms_home ()
{
    local rc tmpvar
    tmpvar=$(export LANG=C;/usr/local/bin/db2ls) || return $?
    echo "${tmpvar}" |awk '/\/opt\/ibm\/db2/{print $1}' | tail -1
    return $?
}

chk_if_user_exist ()
{
    id "${1:?}" >/dev/null 2>&1
    return $?
}

chk_if_group_exist ()
{
    grep -q "^${1:?}:" /etc/group
    return $?
}

# foo <user> <password> [group]
# aix, linux, solaris compatible
add_user ()
{
    local user=${1:?}
    local password=${2:?}
    local group=$3
    #========code changes fo RFE 92204============
    local instanceOwnerUID=$4
    #========code changes fo RFE 92204 ends============
#    local home_dir=${4:-"/home/${user}"}
    local rc

    [[ -z ${group} ]] && group=${user}
    add_group "${group}"

    if ! chk_if_user_exist "${user}" ; then
        logger_info "Creating OS user ${user}..."
        #========code changes fo RFE 92204============
        if [ -n "${instanceOwnerUID}" ] && [ "${instanceOwnerUID}" -ge 500 ] && [ "${instanceOwnerUID}" -le 60000 ] 
        then
           logger_info "Creating OS user with ID = ${instanceOwnerUID}..."
           useradd -g "${group}" -m -d /home/"${user}" -u "${instanceOwnerUID}" "${user}"
           logger_info "Creating OS user ${group} ${user} ${instanceOwnerUID} ..." 
        else
           logger_info "Creating OS user with automatic ID because either ID ${instanceOwnerUID} already exists or out of range"
           useradd -g "${group}" -m -d /home/"${user}" "${user}"
        fi
        #========code changes fo RFE 92204 ends============
        
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error 'Failed while creating OS user'
            return ${rc}
        fi
    fi

    change_user_pwd "${user}" "${password:?}"
    return $?
}

# linux, aix compatible
change_user_pwd ()
{
    local user=${1:?}
    local password=${2:?}
    local rc

    logger_info "Changing password for user: ${user}..."
    if chk_if_ksh; then
        echo "${user}:${password}" |chpasswd -c
    else
        echo "${user}:${password}" |chpasswd
    fi
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while changing password for user: ${user}"
    fi
    return ${rc}
}

# aix, linux, solaris compatible
add_group ()
{
    local group=${1:?}
    #========code changes fo RFE 92204============
    local instanceOwnerGroupID=$2
    #========code changes fo RFE 92204 ends============
    local rc

    if ! chk_if_group_exist "${group}" ; then
        logger_info "Creating OS group ${group}..."
        if which groupadd >/dev/null 2>&1; then
           #========code changes fo RFE 92204============
           if [ -n "${instanceOwnerGroupID}" ] && [ "${instanceOwnerGroupID}" -ge 500 ] && [ "${instanceOwnerGroupID}" -le 60000 ] 
           then
              logger_info "Creating OS group with ID = ${instanceOwnerGroupID}..."
              groupadd -g "${instanceOwnerGroupID}" "${group}"
           else
              logger_info "Creating OS group with automatic ID because either ID ${instanceOwnerGroupID} already exists or out of range"
              groupadd "${group}"
           fi   
           #========code changes fo RFE 92204 ends============
            #groupadd "${group}"
            rc=$?
        elif which mkgroup >/dev/null 2>&1; then
           #========code changes fo RFE 92204============
           if [ -n ${instanceOwnerGroupID} ] ; then
              mkgroup "${group}" && chgroup id="${instanceOwnerGroupID}" "${group}"
           else
              mkgroup "${group}"
           fi   
           #========code changes fo RFE 92204 ends============
           # mkgroup "${group}"
            rc=$?
        else
            logger_error 'No command found for creating OS group'
            rc=1
        fi
        if [[ ${rc} -ne 0 ]] ; then
            logger_error 'Failed while creating OS group'
            return ${rc}
        fi
    fi
    return 0
}

add_user_to_group ()
{
    local user=${1:?}
    local group=${2:?}

    if id -nG ${user} 2>/dev/null |egrep -q "(^| )${group}( |$)"; then
        return 0
    fi
    usermod -G $(id -nG ${user} |sed 's/ /,/g'),${group} ${user}
    return $?
}

remove_user_from_group ()
{
    local user=${1:?}
    local group=${2:?}

    if ! id -nG ${user} 2>/dev/null |egrep -q "(^| )${group}( |$)"; then
        return 0
    fi
    usermod -G $(id -nG ${user} |sed "s/${group}//g; s/  / /g; s/^ //; s/ $//; s/ /,/g") ${user}
    return $?
}

config_db2_client_for_user ()
{
    local user=${1:?}
    local instance=${2:?}

    local user_profile cmd rc
    if chk_if_bash; then
        user_profile=/home/${user}/.bash_profile
    elif chk_if_ksh; then
        user_profile=/home/${user}/.profile
    else
        return 1
    fi

    cmd=". /home/${instance}/sqllib/db2profile"
    if ! grep -q "${cmd}" ${user_profile} ; then
        echo "${cmd}" >> ${user_profile}
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed while updating file ${user_profile}"
            return ${rc}
        fi
    fi
    return 0

}

restart_sshd ()
{
    if chk_if_linux; then
        local sshd_path="/etc/init.d/sshd" # default path
        if [ -f $sshd_path ]; then
            $sshd_path restart
        else
            service sshd restart
        fi
    elif chk_if_aix; then
        stopsrc -s sshd
        startsrc -s sshd
    else
        return 1
    fi
    return $?
}

set_ssh_denygroup ()
{
    local group=${1:?}
    local rc
    add_group "${group}" || return $?
    if ! egrep -q "DenyGroups[ \t]+.*${group}" /etc/ssh/sshd_config ; then
        echo "DenyGroups ${group}" >> /etc/ssh/sshd_config
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error 'Failed while adding DenyGroups to /etc/ssh/sshd_config'
            return ${rc}
        fi
    fi
    restart_sshd
    return $?
}

disable_ssh_for_user ()
{
    local user=${1:?}
    local rc

    logger_info "Disabling SSH login for user ${user}..."

    add_user_to_group ${user} ${NONSSH_GROUP}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while adding user ${user} to group ${NONSSH_GROUP}"
        return ${rc}
    fi

    return 0
}

enable_ssh_for_user ()
{
    local user=${1:?}
    local rc

    logger_info "Enabling SSH login for user ${user}..."

    remove_user_from_group ${user} ${NONSSH_GROUP}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while removing user ${user} from group ${NONSSH_GROUP}"
        return ${rc}
    fi

    return 0
}

db2_license_add ()
{
    local dbms_home=$1
    local lic_dirname=$2
    shift 2

    # apply licenses
    local lic_filename rc
    for lic_filename in $@; do
        ${dbms_home}/adm/db2licm -a "${lic_dirname}/${lic_filename}"
        rc=$?
        if [[ ${rc} -ne 0 ]]; then
            logger_error "Failed to add license: ${lic_dirname}/${lic_filename}"
            return ${rc}
        fi
    done
    
    # remove unnecessary licenses
#    for lic in `ls ${lic_dirname}/*.lict`; do
#        found="false"
#        for lic_filename in $@; do
#           if [[ ${lic_dirname}/$lic_filename == $lic ]]; then
#              found="true"
#              break;
#           fi
#        done
#        if  [[ $found == "false" ]]; then
#           rm ${lic}
#        fi
#    done
   rm -f ${lic_dirname}/*.lict
}
db2_license_remove ()
{
    local dbms_home=$1
    local lic_name=$2
    
    ${dbms_home}/adm/db2licm -r "${lic_name}"
    rc=$?
    if [[ ${rc} -ne 0 ]]; then
       logger_error "Failed to remove license: ${lic_name}"
       return ${rc}
    fi
  
}
get_db2_license ()
{
	local dbms_home=$1
	echo $(${dbms_home}/adm/db2licm -l | awk '/Product identifier:/ {print $3}')
	return $?
}
chk_if_instance_exist ()
{
    su - "${1:?}" -c "db2 -version" >/dev/null 2>&1
    return $?
}

chk_if_instance_alive ()
{
    su - "${1:?}" -c "db2 ATTACH TO ${1:?}" >/dev/null 2>&1
    return $?
}

force_restart_instance ()
{
    su - "${1:?}" -c "db2nkill 0"
    start_instance "${1:?}"
    return $?
}

# foo <instance> [force]
restart_instance ()
{
    stop_instance "${1:?}"
    start_instance "${1:?}"
    return $?
}

# foo <instance> [force]
stop_instance ()
{
    local rc
    if chk_if_instance_alive "${1:?}" ; then
        su - "${1:?}" -c "db2stop $2"
        rc=$?
        case ${rc} in
            9)  # db2start or db2stop is running
                stop_instance $1
                ;;
            1)  # Already stopped
                ;;
            0)  # Success
                ;;
            *)  # Error
                logger_error 'Failed while stopping DB2 instance with force'
                return ${rc}
                ;;
        esac
    fi
    return 0
}

start_instance ()
{
    local rc
    if ! chk_if_instance_alive "${1:?}" ; then
        su - "${1:?}" -c db2start
        rc=$?
        case ${rc} in
            28) # db2start or db2stop is running
                start_instance $1
                ;;
            1)  # Already started
                break
                ;;
            0)  # Success
                break
                ;;
            *)  # Error
                logger_error 'Failed while starting DB2 instance'
                return ${rc}
                ;;
        esac
    fi
    return 0
}

# foo key1=value1 [...]
# foo 'key1="my value1"' [...]
# foo key1= [...]
config_instance_registry ()
{
    local instance=${1:?}
    shift
    local rc param

    if [[ -n "$*" ]] ; then
        logger_info "Updating DB2 instance registry..."
        for param in "$@"
        do
            local cmd="db2set -i ${instance} ${param}"
            logger_info "${cmd}"
            su - "${instance}" -c "${cmd}"
            rc=$?
            if [[ ${rc} -ne 0 ]] ; then
                logger_error 'Failed while updating DB2 instance registry'
                return ${rc}
            fi
        done
        restart_instance "${instance}" || return $?
    fi
    return 0
}

# foo key1=value1 [...]
# foo 'key1="my value1"' [...]
# foo key1= [...]
config_instance ()
{
    local instance=${1:?}
    shift
    local rc param

    if [[ -n "$*" ]] ; then
        logger_info "Updating DB2 instance configuration..."
        # translate "key=value" to "key value"
        # translate "key=" to "key NULL"
        param=$(echo "$*" | \
            awk -v regx='=([ \t]+|$)' -v repl='=NULL ' '{gsub(regx, repl); print}' | \
            sed 's/=/ /g')

        local cmd="UPDATE DBM CFG USING ${param}"
        su - "${instance}" -c "db2 -v ${cmd}"
        rc=$?
        if [[ ${rc} -ne 0 && ${rc} -ne 2 ]] ; then
            logger_error 'Failed while updating DB2 instance configuration'
            return ${rc}
        fi

        restart_instance "${instance}" || return $?
    fi
    return 0
}

chown_dir_owner ()
{
    local instance_name=${1}
    local dataPath=${2}
    ls -ld /home/${instance_name}/sqllib|awk -v dataPath="${dataPath}" '{printf "chown -R %s:%s %s; chmod g+rx %s\n", $3, $4, dataPath, dataPath}'|sh
    return $?
} 

clone_dir_owner ()
{
    local source_path=${1}
    local target_path=${2}
    local source_own_group=$(ls -ld ${source_path}|awk '{print $3":"$4}')
    local target_own_group=$(ls -ld ${target_path}|awk '{print $3":"$4}')

    if [[ "${source_own_group}" !=  "${target_own_group}" ]] ; then
        chown -R ${source_own_group} ${target_path}; chmod g+rx ${target_path}
        return $?
    else
        echo "the owner and group are same, they are ${source_own_group}"
        return 0
    fi
}

get_instance_config ()
{
    local instance=${1:?}
    local key=${2:?}

    local cmd="GET DBM CFG"
    local tmpvar
    tmpvar=$(su - "${instance}" -c "export LANG=C;db2 -v ${cmd}") || return $?
    echo "${tmpvar}" |awk -F= "/\($(upper ${key})\)/ {print \$2}" |pipe_trim
    return $?
}

# only works for DBaaS
# foo instance_name
get_instance_port ()
{
    local svcename
    svcename=$(get_instance_config ${1:?} SVCENAME) || return $?
    awk "/^${svcename}/ {print \$2}" /etc/services |cut -d/ -f1
    return $?
}

check_hadr_db_primary_role()
{
    local instance_name=${1:?}
    local db_name=${2}
    role_name=$(su - $instance_name -c "db2pd -db $db_name -hadr" | grep "HADR_ROLE" | awk -F= '{print $2}' | sed 's/\ //g' | tr '[:lower:]' '[:upper:]')
    
    if [[ "${role_name}" == "PRIMARY" ]]; then
        return 0
    else
        return 1
    fi
}

check_hadr_db_standby_role()
{
    local instance_name=${1:?}
    local db_name=${2}
    role_name=$(su - $instance_name -c "db2pd -db $db_name -hadr" | grep "HADR_ROLE" | awk -F= '{print $2}' | sed 's/\ //g' | tr '[:lower:]' '[:upper:]')
    if [[ "${role_name}" == "STANDBY" ]]; then
        return 0
    else
        return 1
    fi
}

check_tsa_resource()
{
    local db2instance=${1:?}
    local rsdomain
    local domain_status
    host=$(get_short_hostname) || return $?
    rsdomain=$(lsrpdomain | tail -n1 | awk '{print $1}')
    if [[ "${rsdomain}" != "" ]]; then
        domain_status=$(lsrpdomain | tail -n1 | awk '{print $2}')
        echo "rpdomain: ${rsdomain}, domain status: ${domain_status}"
        lssam | grep IBM.ResourceGroup:db2_${db2instance}_${host}_ >/dev/null 2>&1
        return $?
    else
        return 1
    fi
}


chk_if_database_exist ()
{
    local instance=${1:?}
    local database=${2:?}

    return $(su - "${instance}" -c "export LANG=C;db2 LIST DB DIRECTORY"  | \
        awk -v rc=1 -v lname="$(upper ${database})" -v ltype="Indirect" '
            /Database name/ { name=$NF }
            /Directory entry type/ { type=$NF
                if ((type==ltype) && (name==lname)) {rc=0; exit} }
            END { print rc }')
}

chk_if_database_alive ()
{
    local instance=${1:?}
    local database=${2:?}

    su - "${instance}" -c "db2 ACTIVATE DB ${database} >/dev/null 2>&1"
    su - "${instance}" -c "export LANG=C;db2pd -db ${database} -dbcfg |sed -n 2p |egrep -iq 'Active|Standby|Primary'"
    return $?
}

drop_database ()
{
    local rc
    logger_info "Dropping DB2 database $2..."
    su - "${1:?}" -c "db2 -v DROP DATABASE ${2:?}"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while dropping DB2 database'
    fi
    return ${rc}
}

create_database ()
{
    local opt instance database db_path codepage territory collate pagesize
    while getopts "i:d:p:c:t:l:s:" opt; do
        case ${opt} in
            i)
                instance=${OPTARG};;
            d)
                database=${OPTARG};;
            p)
                db_path=${OPTARG};;
            c)
                codepage=${OPTARG};;
            t)
                territory=${OPTARG};;
            l)
                collate=${OPTARG};;
            s)
                pagesize=${OPTARG};;
            \?)
                logger_error "Invalid parameters for creating database"
                return 1
                ;;
        esac
    done
    unset OPTIND
    local rc

    logger_info "Creating DB2 database ${database}..."
    local opt_codeset opt_codeset opt_pagesize
    [[ -n ${codepage} ]] && opt_codeset="USING CODESET ${codepage} ${territory:?}"
    [[ -n ${collate} ]] && opt_collate="COLLATE USING ${collate}"
    [[ -n ${pagesize} ]] && opt_pagesize="PAGESIZE ${pagesize} K"

    local cmd="CREATE DATABASE ${database:?} ON ${db_path:?} ${opt_codeset} ${opt_collate} ${opt_pagesize}"
    logger_info "${cmd}"
    su - "${instance}" -c "db2 -v ${cmd}"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while creating DB2 database'
    fi
    return ${rc}
}

# foo key1=value1 [...]
# foo 'key1="my value1"' [...]
# foo key1= [...]
config_database ()
{
    local instance=${1:?}
    local database=${2:?}
    shift 2
    local rc param

    if [[ -n "$*" ]] ; then
        logger_info "Updating DB2 database configuration..."
        # translate "key=value" to "key value"
        # translate "key=" to "key NULL"
        param=$(echo "$*" | \
            awk -v regx='=([ \t]+|$)' -v repl='=NULL ' '{gsub(regx, repl); print}' | \
            sed 's/=/ /g')

        local cmd="UPDATE DB CFG FOR ${database} USING ${param}"
        su - "${instance}" -c "db2 -v ${cmd}"
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            if [[ ${rc} -eq 2 ]] ; then
                echo "${tmpvar}"
                # su - ${instance} -c "db2 backup db ${dbName} to /dev/null"
                su - ${instance} -c "db2 DEACTIVATE database ${database};db2 ACTIVATE database ${database}"
                rc=0
                return ${rc}
            else
                logger_error 'Failed while updating DB2 database configuration'
                return ${rc}
            fi
        fi
    fi
    return 0
}

get_database_config ()
{
    local instance=${1:?}
    local database=${2:?}
    local key=${3:?}

    local cmd="GET DB CFG FOR ${database}"
    local tmpvar
    tmpvar=$(su - "${instance}" -c "export LANG=C;db2 -v ${cmd}") || return $?
    echo "${tmpvar}" |awk -F= "/\($(upper ${key})\)/ {print \$2}" |pipe_trim
    return $?
}

# Force application in SYNC(wait) mode
# foo <instance>
force_application ()
{
    local instance=${1:?}

    logger_info "Terminating DB2 instance connection..."
    # return true if list is NULL
    # return false if list is not NULL
    __none_handlers ()
    {

        return $(su - "${instance}" -c "export LANG=C;db2 -v LIST APPLICATIONS" |awk 'NF>0 && NR>4' |wc -l)
    }

    while ! __none_handlers; do
        su - "${instance}" -c "db2 -v FORCE APPLICATION ALL"
        logger_info "Sleep 2 seconds waiting for the termination..."
        sleep 2
    done
    return 0
}

force_applicaton_for_db()
{
   DBNAME=$(upper $1)
   
   count=1
   while [[ $count -ne 0 ]]; do
        count=0
        export LANG=C; db2 list applications global | grep "${DBNAME?}" | awk '{print $3}' | while read applid; do
           db2 force application \($applid\)
           count=1
        done
   done
   sleep 2
   local lang=$(set_lang ' ' ' ' ${DBNAME})
   echo "${lang};" db2 DEACTIVATE DATABASE ${DBNAME}
}

set_db2_fmc ()
{
    local rc
    logger_info "Setting auto-start DB2 FMC(Fault Monitor Coordinator)..."
    local dbms_home
    dbms_home=$(get_dbms_home "${1:?}") || return $?
    ${dbms_home:?}/bin/db2fmcu -u -p ${dbms_home}/bin/db2fmcd
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while setting auto-start DB2 FMC(Fault Monitor Coordinator)'
    fi
    return ${rc}
}

enable_auto_instance ()
{
    local rc
    logger_info "Tuning on auto-start DB2 instance..."
    set_db2_fmc "${1:?}" || return $?
    su - "${1:?}" -c "db2iauto -on $1"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while tuning on auto-start DB2 instance'
    fi
    return ${rc}
}

disable_auto_instance ()
{
    local rc
    logger_info "Tuning off auto-start DB2 instance..."
    su - "${1:?}" -c "db2iauto -off $1"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while tuning off auto-start DB2 instance'
    fi
    return ${rc}
}

# foo <instance>
enable_instance_fm ()
{
    local rc
    logger_info "Turning on DB2 FM(Fault Monitor)..."
    su - "${1:?}" -c "db2fm -i $1 -f on -a on"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while turning on DB2 FM(Fault Monitor)'
    fi
    return ${rc}
}

# foo <instance>
disable_instance_fm ()
{
    local rc
    logger_info "Turning off DB2 FM(Fault Monitor)..."
    su - "${1:?}" -c "db2fm -i $1 -f off"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while turning off DB2 FM(Fault Monitor)'
    fi
    return ${rc}
}

# foo <instance>
set_instance_oracle_comp ()
{
    logger_info "Enabling Oracle Compatibility..."
    config_instance_registry "${1:?}" DB2_COMPATIBILITY_VECTOR=ORA DB2_DEFERRED_PREPARE_SEMANTICS=YES
    return $?
}
# foo <instance>
set_instance_columnar_capbility()
{
    logger_info "Enabling columnar capbility..."
    config_instance_registry "${1:?}" DB2_WORKLOAD=ANALYTICS
    return $?
}

# foo
get_tsm_config ()
{
    if [[ -s ${DSM_SYS} ]] ; then
        local var=$(cat ${DSM_SYS} |egrep '^(nodename|tcpserveraddress|tcpport|commmethod|asnodename) ' |\
            sed 's/ /="/' |\
            sed 's/$/"/')
        if [[ -n ${var} ]] ; then
            eval "${var}"
        else
            return 1
        fi
    else
        return 1
    fi
    return 0
}

# foo
chk_if_tsm_client_configured ()
{
    get_tsm_config || return $?

    local configured=0
    # if [[ -z ${nodename} ]] ; then
    #     logger_warning "TSM server nodename is not set"
    #     configured=1
    # fi
    if [[ -z ${tcpserveraddress} ]] ; then
        logger_warning "TSM server address is not set"
        configured=1
    fi
    if [[ -z ${tcpport} ]] ; then
        logger_warning "TSM server port is not set"
        configured=1
    fi
    if [[ -z ${commmethod} ]] ; then
        logger_warning "TSM server commmethod is not set"
        configured=1
    fi
    return ${configured}
}

# foo <adminusername> <adminpassword> <db2domain>
register_tsm_node ()
{
    local adminusername=$1
    local adminpassword=$2
    local db2domain=$3
    local rc
    local configured=0

    if [[ -z ${adminusername} ]] ; then
        logger_warning "TSM server administrator name is not set"
        configured=1
    fi
    if [[ -z ${adminpassword} ]] ; then
        logger_warning "TSM server administrator password is not set"
        configured=1
    fi
    if [[ -z ${db2domain} ]] ; then
        logger_warning "TSM server db2domain is not set"
        configured=1
    fi

    get_tsm_config || return $?
    if [[ -z ${nodename} ]] ; then
        logger_warning "TSM node name is not set"
        configured=1
    fi

    if [[ ${configured} -eq 0 ]] ; then
        logger_info "Registering TSM node"
        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
        register node ${nodename:?} "${adminpassword:?}" domain=${db2domain:?} archdelete=yes backdelete=yes maxnummp=50
EOF
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            if [[ ${rc} -ne 10 ]] ; then
                logger_error "Failed while registering TSM node"
                return ${rc}
            fi
        fi
    else
        logger_warning "TSM Server is not configured or the configuration is incomplete, won't register a TSM Node"
    fi
    return 0
}

# foo <adminusername> <adminpassword> <db2domain>
register_tsm_node_for_hadr ()
{
    local adminusername=$1
    local adminpassword=$2
    local db2domain=$3
    local rc
    local configured=0

    if [[ -z ${adminusername} ]] ; then
        logger_warning "TSM server administrator name is not set"
        configured=1
    fi
    if [[ -z ${adminpassword} ]] ; then
        logger_warning "TSM server administrator password is not set"
        configured=1
    fi
    if [[ -z ${db2domain} ]] ; then
        logger_warning "TSM server db2domain is not set"
        configured=1
    fi

    get_tsm_config || return $?
    if [[ -z ${nodename} ]] ; then
        logger_warning "TSM node name is not set"
        configured=1
    fi
    
    if [[ -z ${asnodename} ]] ; then
        logger_warning "TSM as node name is not set"
        configured=1
    fi
    
    if [[ ${configured} -eq 0 ]] ; then
        logger_info "Registering TSM node"
        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
        register node ${asnodename:?} "${adminpassword:?}" domain=${db2domain:?} archdelete=yes backdelete=yes maxnummp=50
EOF
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            if [[ ${rc} -ne 10 ]] ; then
                logger_error "Failed while registering TSM node"
                return ${rc}
            fi
        fi
        
#        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
#        register node ${nodename:?} "${adminpassword:?}" domain=${db2domain:?} archdelete=yes backdelete=yes maxnummp=50
#EOF
#        rc=$?
#        if [[ ${rc} -ne 0 ]] ; then
#            if [[ ${rc} -ne 10 ]] ; then
#                logger_error "Failed while registering TSM node"
#                return ${rc}
#            fi
#        fi
    
        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
        grant proxynode target=${asnodename} agent=${nodename}
EOF
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed while granting proxynode target=${nodename} agent=${agent_nodename}"
            return ${rc}
        fi
        
    else
        logger_warning "TSM Server is not configured or the configuration is incomplete, won't register a TSM Node"
    fi
    return 0
}

# Remove all images under the node first
delete_tsm_node ()
{
    local adminusername=$1
    local adminpassword=$2
    local rc
    local configured=0

    if [[ -z ${adminusername} ]] ; then
        logger_warning "TSM server administrator name is not set"
        configured=1
    fi
    if [[ -z ${adminpassword} ]] ; then
        logger_warning "TSM server administrator password is not set"
        configured=1
    fi

    get_tsm_config || return $?
    if [[ -z ${nodename} ]] ; then
        logger_warning "TSM node name is not set"
        configured=1
    fi

    if [[ ${configured} -eq 0 ]] ; then
        logger_info "Removing TSM node"
        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" delete filespace ${nodename:?} '*' wait=yes
        dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" remove node ${nodename:?}
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed while removing TSM node"
            return ${rc}
        fi
    else
        logger_warning "TSM Server is not configured or the configuration is incomplete, won't remove any TSM Node"
    fi
    return 0
}

config_instance_for_tsm ()
{
    local instance=${1:?}
    local rc user_profile tsm_profile

    logger_info "Configuring DB2 instance for TSM support"
    if chk_if_bash; then
        user_profile=/home/${instance}/.bash_profile
    elif chk_if_ksh; then
        user_profile=/home/${instance}/.profile
    else
        return 1
    fi

    for value in "export DSMI_DIR=$(dirname ${DSM_OPT})" "export DSMI_CONFIG=${DSM_OPT}" "export DSMI_LOG=/home/${instance}"; do
        if ! grep -q "${value}" ${user_profile} ; then
            logger_info "Adding ${value} to ${user_profile}..."
            echo "${value}" >> ${user_profile}
            rc=$?
            if [[ ${rc} -ne 0 ]] ; then
                logger_error "Failed while updating file ${user_profile}"
                return ${rc}
            fi
        fi
    done
    
    su - ${instance} -c "db2stop force && db2start"
    
    return 0
}

chk_if_database_tsm_configured ()
{
    local instance=${1:?}
    local database=${2:?}

    local nodename
    nodename=$(get_database_config "${instance}" "${database}" "TSM_NODENAME") || return $?
    [[ -n ${nodename} ]]
    return $?
}

config_database_for_tsm ()
{
    local instance=${1:?}
    local database=${2:?}
    local nodename=${3:?}
    local nodepassword=${4:?}

    logger_info "Configuring DB2 database for TSM support"
    get_tsm_config || return $?
    local tmpvar rc
    tmpvar=$(config_database "${instance}" "${database}" TSM_NODENAME=${nodename} TSM_OWNER=${nodename} TSM_PASSWORD="${nodepassword}")
    rc=$?
    echo "${tmpvar}" | pipe_mask "${nodepassword}"
    return ${rc}
}

config_hadr_database_for_tsm ()
{
    local instance=${1:?}
    local database=${2:?}
    local nodepassword=${3:?}

    logger_info "Configuring DB2 database for TSM support"
    get_tsm_config || return $?
    echo "nodename is ${nodename}"
    echo "asnodename is ${asnodename}"
    local tmpvar rc
    vendoropt="-asnodename="${asnodename}
    echo ${vendoropt}
    tmpvar=$(config_database "${instance}" "${database}" TSM_NODENAME=${nodename} TSM_OWNER=${nodename} TSM_PASSWORD=${nodepassword})
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        if [[ ${rc} -ne 2 ]] ; then
            echo "${tmpvar}"
            return ${rc}
        fi
    fi

    local cmd="UPDATE DB CFG FOR ${database} USING VENDOROPT \"'${vendoropt}'\""
    tmpvar=$(su - "${instance}" -c "db2 -v ${cmd}")
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        if [[ ${rc} -ne 2 ]] ; then
            echo "${tmpvar}"
            return ${rc}
        fi
    fi

    #echo "${tmpvar}" | pipe_mask "${nodepassword}"
    return 0
}

chk_if_database_tsm_archived ()
{
    local instance=${1:?}
    local database=${2:?}

    local logarchmeth1
    logarchmeth1=$(get_database_config "${instance}" "${database}" "LOGARCHMETH1") || return $?
    #[[ -n "${logarchmeth1}" && ${logarchmeth1} != "OFF" ]]
    [[ ${logarchmeth1} == "TSM" ]]
    return $?
}

config_database_as_tsm_archive ()
{
    local instance=${1:?}
    local database=${2:?}

    logger_info "Configuring DB2 database as TSM Archive"
    config_database "${instance}" "${database}" LOGARCHMETH1=TSM
    return $?
}

config_hadr_database_as_tsm_archive ()
{
    local instance=${1:?}
    local database=${2:?}

    logger_info "Configuring DB2 database as TSM Archive"
    get_tsm_config || return $?

    config_database "${instance}" "${database}" LOGARCHMETH1=TSM
    
    logarchopt1="-asnodename=${asnodename}"
    local cmd="UPDATE DB CFG FOR ${database} USING LOGARCHOPT1 \"'${logarchopt1}'\""
    tmpvar=$(su - "${instance}" -c "db2 -v ${cmd}")
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        if [[ ${rc} -ne 2 ]] ; then
            echo "${tmpvar}"
            return ${rc}
        fi
    fi
    return 0
}

# foo -i INSTANCE -d DATABASE -t <TSM | BACKUP_PATH> [-g BACKUP_FLAG] [-z] [-o OUT_FILE]
# call this under root
#
# BACKUP_FLAG:
#   F: Normal Offile (Default)
#   N: Normal Online
#   I: Incremental Offline
#   O: Incremental Online
#   D: Delta Offline
#   E: Delta Online
#
# -z: Compress the backup
#
# TSM server and client must have been setup properly if using TSM
# BACKUP_PATH must exist and be writable for instance user if not using TSM
# This function DO NOT support tablespace level backup
#
backup_db ()
{
    local opt instance database backup_target backup_flag compress_option out_file
    while getopts "i:d:t:g:zo:" opt; do
        case ${opt} in
            i)
                instance=${OPTARG:?};;
            d)
                database=${OPTARG:?};;
            t)
                backup_target=${OPTARG:?};;
            g)
                backup_flag=${OPTARG};;
            z)
                compress_option=COMPRESS;;
            o)
                out_file=${OPTARG};;
            \?)
                return 9;;
        esac
    done
    unset OPTIND

    backup_flag=$(upper "${backup_flag}")

    if [[ $(upper "${backup_target:?}") == "TSM" ]] ; then
        local target_option="USE TSM"
    else
        local target_option="TO ${backup_target:?}"
    fi

    local mode_option log_option
    case "${backup_flag:-F}" in
        F)
            mode_option=""
            force_application ${instance}
            ;;
        N)
            mode_option="ONLINE"
            log_option="INCLUDE LOGS"
            ;;
        I)
            mode_option="INCREMENTAL"
            force_application ${instance}
            ;;
        O)
            mode_option="ONLINE INCREMENTAL"
            log_option="INCLUDE LOGS"
            ;;
        D)
            mode_option="INCREMENTAL DELTA"
            force_application ${instance}
            ;;
        E)
            mode_option="ONLINE INCREMENTAL DELTA"
            log_option="INCLUDE LOGS"
            ;;
        *)
            return 9
            ;;
    esac

    local cmd="export LANG=C;db2 BACKUP DB ${database:?} ${mode_option} ${target_option:?} ${compress_option} ${log_option}"

    logger_info "${cmd}"
    local tmpvar rc
    if [[ -n ${out_file} ]] ; then
        tmpvar=$(su - "${instance:?}" -c "${cmd}" 2>&1)
        rc=$?
        echo "${tmpvar}" |tee "${out_file}"
        rc=$((rc + $?))
    else
        su - "${instance:?}" -c "${cmd}"
        rc=$?
    fi
    return ${rc}
}

get_backup_timestamp_from_output ()
{
    local tmpvar
    tmpvar=$(cat "${1:?}") || return $?
    echo "${tmpvar}" |pipe_get_backup_timestamp_from_output
    return $?
}

pipe_get_backup_timestamp_from_output ()
{
    cat |awk -v regx='[0-9]{14}' 'NF {p = match($0, regx); if (p) print substr($0, p, RLENGTH)}'
    return $?
}

get_sqlcode ()
{
    [[ -f $1 ]] || return $?
    awk -v regx='SQL[0-9]{4,5}[CENWI]' 'NF {p = match($0, regx); if (p) print substr($0, p, RLENGTH)}' "$1"
    return $?
}

get_reasoncode ()
{
    [[ -f $1 ]] || return $?
    #grep -Pio '((?<=reason code ")|(?<=reason code: ")|(?<=reason code = ")|(?<=security reason "))[0-9]{1,}(?=")' "$1"
    awk -v regx1='[Rr]eason [Cc]ode \"|[Rr]eason [Cc]ode: \"|[Rr]eason [Cc]ode = "|[Ss]ecurity [Rr]eason \"' -v regx2='[0-9]+' '{p1 = match($0, regx1); if (p1) {s = substr($0, p1 + RLENGTH - 1); if (s) {p2 = match(s, regx2); if (p2) {print substr(s, p2, RLENGTH)}}}}' "$1"
    return $?
}

translate_backup_mode_from_flag ()
{
    local backup_flag=${1:?}
    case $(upper ${backup_flag}) in
        [FID])
            echo "OFFLINE"
            ;;
        [NOE])
            echo "ONLINE"
            ;;
        *)
            return 1
            ;;
     esac
     return 0
}

translate_backup_type_from_flag ()
{
    local backup_flag=${1:?}
    case $(upper ${backup_flag}) in
        [FN])
            echo "NORMAL"
            ;;
        [IO])
            echo "INCREMENTAL"
            ;;
        [DE])
            echo "DELTA"
            ;;
        *)
            return 1
            ;;
     esac
     return 0
}

generate_image_meta_file ()
{
    local instance=${1:?}
    local vm_template_id=${2:?}
    local database=${3:?}
    local image_request=${4:?}
    local image_flag=${5:?}
    local image_name=${6:?}
    local image_desc=$7
    local timestamp=${8:?}
    shift 8
    local deployment_id=${1:?}
    local role_name=${2:?}
    
    local ip 
    ip=$(get_host_ip) || return $?
    
    local signature
    case ${image_request} in
        B)
            signature='baseline';;
        A)
            signature='auto';;
        M)
            signature='manual';;
    esac
    
    local existing_meta_file=/dbaas/${vm_template_id}_${instance}_instance_profile.json
    if [[ ! -f ${existing_meta_file} || ! -r ${existing_meta_file} ]] ; then
        return 1
    fi
    
    local instance_info=$(python -c "import json
with open('${existing_meta_file}') as f:
    json_profile = json.load(f)
    db_json = {}
    #find database name
    for db in json_profile['databases']:
        if db['databaseName'] == '${database}':
            db_json = db
    for key,value in db_json.iteritems():
        json_profile[key] = value
    del json_profile['databases']
    print json.dumps(json_profile,sort_keys=True,indent=4,separators=(',',':')).rstrip('}')
") 
    local meta_file=$(su - ${instance} -c pwd)/$$_image_meta_${signature}_${deployment_id}_${vm_template_id}.${role_name}_${instance}_${database}_${timestamp}.json
    db2_level=$(get_db2_level)
    
    local cpu
    cpu=$(get_cpu) || return $?
    
    local memory
    memory=$(get_memory) || return $?
    
    local osType
    osType=$(get_os) || return $?
    
    local platformType
    platformType=$(get_platform) || return $?
    
    __generate ()
    {
        echo ${instance_info}
        echo ','
        generate_json \
            cpu "${cpu}" \
            memory "${memory}" \
            osType "${osType}" \
            platformType "${platformType}" \
            host "${ip}" \
            databaseName "${database}" \
            imageName "${image_name}" \
            imageDescription "${image_desc}" \
            imageFlag "${signature}" \
            timestamp "${timestamp}" \
            backupMode "$(translate_backup_mode_from_flag ${image_flag})" \
            backupType "$(translate_backup_type_from_flag ${image_flag})" \
            db2Level "${db2_level}"

        echo ','
        echo "\"registeredVariables\": [{ $(generate_instance_registry_json ${instance}) }],"
        echo "\"instanceConfig\": [{ $(generate_instance_cfg_json ${instance}) }],"
        echo "\"databaseConfig\": [{ $(generate_database_cfg_json ${instance} ${database}) }]"
        echo '}'
    }
    __generate > ${meta_file} || return $?

    echo "${meta_file}"
}

generate_instance_registry_json ()
{
    local instance=${1:?}
    eval generate_json $(list_instance_registry "${instance}")
}

generate_instance_cfg_json ()
{
    local instance=${1:?}
    eval generate_json $(list_instance_cfg "${instance}")
}

generate_database_cfg_json ()
{
    local instance=${1:?}
    local database=${2:?}
    eval generate_json $(list_database_cfg "${instance}" "${database}")
}

# foo <key> <value> [...]
generate_json ()
{
    local content
    while [[ $# -gt 0 ]]; do
        content="${content}, \"$1\" : \"$2\""
        shift && shift
    done
    if [[ -n ${content} ]] ; then
        content=$(echo "${content}" |cut -c3-) # remove the leading comma and blank space: ", "
    fi

    echo "${content}"
    return 0
}

# foo <fullpath> <key> <value>
generate_json_file ()
{
    local file_name=${1:?}
    local key=${2:?}
    local value=${3:?}

    __generate ()
    {
        echo "{"
        generate_json \
            "${key}" "${value}"
        echo "}"
    }
    __generate > ${file_name} || return $?
}

# deprecated
fix_ks_domain ()
{
    local ks_url=$1
    echo "${ks_url}" |awk -v regx=$(get_ks_ip) -v repl=$(get_ks_hostname) '{gsub(regx, repl); print}'
    return $?
}

# foo <fullpath>
save_image_meta_file ()
{
    local meta_file=${1:?}

    if [[ ! -s ${meta_file} ]] ; then
        return 1
    fi
    local url="user/db2/images/${meta_file##*_image_meta_}"
    call_sh_rest "${url}" PUT "@${meta_file}"
    return $?
}

# foo <fullpath>
grant_image_meta_file ()
{
    local meta_file=${1:?}

    if [[ ! -s ${meta_file} ]] ; then
        return 1
    fi
    
    local url tmpvar
    
    # get instance profile
    url=instances/
    tmpvar=/tmp/instance_list.$$
    call_sh_deployment_rest "${url}" GET "${tmpvar}" > /dev/null    
    local instance_profile=$(python -c "import json
with open('${tmpvar}') as f_json:
    d_json = json.load(f_json)
    print d_json[0]
")
    /bin/rm -f ${tmpvar}
    
    # get instance profile meta
    url=instances/${instance_profile}?meta
    tmpvar=/tmp/${instance_profile}_meta.$$
    call_sh_deployment_rest "${url}" GET "${tmpvar}" > /dev/null
    local deployment_meta=$(python -c "import json
with open('${tmpvar}') as f_json:
    d_json = json.load(f_json)
    print d_json['AccessRights']
")
    /bin/rm -f ${tmpvar}
    
    # get image meta
    url="user/db2/images/${meta_file##*_image_meta_}?meta"
    tmpvar=/tmp/${meta_file##*_image_meta_}_meta.$$
    local tmpvar2=/tmp/${meta_file##*_image_meta_}_meta_update.$$
    call_sh_rest "${url}" GET "${tmpvar}" > /dev/null
    local image_meta=$(python -c "import json
d_json = {}
with open('${tmpvar}') as f_json:
    d_json = json.load(f_json)
    d_json['AccessRights']=${deployment_meta}
d_json_new = json.dumps(d_json,sort_keys=True,indent=4,separators=(',',':'))
with open('${tmpvar2}', 'w') as f_json:
    f_json.write(d_json_new)
    print d_json_new
")
    /bin/rm -f ${tmpvar}
    
    # update image meta
    url="user/db2/images/${meta_file##*_image_meta_}?meta"
    call_sh_rest "${url}" PUT "@${tmpvar2}" > /dev/null
    /bin/rm -f ${tmpvar2}
    
    return $?
}

# foo <meta_filename>
delete_image_meta_file ()
{
    local meta_file=${1:?}

    logger_info "Delete image meta file: ${meta_file}"

    local url="user/db2/images/${meta_file}"
    call_sh_rest "${url}" DELETE
    
    return $?
}

# If filter is empty, then ignore this filter
# foo <image_request> <ip> <db_name>
list_image_meta_file ()
{
    local image_request=$1
    local deployment_id=$2
    local vm_template_id=$3
    local role_name=$4
    local instance=$5
    local database=$6
    local list signature rc

    list=$(get_image_meta_file) || return $?
    list=$(echo "${list}" | \
        tr -d '{}[]"' | \
        awk -F, '{for(i=1;i<=NF;i++) print $i}') || return $?

    case ${image_request} in
        B)
            signature='baseline';;
        A)
            signature='auto';;
        M)
            signature='manual';;
    esac
    if [[ -n ${signature} ]] ; then
        list=$(echo "${list}" |sed -n "/^${signature}_/p")
    fi
    if [[ -n ${deployment_id} ]] ; then
        list=$(echo "${list}" |sed -n "/_${deployment_id}_/p")
    fi
    if [[ -n ${vm_template_id} && -n ${role_name} ]] ; then
        list=$(echo "${list}" |sed -n "/_${vm_template_id}.${role_name}_/p")
    fi
    if [[ -n ${instance} ]] ; then
        list=$(echo "${list}" |sed -n "/_${instance}_/p")
    fi
    if [[ -n ${database} ]] ; then
        list=$(echo "${list}" |sed -n "/_${database}_/p")
    fi
    echo "${list}"
    return 0
}

# Get image meta file list or content
# foo [meta_filename] [output_file]
get_image_meta_file ()
{
    local meta_file=$1
    local out_file=$2

    local url="user/db2/images/${meta_file}"
    call_sh_rest "${url}" GET "${out_file}"
    return $?
}

get_fixpack_file ()
{
    local fixpack_file=$1
    local out_file=$2

    local url="dbworkloads/${fixpack_file}"
    call_ks_rest_tgz "${url}" GET "${out_file}"
    return $?
}


# foo <instance> <database>
list_image_in_tsm ()
{
    local instance=${1:?}
    local database=${2:?}
    local tmpvar

    tmpvar=$(su - ${instance} -c "db2adutl QUERY FULL DB ${database}") || return $?
    echo "${tmpvar}" |pipe_get_backup_timestamp_from_output
    return $?
}
# foo <instance> <database> <timestamp>
delete_image_in_tsm ()
{
    local instance=${1:?}
    local database=${2:?}
    local timestamp=${3:?}

    logger_info "Delete database image of taken at ${timestamp}"
    su - ${instance} -c "db2adutl DELETE FULL TAKEN AT ${timestamp} DB ${database} WITHOUT PROMPTING"
    return $?
}

# foo <inst_name> <database_name> <database_role_name>
delete_backup_schedule ()
{
    logger_info "Delete backup schedule"
    local inst_name=$1
    local database_name=$2
    local database_role_name=$3
    
    local signature="create_database_image . ${inst_name} ${database_name} ${database_role_name}"
    crontab -l |grep -v "${signature}" |crontab
    return $?
}

# foo <frequency> <inst_name> <db_name> <database_role_name> <year> <month> <day> <hour> <minute> <weekday>
create_backup_schedule ()
{
    logger_info "Create a backup schedule"
    local frequency=${1:?}
    local inst_name=${2:?}
    local db_name=${3:?}
    local database_role_name=${4:?}
    shift 4
    
    if [[ "$frequency" != "off" ]]; then
        local year=${1:?}
        local month=${2:?}
        local day=${3:?}
        local hour=${4:?}
        local minute=${5:?}
        shift 5
    fi
     
    #delete the former task at first
    delete_backup_schedule ${inst_name} ${db_name} ${database_role_name}

    if [[ "$frequency" == "once" ]]; then
        logger_info "Create a backup schedule at the specific time"
        local cmd="${minute} ${hour} ${day} ${month} * $(dirname $0)/func_agent.sh create_database_image A ${inst_name} ${db_name} ${database_role_name} ${year}${month}${day}"
        echo "once cmd=$cmd"
    elif [[ "$frequency" == "daily" ]]; then
        logger_info "Create a backup schedule at the specific time every day"
        local cmd="${minute} ${hour} * * * $(dirname $0)/func_agent.sh create_database_image A ${inst_name} ${db_name} ${database_role_name} ${year}${month}${day}"
        echo "daily cmd=$cmd"
    elif [[ "$frequency" == "weekly" ]]; then
        logger_info "Create a backup schedule at the specific time every week"
        local weekday=${1:?}
        local cmd="${minute} ${hour} * * ${weekday} $(dirname $0)/func_agent.sh create_database_image A ${inst_name} ${db_name} ${database_role_name} ${year}${month}${day}"
        echo "weekly cmd=$cmd"
    else
        logger_error "usage: $0 <once|daily|weekly>"
        return 1
    fi

    printf "$(crontab -l)\n${cmd}\n" |crontab
    return $?
}

# foo <instance> <database> <admin> <password>
tsm_backup_rollback ()
{
    local instance=${1:?}
    local database=${2:?}
    local adminusername=${3:?}
    local adminpassword=${4:?}
    local timestamp rc

    delete_backup_schedule
    rc=$((rc + $?))

    logger_info "Delete all images with meta"
    delete_database_image "" "${instance}" "${database}" 0
    rc=$((rc + $?))

    logger_info "Delete any orphan image in TSM if have"
    for timestamp in $(list_image_in_tsm "${instance}" "${database}"); do
        delete_image_in_tsm "${instance}" "${database}" "${timestamp}"
        rc=$((rc + $?))
    done

    delete_tsm_node "${adminusername}" "${adminpassword}"
    rc=$((rc + $?))

    return ${rc}
}

# foo <image_request> <inst_name> <database_name> <database_role_name> <date>
create_database_image ()
{
    local image_request=$1
    local inst_name=$2
    local database_name=$3
    local database_role_name=$4
    local date=$5
    
    check_hadr_db_standby_role $inst_name $database_name
    local isStandby=$?
    
    if [[ ${isStandby} -eq 0 ]] ; then
       return 0
    fi
    
    local current_date=`date +"%Y%m%d"`    
    if [[ ${current_date} -lt  ${date} ]]; then
       #"The big day not come yet"
       return 0
    fi
    
    call_operation_by_rest \
        "backup" \
        databaseOperation.py \
        "${database_role_name}" \
        imageRequest "${image_request}" \
        databaseName "${database_name}" 
    return $?
}

# image_request:
#     B: Baseline backup
#     M: Manual backup
#     A: Automated backup
# keep_n: How many images will be kept
#     0: delete all
#     <N>: keep N images
# foo <image_request> <instance> <database> <keep_n>
delete_database_image ()
{
    local image_request=$1
    local deployment_id=${2:?}
    local vm_template_id=${3:?}
    local role_name=${4:?}
    
    local instance=${5:?}
    local database=${6:?}
    local keep_n=${7:?}
    local rc meta_file_list meta_file tmpstr timestamp ip

    logger_info "Delete database image by image_request: '${image_request}', instance: '${instance}', database: '${database}', keep_n: '${keep_n}'"
    # Get image meta file list

    meta_file_list=$(list_image_meta_file "${image_request}" "${deployment_id}" "${vm_template_id}" "${role_name}" "${instance}" "${database}")
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed to get image meta file list"
        return ${rc}
    fi

    meta_file_list=$(echo "${meta_file_list}" |sort -r | \
        sed -n "$((keep_n + 1)),\$p")

    for meta_file in ${meta_file_list}; do
        tmpstr=${meta_file##*_}
        timestamp=${tmpstr%%.json}
        # Delete image
        delete_image_in_tsm "${instance}" "${database}" "${timestamp}"
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed to delete database image in TSM"
            return ${rc}
        fi

        # Delete image meta
        delete_image_meta_file "${meta_file}"
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed to delete image meta file"
            return ${rc}
        fi
    done
    return 0
}
# foo
get_master_ip ()
{
    local url tmpvar rc out

    url=deployment.json
    tmpvar=/tmp/${url}.$$
    call_sh_deployment_rest "${url}" GET "${tmpvar}" > /dev/null
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed to get ${url} from SH.\n$(cat ${tmpvar})"
        return ${rc}
    fi

    local master_ip=$(python -c "import json
f_json = open('${tmpvar}')
d_json = json.load(f_json)
master_id = d_json['roles']['master']['node'].encode()
print d_json['instances'][master_id]['public-ip'].encode()
")
    
    echo ${master_ip}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed to get master VM IP from ${tmpvar}."
        return ${rc}
    fi

    /bin/rm -f ${tmpvar}
    return 0
}

# foo <operation name> <operation script> <database_role_name> [<key value> [...]]
call_operation_by_rest ()
{
    local name=${1:?}
    shift
    local script=${1:?}
    shift
    local database_role_name=${1:?}
    shift

    get_security_header

    local curl_url data master_ip role rc

    role="$(echo "${SERVER_NAME}" |cut -d\. -f1).${database_role_name}"

    master_ip=$(get_master_ip)
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed to get master VM IP.\n${master_ip}"
        return ${rc}
    fi

    if chk_if_ipv6 "${master_ip}"; then
        if ! echo "${master_ip}" |grep -q '^\['; then
            master_ip="[${master_ip}]"
        fi
    fi

    curl_url="https://${master_ip}:9999/operations/"
    logger_info "Operation URL: ${curl_url}"

    data='{
        "role": "'${role}'",
        "type": "'${name}'",
        "parameters": { '$(generate_json "$@")' },
        "script": "'${script}'"
    }'
    logger_info "Operation JSON: ${data}"

    curl -g -kv -H "${SECURITY_HEADER}" -H "Content-Type:application/json" -X POST --data-binary "${data}" --cacert /0config/cert.tmp/cert_1.pem --url ${curl_url}
    return $?
}

# foo
get_agent_env ()
{
    local userdata

    userdata=$(/0config/get_userdata.sh) || return $?
    export ${userdata:?} || return $?
    return 0
}

# foo
get_security_header ()
{
    get_agent_env
    SECURITY_HEADER="X-IWD-Authorization : $(${PYTHON_CMD} /0config/create_security_header.py)"
    return $?
}

# <password> could be empty if the <user> matchs <instance>
# Usage:
# foo mydb appuser password /tmp/test.sql /tmp/test.sql.log
# foo mydb db2inst1 "" /tmp/test.sql /tmp/test.sql.log
load_sqlfile_for_db2 ()
{
    local instance=${1:?} # not used
    local database=${2:?}
    local user=${3:?}
    local password=$4
    local file=${5:?}
    local log=$6
    local error_proceed=1 # not used
    local rc

    logger_info "Loading SQL file in DB2 syntax: ${file} ..."
    [[ -f ${file} ]]
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while reading file: ${file}"
        return ${rc}
    fi

    if [[ ! -s ${file} ]] ; then
        logger_info "The file is empty, skipped."
        return 0
    fi

    logger_info "Generating temp SQL file..."
    local tmpexec=/tmp/exec_$(basename ${file}).$$
    local tmpsql=/tmp/$(basename ${file}).$$
    /bin/cp "${file}" "${tmpsql}" # To avoid permission problem for parent directories and the file itself.
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while generating temp SQL file: ${tmpsql}"
        return ${rc}
    fi

    dos2unix "${tmpsql}"
    chmod go+r "${tmpsql}"

    logger_info "Guess SQL termination character used in file"
    local tc
    tc=$(get_sql_term_char_for_db2 "${tmpsql}") || return $?
    logger_info "Termination Character is: ${tc:-newline}"
    local tc_option
    [[ -n "${tc}" ]] && tc_option="-td\\${tc}"

    local user_option
    [[ -n ${password} ]] && user_option="USER ${user} USING '${password}'"

    __generate ()
    {
        echo "db2 CONNECT TO ${database} ${user_option}"
        echo "db2 -v ${tc_option} -f ${tmpsql}"
    }
    __generate > "${tmpexec}"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while generating temp exec file: ${tmpexec}"
        return ${rc}
    fi
    chmod go+rx "${tmpexec}"
    cat "${tmpexec}" |pipe_mask "${password}"

    local cmd="su - ${user} -c ${tmpexec}"
    logger_info "${cmd}"
    local tmpvar
    tmpvar=$(${cmd})
    rc=$?
    logger_info "Removing temp exec file..."
    /bin/rm -f "${tmpexec}"
    echo "${tmpvar}" |tee ${log:?}
    rc=$((rc + $?))
    if [[ ${rc} -ne 0 && ${rc} -ne 2 ]] ; then
        logger_error "Error detected while loading SQL file: ${tmpsql}"
        return ${rc}
    fi

    logger_info "Done"
    logger_info "Removing temp SQL file..."
    /bin/rm -f "${tmpsql}"

    return 0
}

# <password> must be given due to clpplus syntax limitation.
# When <error_proceed>=1, clpplus will exit immediately after the error,
# this is different from DB2 CLP, CLP will proceed the process after the error SQL.
# Usage:
# foo db2inst1 mydb appuser password /tmp/test.sql /tmp/test.sql.log 1
# foo db2inst1 mydb db2inst1 password /tmp/test.sql /tmp/test.sql.log 0
load_sqlfile_for_oracle ()
{
    local instance=${1:?}
    local database=${2:?}
    local user=${3:?}
    local password="${4:?}"
    local file="${5:?}"
    local log="$6"
    local error_proceed=${7:-1}
    local rc

    logger_info "Loading SQL file in Oracle syntax: ${file}"
    [[ -f ${file} ]]
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while reading file: ${file}"
        return ${rc}
    fi

    if [[ ! -s ${file} ]] ; then
        logger_info "The file is empty, skipped."
        return 0
    fi

    logger_info "Getting listening port for instance..."
    local port=$(get_instance_port ${instance}) || return $?
    if [[ -z ${port} ]] ; then
        logger_error "Failed to get instance port"
        return 1
    fi

    logger_info "Generating temp SQL file..."
    local tmpfile=/tmp/$(basename ${file}).$$
    __generate_cmd ()
    {
        echo "SET ECHO ON"
        if [[ ${error_proceed} -eq 0 ]] ; then
            echo "WHENEVER OSERROR EXIT FAILURE"
            echo "WHENEVER SQLERROR EXIT SQL.SQLCODE"
        fi
        echo "@${file}"
        echo "QUIT" # Must have this in case the lake of quit/exit in plsql file.
    }
    __generate_cmd > "${tmpfile}"
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while generating temp SQL file: ${tmpfile}"
        return ${rc}
    fi

    dos2unix "${tmpfile}"
    chmod go+r "${tmpfile}"

    local cmd="su - ${user} -c 'clpplus -nw ${user}/${password}@localhost:${port:?}/${database} @${tmpfile}'"
    logger_info "${cmd}" |pipe_mask "${password}"
    local tmpvar
    tmpvar=$(eval ${cmd})
    rc=$?
    echo "${tmpvar}" |tee ${log:?}
    rc=$((rc + $?))
    if [[ ${rc} -ne 0 && ${rc} -ne 2 ]] ; then
        logger_error "Error detected while loading SQL file: ${tmpfile}"
        return ${rc}
    fi

    logger_info "Done"
    logger_info "Removing temp SQL file..."
    /bin/rm -f "${tmpfile}"

    return 0
}

# return EMPTY for newline as the termination char
# supported termination char: ";", "@" and <newline>
# only accept unix format file to test
get_sql_term_char_for_db2 ()
{
    local file="${1:?}"
    local rc tc tmpvar

    tmpvar=$(awk -F "" '{
        quote=0;
        for (i=1;i<=NF;i++) {
            if ($i == "\47") quote++;
            if ((quote % 2) == 0) {
                if ($i == "-" && $(i+1) == "-") next
            }
            printf("%s", $i);
            printf((i == NF ? RS : FS));
        } }' "${file}"
    ) || return $?

    tc=$(echo "${tmpvar}" |tr -d '[ \t]' |\
        awk NF |sed -n '$p' |rev |cut -c1
    ) || return $?

    case ${tc} in
        \;|@)
            ;; # do nothing
        *)
            tc="";;
    esac
    echo "${tc}"
    return 0
}
# foo <instance> <database>
get_tablespace_list ()
{
    local instance=${1:?}
    local database=${2:?}
    local tmpvar
    tmpvar=$(printf "export LANG=C;db2 CONNECT TO ${database}\ndb2 LIST TABLESPACES" |su - ${instance}) || return $?
    echo "${tmpvar}" |awk -F= '/^[ \t]*Name[\t ]+=/ {print $2}' |pipe_trim
    return $?
}

# bash and ksh88 compatible
# foo <array_name> <array_element [...]>
new_array ()
{
    local name=$1
    shift
    if chk_if_bash; then
        eval ${name}=\(\"\$@\"\)
    elif chk_if_ksh; then
        set -A ${name} "$@"
    else
        return 1
    fi
    return $?
}

# bash and ksh88 compatible
list_funcname ()
{
    if chk_if_bash; then
        declare -F |awk '{print $3}'
    elif chk_if_ksh; then
        typeset -f |awk '/^function / {print $2}'
    else
        return 1
    fi
    return $?
}

# foo
get_host_ip ()
{
    local hostname ip
    hostname=$(hostname 2>/dev/null) || return $?
    ip=$(awk "/${hostname:?}/ {print \$1}" /etc/hosts |grep -v 127.0.0.1 |tail -1) || return $?
    echo ${ip:?}
    return $?
}


update_etc_hosts ()
{
    local ip hostname hostname_short
    ip=$1
    hostname=$2
    hostname_short=$3
	cat >> /etc/hosts <<EOF
${ip}    ${hostname}        ${hostname_short}
EOF
    return $?
}

#foo
get_cpu ()
{
   local cpu_info
   cpu_info=$(cat /proc/cpuinfo | grep "cpu family")
   echo ${cpu_info} | awk 'BEGIN {FS=":"} {print $2}' |pipe_trim
}

#foo
#data_path
get_disk_size()
{
   local data_path=$1
   local disk_size=$(df -k ${data_path}| awk 'NR==2{print $2}')
   #sometimes, filesystem has a long name, the disksize in the 3th row
   if [[ ! -n ${disk_size} ]]; then
      disk_size=$(df -k ${data_path}| awk 'END{print $1}')
   fi
   echo ${disk_size}
}
  
#foo
get_memory()
{
   local mem_info=$(cat /proc/meminfo | grep "MemTotal")
   echo ${mem_info} | awk 'BEGIN {FS=":"} {print $2}'  |pipe_trim
}

# deprecated
get_ks_ip ()
{
    local ip
    ip=$(awk "/$(get_ks_hostname)/ {print \$1}" /etc/hosts |grep -v 127.0.0.1 |tail -1) || return $?
    echo ${ip:?}
    return $?
}

# deprecated
get_ks_hostname ()
{
    echo IBMWorkloadDeployer
    return $?
}

# foo <instance>
list_instance_registry ()
{
    local instance=${1:?}
    local data

    data=$(su - ${instance} -c "db2set -i ${instance}" |awk '/\=/')
    echo "${data}" |awk -F= -v regx="(^[\t ]*|[\t ]*$)" -v repl="" '{key = $1; val = $2; gsub(regx, repl, key); gsub(regx, repl, val); print "\"" key "\" \"" val "\""}'
}

# foo <instance>
list_instance_cfg ()
{
    local instance=${1:?}
    local data

    data=$(su - ${instance} -c "export LANG=C;db2 get dbm cfg" |awk '/ = /')
    echo "${data}" |awk -F= -v regx="(^[\t ]*|[\t ]*$)" -v repl="" '{key = $1; val = $2; gsub(regx, repl, key); gsub(regx, repl, val); print "\"" key "\" \"" val "\""}'
    return $?
}

# foo <instance> <database>
list_database_cfg ()
{
    local instance=${1:?}
    local database=${2:?}
    local data

    data=$(su - ${instance} -c "export LANG=C;db2 get db cfg for ${database}" |awk '/ = / {print}')
    echo "${data}" |awk  -v regx="(^[\t ]*|[\t ]*$)" -v repl="" 'BEGIN{FS=" = "}{key = $1; val = $2; gsub(regx, repl, key); gsub(regx, repl, val); print "\"" key "\" \"" val "\""}'
    return $?
}

# foo
set_tsm_const ()
{
    if chk_if_linux; then
        TSM_HOME=/opt/tivoli/tsm
    elif chk_if_aix; then
        TSM_HOME=/usr/tivoli/tsm
    fi
    [[ -n ${TSM_HOME} ]]
    check_status $? "Not found TSM home directory."

    DSM_OPT=${TSM_HOME}/client/api/bin64/dsm.opt
    DSM_SYS=${TSM_HOME}/client/api/bin64/dsm.sys
}

# foo <ip>
chk_if_ipv6 ()
{
    echo "$1" |grep -q ":"
    return $?
}

# foo <url> [GET(default) | POST | DELETE] [data]
# url: give me the part after: https://<ip>:<port>/services/
call_ks_rest ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    get_agent_env || return $?
    # e.g. KERNELSERVICE_URL=https://172.16.65.201:9443/
    local ks_url=$(echo "${KERNELSERVICE_URL}" |cut -d/ -f 1-3)/services
    call_rest "${ks_url}/${url}" "${request}" "${data}"
    return $?
}

# foo <url> [GET(default) | POST | DELETE] [data]
# url: give me the part after: https://<ip>:<port>/services/
call_ks_rest_tgz ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    get_agent_env || return $?
    # e.g. KERNELSERVICE_URL=https://172.16.65.201:9443/
    local ks_url=$(echo "${KERNELSERVICE_URL}" |cut -d/ -f 1-3)/services
    call_rest_tgz "${ks_url}/${url}" "${request}" "${data}"
    return $?
}

# foo <url> [GET(default) | POST | DELETE] [data]
# url: give me the part after: https://<ip>:<port>/storehouse/
call_sh_rest ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    get_agent_env || return $?
    # e.g. DEPLOYMENT_URL=https://172.16.65.201:9444/storehouse/user/deployments/d-9eac3892-093c-468a-a2c9-f60cb07a04c7
    local sh_url=$(echo "${DEPLOYMENT_URL}" |cut -d/ -f 1-3)/storehouse
    call_rest "${sh_url}/${url}" "${request}" "${data}"
    return $?
}

# foo <url> [GET(default) | POST | DELETE] [data]
# url: give me the part after: https://<ip>:<port>/storehouse/user/deployments/<deployment-id>/
call_sh_deployment_rest ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    get_agent_env || return $?
    # e.g. DEPLOYMENT_URL=https://172.16.65.201:9444/storehouse/user/deployments/d-9eac3892-093c-468a-a2c9-f60cb07a04c7
    call_rest "${DEPLOYMENT_URL}/${url}" "${request}" "${data}"
    return $?
}

# foo <curl_url> [GET(default) | POST | DELETE] [data]
# url: give me the full url started with "http"
call_rest ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    curl_contenttype="Content-Type: application/json"
    curl_cert=/0config/cert.tmp/cert_1.pem

    if [[ -n ${data} ]]; then
        case ${request} in
            GET)
                data_option="-o ${data}"
                ;;
            PUT|POST)
                data_option="--data-binary ${data}"
                ;;
        esac
    fi

    get_security_header || return $?
    curl -g -kv -X ${request} -H "${curl_contenttype}" -H "${SECURITY_HEADER}" ${data_option} --url "${url}" --cacert "${curl_cert}"
    return $?
}

# foo <curl_url> [GET(default) | POST | DELETE] [data]
# url: give me the full url started with "http"
call_rest_tgz ()
{
    local url=${1:?}
    local request=${2:-GET}
    local data=$3

    curl_contenttype="Content-Type: application/x-tar"
    curl_cert=/0config/cert.tmp/cert_1.pem

    if [[ -n ${data} ]]; then
        case ${request} in
            GET)
                data_option="-o ${data}"
                ;;
            PUT|POST)
                data_option="--data-binary ${data}"
                ;;
        esac
    fi

    get_security_header || return $?
    curl -g -kv -X ${request} -H "${curl_contenttype}" -H "${SECURITY_HEADER}" ${data_option} --url "${url}" --cacert "${curl_cert}"
    return $?
}

# foo
backup_dsm_sys ()
{
    /bin/cp ${DSM_SYS} ${DSM_SYS}.bak
    return $?
}

# foo
restore_dsm_sys ()
{
    /bin/cp ${DSM_SYS}.bak ${DSM_SYS}
    return $?
}

# foo <new_nodename>
replace_nodename_in_dsm_sys ()
{
    local new_nodename=$1
    local tmpvar=${DSM_SYS}.tmp
    awk -v new=${new_nodename} '{if ($1 == "nodename") {$2 = new}; print}' ${DSM_SYS} > ${tmpvar}
    mv ${tmpvar} ${DSM_SYS}
}

# dos2unix and chmod 777
# foo <workload_dir>
# foo <workload_dir>
fix_workload ()
{
    local dir=${1:?}
    if which dos2unix >/dev/null 2>&1; then
        
        local list=$(find "${dir}" -type f -name "*.sh")
        if [[ -n ${list} ]] ; then
            echo "${list}" |xargs dos2unix
        fi
        
        list=$(find "${dir}" -type f -name "*.sql")
        if [[ -n ${list} ]] ; then
            echo "${list}" |xargs dos2unix
        fi
    else
        #find ${dir} -type f -name "*.sh" -exec sed -i -e "s/\x0D$//g" {} \;
        for f in $(find ${dir} -type f -name "*.sh")
        do
            cp ${f} ${f}_tmp
            sed "s/\x0D$//g" ${f}_tmp > ${f}
            rm ${f}_tmp
        done
    fi
    
    chmod -R 777 "${dir}"
}

# base_dir will be removed from the path of the files stored.
# foo <base_dir> <gz_file> [exclude_file ...]
tar_cz ()
{
    local dir=${1:?}
    local gz_file=${2:?}
    shift 2
    local excludes="${@}"
    excludes="${excludes}"" ""${gz_file}"

    local filelist=$(ls -1A "${dir}") # excludes . and ..
    echo "${excludes[@]}" |xargs -n1 |tar -C "${dir}" -X - -cvf - ${filelist} |gzip > "${gz_file}"
    return $?
}

# foo <instance> <database> <backup_to_dir>
backup_db2_setting ()
{
    local instance=${1:?}
    local database=${2:?}
    local to_dir=$3

    # Generate db2support.zip
    su - ${instance} -c "db2support '${to_dir}' -d ${database} -cl 0"
    # Backup packages
    pckg_file="${to_dir}"/${database}_pckg.txt
    su - ${instance} -c "export LANG=C;db2 connect to ${database}; db2 list packages show detail" > "${pckg_file}"
    # Backup audit settings
    audit_file="${to_dir}"/${instance}_audit.txt
    su - ${instance} -c "export LANG=C;db2db2audit describe" > "${audit_file}"
    # Backup routines
    su - ${instance} -c "/bin/cp -R /home/${instance}/sqllib/function '${to_dir}'/routine_backup"
    return 0
}

start_text_search ()
{
    local inst_name=${1:?}
    local text_search_status="/home/${inst_name}/sqllib/db2tss/config/config.xml"
    if [[ -f ${text_search_status} ]] ; then
        rvl=$(su - ${inst_name} -c "db2ts START FOR TEXT STATUS")

        if [[ ${rvl}  == *STARTED* ]]; then
             su - ${inst_name} -c "db2ts START FOR TEXT "
            return $?
        else
            return 0
        fi
    else
       return 0
    fi
}

stop_text_search ()
{
    local inst_name=${1:?}
    local text_search_status="/home/${inst_name}/sqllib/db2tss/config/config.xml"

    local rvl=$(su - ${inst_name} -c "db2ts START FOR TEXT STATUS")

    if [[ ${rvl}  == *STARTED* ]]; then
       su - ${inst_name} -c "db2ts STOP FOR TEXT "
       return $?
    else
       return 0
    fi 
}

pre_db2_upgrade ()
{
    local instance=${1:?}
    
    # Terminate all unfinished transactions
    force_application ${instance} || return $?
    stop_instance ${instance} 'force' || return $?
   
    
    #stop the text search instance services
    stop_text_search ${instance} || return $?

    # Bring DB2 license daemon down
    su - ${instance} -c "db2licd -end"

    # Unload unused library for AIX
    if chk_if_aix; then
        /usr/sbin/slibclean
    fi

    # Disable DB2 FM
    disable_instance_fm ${instance} || return $?

    # Disable DB2 instance auto-start
    disable_auto_instance ${instance} || return $?

    # IP clean
    su - ${instance} -c ipclean
}

stop_all_instances()
{
  local dbms_home=${1}
  ${dbms_home}/instance/db2ilist|while read instance_name
  do
     echo "stop instance ${instance_name}"
     pre_db2_upgrade ${instance_name}
  done
}

# foo <unpacked_dir> <dbms_home>
db2_upgrade ()
{
    local fixpack_dir=${1:?}
    local dbms_home=${2:?}

    local subdir
    findFixpack=0
    for subdir in server server_r universal awse aese aese_en ese ese_en wse wse_en; do
        if [[ -d "${fixpack_dir}"/${subdir} ]]; then
            echo "current fixpack type is ${subdir}"
            findFixpack=1
            "${fixpack_dir}"/${subdir}/installFixPack -b ${dbms_home} -n -d -t /tmp/installFixPack.trace
            rc=$?
            if [[ ! ${rc} -eq "0" ]] ; then
               return $rc
            else
               #rm -rf ${fixpack_dir}
               return 0 
            fi
        fi
    done
    
    if [[ $findFixpack -eq 0 ]]; then
      echo "does not find the fixpack server server_r universal awse aese aese_en ese ese_en wse wse_en"
      ls ${fixpack_dir}
      return 2
    else
      return 1
    fi
}

upgrade_all_db2_instances ()
{
   local dbms_home=${1}
   hostname `hostname -s`
   ${dbms_home}/instance/db2ilist|while read instance_name
   do
     echo "db2iupdt ${instance_name}"
     message=$(${dbms_home}/instance/db2iupdt ${instance_name})
     rc=$?
     if [[ ${rc} -ne 0 ]]; then
        echo ${message}
        return ${rc}
     fi
   done
   return 0
}


# foo <instance>
post_db2_upgrade ()
{
    local instance=${1:?}
    
    start_instance ${instance} || return $?
    # Enable DB2 FM
    enable_instance_fm ${instance} || return $?

    # enable DB2 instance auto-start
    enable_auto_instance ${instance} || return $?
    
    # start the db2 text search instance services
    start_text_search ${instance}
}

db_db2_upgrade_105(){

local dbms_home=${1:?}

${dbms_home}/instance/db2ilist|while read instance_name
do
	su - ${instance_name} -c "export LANG=C; db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
		echo "db2updv105 ${db_name}"
		message=$(su - ${instance_name} -c "export LANG=C; db2updv105 -d ${db_name}")
		rc=$?
		echo ${rc}
		if [[ ${rc} -ne 0 ]]; then
			echo ${message}
			return ${rc}
		else
			echo "db2updv105 successfull"
			echo ${message}
		return 0
		fi
	done
done  

}
db_db2_upgrade_111(){

local dbms_home=${1:?}

${dbms_home}/instance/db2ilist|while read instance_name
do
	su - ${instance_name} -c "export LANG=C; db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
		echo "db2updv111 ${db_name}"
		message=$(su - ${instance_name} -c "export LANG=C; db2updv111 -d ${db_name}")
		rc=$?
		echo ${rc}
		if [[ ${rc} -ne 0 ]]; then
			echo ${message}
			return ${rc}
		else
			echo "db2updv111 successfull"
			echo ${message}
		return 0
		fi
	done
done  

}

db_db2_upgrade_115(){

local dbms_home=${1:?}

${dbms_home}/instance/db2ilist|while read instance_name
do
	su - ${instance_name} -c "export LANG=C; db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
		echo "db2updv115 ${db_name}"
		message=$(su - ${instance_name} -c "export LANG=C; db2updv115 -d ${db_name}")
		rc=$?
		echo ${rc}
		if [[ ${rc} -ne 0 ]]; then
			echo ${message}
			return ${rc}
		else
			echo "db2updv115 successfull"
			echo ${message}
		return 0
		fi
	done
done  

}
start_all_instances()
{
   local dbms_home=${1}
   ${dbms_home}/instance/db2ilist|while read instance_name
   do
     echo "start instance ${instance_name}"
     post_db2_upgrade ${instance_name}
   done
}

start_all_instances_hadr()
{
    local instance=${1:?}

    start_ha_domain
    start_resource_group ${instance}
    migrate_check
            
    # Enable DB2 FM
    enable_instance_fm ${instance} || return $?

    # enable DB2 instance auto-start
    enable_auto_instance ${instance} || return $?
    
    # start the db2 text search instance services
    start_text_search ${instance}
}

chk_standby_mp_from_primary()
{
	local remoteHostName=$1
	local MOUNT_POINT=$2
	
	if chk_if_linux; then
        . /root/.bash_profile >/dev/null 2>&1
    elif chk_if_aix; then
        . /.profile >/dev/null 2>&1
    fi
	
	ssh ${remoteHostName} mount | grep -q $MOUNT_POINT
	return $?
}

get_mount_point_size ()
{
	local MOUNT_POINT=${1:?}
	local size_g
	
	if chk_if_linux; then
        size_g=`df -h ${MOUNT_POINT} | awk 'BEGIN{RS=""}{print $9}' | awk -FG '{print $1}'`
    elif chk_if_aix; then
        size_g=`df -g | grep "${MOUNT_POINT}" | awk '{print $2}'`
    fi
    echo $size_g
	return $size_g
}

get_volume_group ()
{
    local MOUNT_POINT=${1:?}
    local VOLUME_GROUP=''

	# validate mount point
    if [ "$MOUNT_POINT" == "" ]; then
        return 1
    fi
    
    if chk_if_linux; then
        local LV_NAME=`cat /etc/fstab | grep "$MOUNT_POINT" | awk '{print $1}'`
        VOLUME_GROUP=`lvdisplay $LV_NAME | grep "VG Name" | awk '{print $3}'`
        vgdisplay $VOLUME_GROUP >/dev/null 2>&1
        if [ $? -ne 0 ]; then
	        return 1
	    else
	        echo $VOLUME_GROUP
	    fi 
    elif chk_if_aix; then
        mount_point_info=`lsfs | awk -v MP=$MOUNT_POINT '$3 == MP'`
	    if [ "$mount_point_info" == "" ]; then
	        return 1
	    fi
	
	    local LV_NAME=`lsfs $MOUNT_POINT |grep jfs2 |awk '{print $1}'|awk '{split($0,a,"\/dev\/"); print a[2]}'`
	    VOLUME_GROUP=`lslv $LV_NAME | grep "VOLUME GROUP:" | awk '{print $6}'`
	    lsvg $VOLUME_GROUP >/dev/null 2>&1
	    if [ $? -ne 0 ]; then
	        return 1
	    else
	        echo $VOLUME_GROUP
	    fi   
    fi
    return 0
}

check_new_disk_aix ()
{
    local DISK_SIZE_GB=${1:?}
    
    echo "searching for uninitialized disk of size ${DISK_SIZE_GB}GiB"
    cfgmgr
    local pvs=`lspv -P | grep None | cut -d' ' -f1`
    echo "new pvs = $pvs"
    echo pvtouse=""
    for pv in $pvs
    do
        size=`bootinfo -s $pv`
        let sizeingb=$size/1024
        echo size of $pv is $sizeingb
        if [[ $sizeingb -eq $DISK_SIZE_GB ]]; then
            pvtouse="$pv"
        fi
    done
    
    if [[ "$pvtouse" == "" ]]; then
        logger_info "no free pv found of size ${DISK_SIZE_GB}"
        return 1
    else
        logger_info "found free pv of size ${DISK_SIZE_GB}"
        return 0
    fi
    
}

check_new_disk_linux ()
{
    local disk_size=${1:?}
    
    local DEVICE=$(sfdisk -s 2>/dev/null | grep $(($disk_size * 1024 * 1024))'$' | sed -e 's/:.*//' | sort | while read dev
    do
        if ! parted $dev print >/dev/null; then
            echo $dev
            break
        elif ! sfdisk -V -q $dev >/dev/null 2>&1; then
            echo $dev
            break
        fi
    done)

    if [[ -n "$DEVICE" ]] ; then
        logger_info "found free disk of size ${disk_size}"
        return 0
    else
        logger_info "no free disk found of size ${disk_size}"
        return 1
    fi
}

check_new_disk ()
{
    if chk_if_linux; then
        check_new_disk_linux $*
    elif chk_if_aix; then
        check_new_disk_aix $*
    fi
    
    return $?
}

format_new_disk_aix ()
{
    local DISK_SIZE_GB=${1:?}
    local MOUNT_POINT=${2:?}
    local VOLUME_GROUP=${3:?}
    local inst_name=${4:-"db2inst1"}
    local sysadm_group=${5:-"g_sysadm"}
    FILESYSTEM_TYPE="jfs2"
    
    echo "basic validation of input"
    if [ "$DISK_SIZE_GB" == "" ]; then
        logger_error "DISK_SIZE_GB not provided"
        return 1
    fi
    if [ "$VOLUME_GROUP" == "" ]; then
        logger_error "VOLUME_GROUP not provided"
        return 1
    fi
    
    echo "searching for uninitialized disk of size ${DISK_SIZE_GB}GiB"
    cfgmgr
    pvs=`lspv -P | grep None | cut -d' ' -f1`
    echo "new pvs = $pvs"
    local pvtouse=""
    for pv in $pvs
    do
        size=`bootinfo -s $pv`
        let sizeingb=$size/1024
        echo size of $pv is $sizeingb
        if [ $sizeingb -eq $DISK_SIZE_GB ]; then
            pvtouse="$pv"
        fi
    done
    
    if [ "$pvtouse" == "" ]; then
        logger_error "no free pv found of size ${DISK_SIZE_GB}"
        return 1
    else
    	logger_info "new free pv: $pvtouse is found"
    fi
    
    chdev -l $pvtouse -a "queue_depth=20"
    
    echo "initializing pv $pvtouse for volume group $VOLUME_GROUP"
    lsvg $VOLUME_GROUP
    if [ $? -ne 0 ]; then
        newvg="yes"
        echo "vg does not exist, creating"
        mkvg -f -y $VOLUME_GROUP $pvtouse
        rc=$?
        if [[ $rc -ne 0 ]]; then
            echo "ERROR : Unable to create VG. Check Disk / Physical Volume "
            /usr/sbin/rmdev -dl $pvtouse
            return $rc
        fi
        echo "volume group $VOLUME_GROUP created"
    else
        newvg="no"
        echo "VG already exists, extending"
        extendvg $VOLUME_GROUP $pvtouse
        echo "Post extend pv $pvtouse for volume group $VOLUME_GROUP"
    	lsvg $VOLUME_GROUP
    fi
    
    varyonvg $VOLUME_GROUP
    echo "volume group $VOLUME_GROUP varied online"
    
    if [ "$MOUNT_POINT" == "" ]; then
        echo "No mountpoint specified, can not creating a filesystem"
        return 1
    fi
    
    mount_point_info=`lsfs | awk -v MP=$MOUNT_POINT '$3 == MP'`
    if [ "$mount_point_info" == "" ]; then
        echo "creating filesystem $MOUNT_POINT"
        /usr/sbin/crfs -v $FILESYSTEM_TYPE -g $VOLUME_GROUP  -a size=123M -m $MOUNT_POINT -A ''`locale yesstr | awk -F: '{print $1}'`'' -p'rw' -a agblksize='4096' -a isnapshot=''`locale nostr | awk -F: '{print $1}'`''
        rc=$?
        if [[ $rc -ne 0 ]]; then
            echo "ERROR : Unable to create file system"
            /usr/sbin/reducevg -df $VOLUME_GROUP $pvtouse
            /usr/sbin/rmdev -dl $pvtouse
            return $rc
        fi
        echo "$FILESYSTEM_TYPE filessytem created at $MOUNT_POINT"
    fi
    
    LV_NAME=`lsfs $MOUNT_POINT |grep jfs2 |awk '{print $1}'|awk '{split($0,a,"\/dev\/"); print a[2]}'`
    echo "Logical volume name: $LV_NAME"
    TOTAL_MAX_LPs=`lslv $LV_NAME | grep "MAX LPs" | awk '{print $3}'`
    TOTAL_PVS=`lspv $pvtouse | grep "TOTAL PPs"`
    TOTAL_PVS=`echo $TOTAL_PVS | cut -d \  -f 3`
    echo "total pvs: $TOTAL_PVS"
    echo "Current MAX_LPs: ${TOTAL_MAX_LPs}"
    
    echo "Extending file system"
    # extend the FS to use all the spaces in the VG
    fpline=`lsvg $VOLUME_GROUP | grep "FREE PPs"`
    fpline2=${fpline##*\(}
    freemega=${fpline2%% megabytes\)}
    echo "freemega=${freemega}"
    chfs -a size=+${freemega}M $MOUNT_POINT
    rc=$?
    if [[ $rc -ne 0 ]]; then
        echo "ERROR : Unable to extend the filesystem to max size"
        return $rc
    fi
    
    is_mounted=`mount | awk -v MP=$MOUNT_POINT '$2 == MP'`
    if [ "$is_mounted" == "" ]; then
        echo "File system not mounted, mounting now..."
        mount $MOUNT_POINT
        rc=$?
        if [[ $rc -ne 0 ]]; then
            echo ERROR : Unable to mount file system on $MOUNT_POINT
            return $rc
        fi
        echo "File system mounted successfully"
    fi
    chown -R ${inst_name}:${sysadm_group} $MOUNT_POINT
    rc=$?
    echo "chown -R ${inst_name}:${sysadm_group} $MOUNT_POINT: $rc"
    if [[ ${rc} -ne 0 ]]; then
        return ${rc}
    fi
    echo "df -g $MOUNT_POINT"
    df -g $MOUNT_POINT
    logger_info "Filesystem $MOUNT_POINT has been extended with $freemega Megabytes and mounted."
    
    return 0
}

format_new_disk_linux ()
{
    local disk_size=${1:?}
    local mount_point=${2:?}
    local VOLUME_GROUP=${3:?}
    local inst_name=${4:-"db2inst1"}
    local sysadm_group=${5:-"g_sysadm"}
    local dev_name=""
    
    echo "mount_point is: ${mount_point}"
    echo "disk size is: ${disk_size}"
    
    if [[ ${disk_size} -gt 0 ]] ; then
        echo "re-scan SCSI device"
        ls /sys/class/scsi_host | while read host
        do
            host_path="/sys/class/scsi_host/"${host}"/scan"
            echo "host_path=${host_path}"
            echo "- - -" > ${host_path}
        done
        echo "device list"
        sfdisk -s
        echo "filtered device list by disk_size"
        sfdisk -s 2>/dev/null | grep $(($disk_size * 1024 * 1024))'$' | sed -e 's/:.*//' | sort -r
        echo "get device for specified disk size"
        local version_info=`cat /etc/redhat-release |awk -F" " '{print $7}'`
        if [[ $version_info > 7.0 ]]; then
        DEVICE=$(sfdisk -s 2>/dev/null | grep $(($disk_size * 1024 * 1024))'$' | sed -e 's/:.*//' | sort -r | while read dev
        do
         local partition_table=`parted $dev print|grep Partition|awk '{print $3}'`
         if [[ ${partition_table} == "unknown" ]]; then
            echo $dev
            break
         fi
        done)

        echo "DEVICE is: ${DEVICE}"
        else
        DEVICE=$(sfdisk -s 2>/dev/null | grep $(($disk_size * 1024 * 1024))'$' | sed -e 's/:.*//' | sort -r | while read dev
        do
            if ! parted $dev print >/dev/null; then
                echo $dev
                break
            fi
        done)

        echo "DEVICE is: ${DEVICE}"
        fi
           
        if [ -n "$DEVICE" ]
        then
            # partition and format disk
            #fstype=$(cat /etc/fstab| awk avar=${inst_name} '$2 ~ /^\/home\/avar$/ {print $3}'|uniq)
            fstype='ext3'
            echo "fstype=${fstype}"
            
            # format new disk 
            echo "mkfs -t "${fstype}" ${DEVICE}"
            yes y|mkfs -t "${fstype}" ${DEVICE}
            rc=$?
            if [[ ${rc} -ne 0 ]]; then
            	logger_error "Unable to format device - ${DEVICE} using ${fstype}"
              	return ${rc}
            fi

			# Create PV
			PV=$DEVICE
			
			logger_info "Creating PV"
			pvcreate -y $PV
			rc=$?
			if [[ $rc -ne 0 ]]; then
				logger_error "Unable to create pv - $PV"
			    return $rc
			else
				logger_info "Successfully create PV: $PV"
			fi

            # VG scan
            vgdisplay $VOLUME_GROUP
            if [ $? -ne 0 ]; then
              	logger_info "vg: $VOLUME_GROUP dose not exist, create a new one"
              	vgcreate $VOLUME_GROUP $PV >/dev/null 2>&1
              	rc=$?
			    if [[ $rc -ne 0 ]]; then
			        logger_error "Unable to create a new vg - $VOLUME_GROUP"
			        return $rc
			    else
					logger_info "Successfully create a new VG: $VOLUME_GROUP"
			    fi
            	vgscan
            fi
        	logger_info "Extending vg: $VOLUME_GROUP"
        	vgextend $VOLUME_GROUP $PV
        	rc=$?
		    if [[ $rc -ne 0 ]]; then
		        logger_error "Unable to extend exist vg - $VOLUME_GROUP"
		        return $rc
		    else
				logger_info "Successfully extend exist vg - $VOLUME_GROUP"
		    fi
		    vgdisplay $VOLUME_GROUP
			
            logger_info "Validate if $PV is included into $VOLUME_GROUP"
            echo pvscan
            pvscan | grep $VOLUME_GROUP
            pvscan | grep $VOLUME_GROUP | grep $DEVICE >/dev/null 2>&1
            if [[ $rc -ne 0 ]]; then
			        logger_error "$DEVICE does NOT be included into vg $VOLUME_GROUP"
			        logger_info "Force remove missing device in VG"
            		vgreduce --removemissing -f $VOLUME_GROUP
			        return $rc
			fi

			logger_info "Get Total PE on PV - $PV"
			pvdisplay $PV
			PE=`pvdisplay $PV | grep 'Total PE' | awk '{print $3}'`
			PE=`echo "0+$PE"|bc`
            if [ 0 -eq ${PE} ]; then
            	logger_error "Failed to get Total PE"
			    return 1
			fi
			logger_info "Total PE=${PE} on PV - $PV"

            # Get LV info
            local LV=`cat /etc/fstab | grep ${mount_point} | awk '{print $1}'`
            lvdisplay ${LV}
            rc=$?
            if [[ ${rc} -ne 0 ]]; then
            	logger_error "Unable to get logical volume: $LV"
            	return 1
            fi
            
            # Resize LV
            logger_info "Extending LV: $LV"
            echo "lvextend -l +100%FREE $LV"
            lvextend -l +100%FREE $LV
            rc=$?
            if [[ ${rc} -ne 0 ]]; then
             	logger_error "Unable to extend LV $LV"
			    logger_info "Force remove missing device in VG and try to extend again..."
            	vgreduce --removemissing -f $VOLUME_GROUP
            	echo "lvextend -l +100%FREE $LV"
            	lvextend -l +100%FREE $LV
            	rc=$?
            	if [[ ${rc} -ne 0 ]]; then
            		logger_error "Unable to extend LV $LV in a one more try."
            		return ${rc}
   				fi
            fi
			
			# online resize LV
			logger_info "Online resize LV: $LV..."
			echo "resize2fs $LV"
            resize2fs $LV
            rc=$?
            if [[ ${rc} -ne 0 ]]; then
	            echo "not resize2fs, trying xfs_growfs"
				xfs_growfs $LV
				rc=$?
				if [[ ${rc} -ne 0 ]]; then
					logger_error "Failed to resize LV online"
					return ${rc}
 				fi
            fi

            echo "lvdisplay $LV"
            lvdisplay $LV
            echo "df -h ${mount_point}"
            df -h ${mount_point}
          
            #mount ${mount_point}
            #chown -R ${inst_name}:${sysadm_group} ${mount_point}
            #rc=$?
            #echo "chown -R ${inst_name}:${sysadm_group} ${mount_point}"
            #if [[ ${rc} -ne 0 ]]; then
            #  logger_error "Failed to set permission to mount point ${mount_point}"
            #  return ${rc}
            #fi
        else
            echo "could not determine disk device"
            return 1
        fi
    fi
    
    return 0
}

format_new_disk ()
{
    if chk_if_linux; then
        format_new_disk_linux $*
    elif chk_if_aix; then
        format_new_disk_aix $*
    fi
    
    return $?
}

add_new_dbpath ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    local db_path=${3:?}
    chown -R ${inst_name} ${db_path} 
    su - ${inst_name} -c "db2 connect to ${db_name}; db2 alter database ${db_name} add storage on \'${db_path}\'; db2 disconnect ${db_name}"
    rc=$?
    if [[ ${rc} -ne 0 ]]; then
        if [[ ${rc} -ne 4 ]]; then
            return $?
        fi
    else
        return 0
    fi
}

# ** This function is no longer needed for IPAS, should be removed ** #
set_short_hostname ()
{
	local _hostname
	local _hostname_short
	_hostname=`hostname`
	
	echo ${_hostname} | grep "\."
	local rc=$?
	if [[ 0 -eq ${rc} ]]; then
		_hostname_short=`echo ${_hostname} | tr '.' ' ' | awk '{ print $1; }'`
		hostname ${_hostname_short}
	fi
	
	return $?
}

get_short_hostname ()
{
	local _hostname
	local _hostname_short
	_hostname=`hostname`
	
	echo ${_hostname} | grep -q "\."
	local rc=$?
	if [[ 0 -eq ${rc} ]]; then
		_hostname_short=`echo ${_hostname} | tr '.' ' ' | awk '{ print $1; }'`
	else
		_hostname_short=${_hostname}
	fi 
	echo ${_hostname_short}
	return $?
}

# ** This function is no longer needed for IPAS, should be removed ** #
rebind_ipv4_to_NIC ()
{
	local NIC
	local OS
	local IP='192.168.199.199'
	
	OS=`uname`
	if [[ "${OS}" = "Linux" ]] ; then
		NIC='eth0'
	elif [[ "${OS}" = "AIX" ]] ; then
		NIC='en0'
	fi
	
	ifconfig ${NIC} inet ${IP} netmask 255.255.255.0
	
	return $?
}

check_db2HAdomain_status ()
{
	 local status
	 status=`lsrpdomain | grep db2HAdomain | awk '{print $2}'`
	 if [[ "${status}" == "Online" ]]; then
	 	return 0
	 else
	 	echo "db2HAdomain status is: ${status}"
	 	return 1
	 fi
}

query_tsm_node ()
{
    local adminusername=$1
    local adminpassword=$2
    local rc
    local configured=0
    
    get_tsm_config || return $?
  
    logger_info "Queryig TSM node"
    dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
        query node ${nodename:?} 
EOF
    rc=$?
   
    return ${rc}
}

configure_tsm_node()
{
    local node_name=$1
    local public_ip=$2
    local back_file="${DSM_SYS}$(date +%Y_%m_%d_%H_%M_%S).bak"
    logger_info "${DSM_SYS} backup file is: ${back_file}"
    cp ${DSM_SYS} ${back_file}
    
    logger_info "new value: node_name=$node_name"

    echo ${public_ip} | grep ":" > /dev/null
    if [[ 0 -eq $? ]]; then
        comm_str="commmethod V6TCPIP"    
    else
        comm_str="commmethod TCPIP"
    fi
    
    sed -e "s/nodename .*/nodename ${node_name}/g" -e "s/commmethod .*/${comm_str}/g" ${back_file} > ${DSM_SYS}
    
    if ! grep -q "nodename" ${DSM_SYS} ; then
        echo "nodename ${node_name}" >> ${DSM_SYS}
    fi
    if ! grep -q "commmethod" ${DSM_SYS} ; then
        echo ${comm_str} >> ${DSM_SYS}
    fi  
    
}

configure_tsm_node_for_hadr()
{
#    local node_name=${1:?}
    local as_node_name=${1:?}
    local back_file="${DSM_SYS}$(date +%Y_%m_%d_%H_%M_%S).bak"
    logger_info "${DSM_SYS} backup file is: ${back_file}"
    cp ${DSM_SYS} ${back_file}
    
    logger_info "new value: as_node_name=$as_node_name"
    
#    sed -i "s/nodename .*/nodename ${node_name}/g" ${DSM_SYS}
    
#    if ! grep -q "nodename" ${DSM_SYS} ; then
#        echo "nodename ${node_name}" >> ${DSM_SYS}
#    fi
    
    sed "s/asnodename .*/asnodename ${as_node_name}/g" ${back_file} > ${DSM_SYS}
    
    if ! grep -q "asnodename" ${DSM_SYS} ; then
        echo "asnodename ${as_node_name}" >> ${DSM_SYS}
    fi
}

restore_backup_with_named_pipe ()
{
    local remoteHostName
    local localHostName
    local dbName
    local restoreScriptPath
    local instanceOwner
    local remoteInstanceOwner
    local dbpath
    remoteHostName=${1:?}
    localHostName=${2:?}
    dbName=${3:?}
    restoreScriptPath=${4:?}
    instanceOwner=${5:?}
    remoteInstanceOwner=${6:?}
    dbpath=${7:?}
    logarch=$(db2 get db cfg for ${dbName} | grep LOGARCHMETH1 | awk -F= '{print $2}')
    if [[ "$logarch" == " OFF" ]]; then
        db2 update db cfg for ${dbName} using LOGARCHMETH1 logretain
    fi
    db2 force application all
    db2 backup db ${dbName} to /dev/null
    mkfifo /tmp/tmppipe
    ssh ${remoteInstanceOwner}@${remoteHostName} "${restoreScriptPath} ${dbName} ${localHostName} ${instanceOwner} ${remoteInstanceOwner} ${dbpath}" &
    db2 backup db ${dbName} to /tmp/tmppipe
    rm /tmp/tmppipe
}

backup_to_null ()
{
    local dbName=${1:?}

    force_applicaton_for_db ${dbName}
    db2 backup db ${dbName} to /dev/null
    return $?
}

#====================================For Instance Management=====================================#

#=====================================For User/group management===========================#
addOSProfile ()
{
   local instance_name=$1
   local user_name=$2
   local default_user_model=${3:-'False'}

   if chk_if_linux; then
      user_profile="/home/${user_name}/.bash_profile" 
   else
      user_profile="/home/${user_name}/.profile"
   fi
  
   cmd=". /home/${instance_name}/sqllib/db2profile"
   if ! grep -q "${cmd}" ${user_profile} ; then
        echo "${cmd}" >> ${user_profile}
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed while updating file ${user_profile}"
            return ${rc}
        fi
    fi
    
    chown ${user_name}:`id -g ${user_name}` ${user_profile}
    
    if [[ ${default_user_model_user} == "True" ]] ; then
        chmod 755 /home/${user_name}
    fi
    return 0
}

# linux, aix compatible
change_user_pwd ()
{
    local user_name=${1:?}
    local password=${2:?}
    local rc

    logger_info "Changing password for user: ${user_name}..."
    if chk_if_ksh; then
        echo "${user_name}:${password}"|chpasswd -c >/dev/null 2>&1
    else
        echo "${user_name}:${password}"|chpasswd >/dev/null 2>&1
    fi
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while changing password for user: ${user_name}"
    fi
    return ${rc}
}

add_user_with_id()
{
  local user_name=$1
  local userID=$2
  local user_password=$3
  local group_list=$4
  local user_type=${5:-'OS'}
  local instance_name=${6}
  local default_user_model=${7:-'False'}
  local home_dir=${8:-"/home/${user_name}"}
  
  if [[ -n ${group_list} ]] ; then
      group_list=$(get_group_list_except_user ${user_name} ${group_list})
  fi

  if [[ ${user_type} == "OS" ]] ; then
      if [[ -z ${group_list} ]] ; then
            logger_info "useradd -m -d ${home_dir} -u ${userID} ${user_name}"
            useradd -m -d ${home_dir} -u ${userID} ${user_name}
      else
            primary_group=$(echo ${group_list} | cut -d, -f1)
            logger_info "useradd -m -d ${home_dir} -u ${userID} -g ${primary_group} -G ${group_list} ${user_name}"
            useradd -m -d ${home_dir} -u ${userID} -g ${primary_group} -G ${group_list} ${user_name}
      fi
  else
     primary_group=$(echo ${group_list} | cut -d, -f1)
     mkdir -p /home/${user_name} && chown -R ${user_name}:${primary_group} /home/${user_name}
  fi

  local rc=$?
  if [[ ${rc} -ne 0 ]] ; then
       logger_error 'Failed while creating OS user'
       return ${rc}
  fi
  
  change_user_pwd "${user_name}" "${user_password:?}"
 
  if [[ -n ${instance_name} ]] ; then
     addOSProfile ${instance_name} ${user_name} ${default_user_model}
  fi

  if [[ ${default_user_model} == "True" ]] ; then
     chmod 755 /home/${username}
  fi

  logger_info $(id ${user_name})
  return $?
} 

# foo <user>
# aix, linux, solaris compatible
delete_user ()
{
    local user_name=${1:?}
    local user_type=${2:-'OS'}
    echo "delete user ${user_name}"
    local rc=0
    if chk_if_user_exist "${user_name}" ; then
        if [[ ${user_type} == "OS" ]] ; then
        	if chk_if_linux; then
	        	logger_info "userdel -f -r ${user_name}"
		        userdel -f -r ${user_name}
			else
				logger_info "userdel -r ${user_name}"
		        userdel -r ${user_name}
			fi
            rc=$?
        else
           if [[ -d /home/${user_name} ]] ; then
                logger_info "rm -rf /home/${user_name}"
                rm -rf /home/${user_name}
                rc=$?
           fi
        fi
        if [[ ${rc} -ne 0 ]] ; then
            echo 'Failed while deleting OS user'
            return ${rc}
        fi
    else
       echo "No such user ${user_name}"
       return 0
    fi
    
    return ${rc}
}

change_user_groups ()
{
    local user_name=${1:?}
    local group_list=${2:?}
    
    if [[ -z ${group_list} ]] ; then
        if id -nG ${user_name} 2>/dev/null |egrep -q "(^| )nonssh( |$)"; then
            logger_info "usermod -G nonssh ${user_name}"
            usermod -G nonssh ${user_name}
            rc=$?
        else
            logger_info "usermod -G 100 ${user_name}"
            usermod -G 100 ${user_name}
            rc=$?
        fi
    else
        if id -nG ${user_name} 2>/dev/null |egrep -q "(^| )nonssh( |$)"; then
            logger_info "usermod -G ${group_list},nonssh ${user_name}"
            usermod -G ${group_list},nonssh ${user_name}
            rc=$?
        else
            logger_info "usermod -G ${group_list} ${user_name}"
            usermod -G ${group_list} ${user_name}
            rc=$?
        fi
    fi
    
    logger_info $(id ${user_name})
    
    return ${rc}
}

add_user_to_groups ()
{
    local user_name=${1:?}
    local group_list=${2:?}
    #local sshAccess=${3:'False'}
    
    if [[ -z ${group_list} ]] ; then
        return 0
    fi
    
    group_list=$(id -nG ${user_name}|awk -v new_group_list=${group_list} '{n=split(new_group_list,new_groups, ","); \
                            for(i=0;i<=n;i++) {if(new_groups[i]!="") group[new_groups[i]]=new_groups[i]}; \
                            for(i=2;i<=NF;i++) group[$i]=$i;}\
                        END{for(item in group) printf ","item;printf "\n"}')
    #remove the first "," from the string
    group_list=${group_list#,}
    
    logger_info "usermod -G ${group_list} ${user_name}"
    usermod -G ${group_list} ${user_name}
    rc=$?
    
    logger_info $(id ${user_name})
    return ${rc}
}

remove_user_from_groups ()
{
    local user_name=${1:?}
    local group_list=${2:?}


    group_list=$(id -nG ${user_name}|awk -v new_group_list=${group_list} '{n=split(new_group_list,new_groups, ","); \
                            for(i=2;i<=NF;i++) group[$i]=$i;\
                            for(i=0;i<=n;i++) {delete group[new_groups[i]]}; \
                            }\
                        END{for(item in group) printf ","item;printf "\n"}')
    #remove the first "," from the string
    group_list=${group_list#,}
    
    if [[ -z ${group_list} ]] ; then
        logger_info "usermod -G 100 ${user_name}"
        usermod -G 100 ${user_name}
        rc=$?
    else
        logger_info "usermod -G ${group_list} ${user_name}"
        usermod -G ${group_list} ${user_name}
        rc=$?
    fi
    
    logger_info $(id ${user_name})
    return ${rc}
}

changeUsermod()
{
    local user_name=$1
    local model_type=$2
    chmod ${model_type} /home/${user_name}
}

# aix, linux, solaris compatible
add_group_with_id ()
{
  local group_name=${1:?}
  local group_id=${2:?}
  local group_type=${3:-'OS'}
  local rc=0

  if ! chk_if_group_exist "${group_name}" ; then
     if [[ ${group_type} == "OS" ]] ; then
         if which groupadd >/dev/null 2>&1; then
            logger_info "groupadd -g ${group_id} ${group_name}"
            groupadd -g ${group_id} ${group_name}
            rc=$?
         elif which mkgroup >/dev/null 2>&1; then
            logger_info "mkgroup ${group_name} && mkgroup ${group_name}"
            mkgroup ${group_name} && chgroup id=${group_id} ${group_name}
            rc=$?
         else
            logger_error "No command found for creating OS group"
            rc=1
         fi
     else
        logger_info "lgroupadd -g ${group_id} ${group_name}"
        lgroupadd -g ${group_id} ${group_name}
        rc=$?
     fi
        
     if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while creating group ${group_name}, id is ${group_id}, type is ${group_type}"
        return ${rc}
     fi
  else
     logger_info "Group exists: ${group_name}"
  fi
 
  return 0
}

delete_group(){
   local group_name=$1
   local group_type=${2:-'OS'}
   local rc=0
   if chk_if_group_exist "${group_name}" ; then
      if [[ ${group_type} == "OS" ]] ; then
          if chk_if_linux; then
             groupdel ${group_name}
             rc=$?
          elif chk_if_aix; then
             rmgroup ${group_name}
             rc=$?
          fi
       else
          lgroupdel ${group_name}
          rc=$?
      fi
   else
      echo "No such group: ${group_name}"
   fi
     
   if [[ ${rc} -ne 0 ]] ; then
        logger_error 'Failed while deleting group ${group_name}'
        return ${rc}
   fi
   return ${rc}
}

chk_if_user_exist ()
{
    local user_name=${1:?}
    id -u "${user_name}" >/dev/null 2>&1
    local rc=$?
    if [[ ${rc} -ne 0 ]] ; then
       echo "The user ${user_name} does not exist: ${rc}"
    fi
    return ${rc}
}

chk_if_group_exist ()
{
  local group_name=${1:?}
  local rc=0
  if chk_if_linux; then
     getent group ${group_name} >/dev/null 2>&1
     rc=$?
  elif chk_if_aix; then
     lsgroup ${group_name} >/dev/null 2>&1
     rc=$?
  else
     uname -s |tr A-Z a-z
     rc=1
  fi
        
  if [[ ${rc} -ne 0 ]] ; then
      echo "The group ${group_name} does not exist:${rc}"
  fi
  return ${rc}
}


generate_uid ()
{
  if chk_if_linux; then
     getent passwd | awk -F ':' '{if($3>=500) print $3}' | sort -n | awk 'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}'   
  elif chk_if_aix; then
     lsuser -C ALL | awk -F ':' '{if($2>=500 && $2 != "id") print $2}' | sort -n | awk 'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}'
  fi
  
  return $?
}

generate_gid ()
{
  if chk_if_linux; then
     getent group | awk -F ':' '{if($3>=500) print $3}' | sort -n | awk 'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}'
  elif chk_if_aix; then
     lsgroup -C ALL | awk -F ':' '{if($2>=500 && $2 != "id") print $2}' | sort -n | awk 'BEGIN{min=500;} {if($1==min) min++; else {print min; exit;}}'  
  fi
    	
  return $?			
}

get_gid ()
{
  local group_name=$1
  if chk_if_linux; then
     getent group ${group_name} | awk -F':' {'print $3'}
  elif chk_if_aix; then
     lsgroup ${group_name} | awk -F"[ =]" '{print $3}'
  fi
}

get_user_gid ()
{
   local user_name=$1
   local id_value=$(id -g ${user_name} 2>/dev/null)
   local rc=$? 
   if [[ ${rc} -ne 0 ]] ; then
        echo ""
   else
       echo ${id_value}
   fi
  
   return ${rc}
}

get_user_group_name ()
{
    local user_name=$1
    local id_value=$(id -ng ${user_name} 2>/dev/null)
    local rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        echo ""
    else
        echo "${id_value}"
    fi
}

get_uid ()
{
    local user_name=$1
    local id_value=$(id -u ${user_name} 2>/dev/null)
    local rc=$? 
    if [[ ${rc} -ne 0 ]] ; then
        echo ""
    else
        echo "${id_value}"
    fi
   
    return ${rc}
}

get_group_list_except_user()
{
    local user_name=${1:?}
    local group_list=${2:?}
    group_list=$(echo ${group_list}|awk -v user_name=${user_name} 'BEGIN{k=0}{n=split($0,a, ","); for(i=1;i<=n;i++) {if (a[i]!=user_name) {k=k+1; b[k]=a[i]}}}END{for(i=1;i<=k;i++) printf ","b[i];printf "\n"}')
    echo "${group_list#,}"
}

#=====================================For SSH management===========================#
disable_ssh_for_user ()
{
    local user_name=${1:?}
    local rc

    logger_info "Disabling SSH login for user_name ${user_name}..."

    add_user_to_group ${user_name} ${NONSSH_GROUP}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while adding user ${user_name} to group ${NONSSH_GROUP}"
        return ${rc}
    fi

    return 0
}

enable_ssh_for_user ()
{
    local user_name=${1:?}
    local rc

    logger_info "Enabling SSH login for user ${user_name}..."

    remove_user_from_group ${user_name} ${NONSSH_GROUP}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed while removing user ${user_name} from group ${NONSSH_GROUP}"
        return ${rc}
    fi

    return 0
}

#=====================================For HADR===========================#
check_db_role ()
{
    local instance_name=${1:?}
    local db_name=${2:?}
    role=$(su - $instance_name -c "db2 get db cfg for $db_name" | grep "HADR database role" | awk -F= '{print $2}')
    echo ${role}
    return 0
}

check_remote_db_role ()
{
    local instance_name=${1:?}
    local db_name=${2:?}
    local remote_host=${3:?}
    if chk_if_linux; then
        . ${HOME}/.bash_profile
    elif chk_if_aix; then
        . ${HOME}/.profile
    fi
    role=$(ssh ${instance_name}@${remote_host} db2 get db cfg for $db_name| grep "HADR database role" | awk -F'= ' '{print $2}')
    echo ${role}
    return 0
}

takeover_hadr ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    logger_begin
    logger_info "db2 takeover hadr on database ${db_name}"
    echo "Running: db2 takeover hadr on database ${db_name}"
    su - ${inst_name} -c "db2 takeover hadr on database ${db_name}"
    rc=$?
    logger_end
    return $rc
}

hadr_monitor ()
{
    local db_name=${1:?}
    local inst_name=${2:?}
    local hadr_role=`su - $inst_name -c "db2pd -db $db_name -hadr" | grep "HADR_ROLE" | awk -F= '{print $2}'`
    local hadr_state=`su - $inst_name -c "db2pd -db $db_name -hadr" | grep "HADR_STATE" | awk -F= '{print $2}'`
    
    hadr_role=`echo ${hadr_role} | sed 's/^ //;s/ $//'`
    hadr_state=`echo ${hadr_state} | sed 's/^ //;s/ $//'`
    echo "{\"role\":\"$hadr_role\", \"hadr_status\":\"$hadr_state\"}"
    return 0
}

reset_standby_tsm_node ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    local tsm_node_name=${3:?}
    
    su - ${inst_name} -c "db2 update db cfg for ${db_name} USING TSM_NODENAME ${tsm_node_name} TSM_OWNER ${tsm_node_name}"
    return $?
}

pipe_restore ()
{
    local db_name=${1:?}
    local remotelHostName=${2:?}
    local inst_name=${3:?}
    local dbpath=${4:?}

    if [[ -z /tmp/tmppipe ]]; then 
        rm -f /tmp/tmppipe
    fi
    mkfifo /tmp/tmppipe
    ssh ${remotelHostName} 'cat /tmp/tmppipe' > /tmp/tmppipe &
    su - ${inst_name} -c "db2 restore db ${db_name} from /tmp/tmppipe DBPATH on ${dbpath} replace history file replace existing"
    rm -f /tmp/tmppipe 
    return 0
}

deactivate_db ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    su - ${inst_name} -c "db2 DEACTIVATE database ${db_name}"
    rc=$?
    return $rc
}

stop_hadr_db ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    su - ${inst_name} -c "db2 stop hadr on database ${db_name}"
    rc=$?
    return $rc
}

start_hadr_primary_db ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    su - ${inst_name} -c "db2 start hadr on database ${db_name} as primary"
    rc=$?
    return $rc
}

start_hadr_standby_db ()
{
    local inst_name=${1:?}
    local db_name=${2:?}
    su - ${inst_name} -c "db2 start hadr on database ${db_name} as standby"
    rc=$?
    return $rc
}

get_instance_name_list ()
{
   local dbms_home=${1}
   ${dbms_home}/instance/db2ilist|while read instance_name
   do
     echo ${instance_name}
   done
}


get_standby_db_list ()
{
	local inst_name=${1}
	su - ${inst_name} -c "export LANG=C; db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
	    su - ${inst_name} -c "export LANG=C; db2 get db cfg for ${db_name}"|grep -q "HADR database role * = STANDBY" && echo ${db_name}
	done
}


get_primary_db_list ()
{
	local inst_name=${1}
	su - ${inst_name} -c "export LANG=C; db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
		su - ${inst_name} -c "export LANG=C; db2 get db cfg for ${db_name}"|grep -q "HADR database role * = PRIMARY" && echo ${db_name}
	done
}

take_over_databases ()
{
    local inst_name=${1}
    shift 1
    for db_name in "$@"; do
	    db_role=$(su - ${inst_name} -c "export LANG=C; db2 get db cfg for ${db_name}" | grep "HADR database role" | awk -F= '{print $2}')
	    if [[ "${db_role}" -eq "STANDBY" ]]; then
	    	su - ${inst_name} -c "export LANG=C; db2 takeover hadr on db ${db_name}"
	    	rc=$?
	    	if [[ ${rc} -ne 0 ]] ; then
	    	    logger_error "takeover failed, database name is ${db_name}, rc=${rc}"
	    	fi
	    fi
    done
}

check_hadr_db_status ()
{
	local inst_name=${1}
	su - ${inst_name} -c "db2 list db directory" | grep "Database name" | awk -F"= " '{ print $2 }'|while read db_name
	do
	    db_role=$(su - ${inst_name} -c "export LANG=C; db2 get db cfg for ${db_name}" | grep "HADR database role" | awk -F"= " '{print $2}')
	    echo "${db_name} is ${db_role} database"
	    if [[ "${db_role}" -eq "STANDBY" ]] || [[ "${db_role}" -eq "PRIMARY" ]]; then
	    	hadr_state=$(su - ${inst_name} -c "export LANG=C; db2pd -hadr -db ${db_name}" | grep "HADR_STATE" | awk -F"= " '{print $2}')
	    	if [[ "${hadr_state}" != "PEER" ]]; then
	    		return 1
	    	fi
	    fi
	done
	return 0
}

stop_rp_node ()
{
    logger_begin
    logger_info "stop_rp_node"
    # Stop the cluster node (the standby server) and confirm the change:
    short_hostname=`echo $(hostname) | tr '.' ' ' | awk '{ print $1; }'`
    logger_info "stoprpnode ${short_hostname}"
    stoprpnode ${short_hostname}
    sleep 10
    lsrpnode
    domain_status=$(lsrpdomain | tail -n1 | awk '{print $2}')
    logger_info "domain status is ${domain_status}"
    if [[ "${domain_status}" != "Offline" ]]; then
        logger_error "domain status should be Offline, but ${domain_status} instead, stop domain by force"
        stoprpnode -f ${short_hostname}
        rc=$?
        force_domain_status=$(lsrpdomain | tail -n1 | awk '{print $2}')
        logger_info "domain status after force stop is ${force_domain_status}"
        logger_end
        return $rc
    else
        logger_info "domain status successfully changed to ${domain_status}"
        logger_end
        return 0
    fi
}

stop_resource_group ()
{
    logger_begin
    logger_info "stop_resource_group ${1}"
    local inst_name=${1}
    local rpdomain inst_resource_group domain_status resource_group_status rc short_hostname try_time

    rpdomain=$(lsrpdomain | tail -n1 | awk '{print $1}')
        
    if [[ "${rpdomain}" != "" ]]; then
        lssam -nocolor
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_info "lssam error, it may be stopped already, rc=${rc}"
        fi
        short_hostname=$(echo $(hostname) | tr '.' ' ' | awk '{ print $1; }')
        inst_resource_group=$(lssam -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${short_hostname}_ | awk 'BEGIN{FS="[:]"}{print $2}'| awk 'BEGIN{FS="[ ]"}{print $1}')
    else
        return 1
    fi
    
    logger_info "chrg -o offline ${inst_resource_group}"
    chrg -o Offline ${inst_resource_group}
    rc=$?
    logger_info "chrg -o Offline ${inst_resource_group}, rc=${rc}"
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "chrg Offline ${inst_resource_group}: command returned ${rc}"
        logger_end
        return ${rc}
    else
        #check status
        count=0
        while [ ${count} -le 10 ]
        do
            count=$((${count}+1))
            logger_info " Try=${count} -Check resource group Status for ${inst_resource_group}"
            resource_group_status=$(lssam -g ${inst_resource_group}  -nocolor | grep ${inst_resource_group} | awk 'BEGIN{FS="[ \t]"}{print $1}')
            if [[ "${resource_group_status}" == "Offline" ]]; then
                logger_info "resource group : ${inst_resource_group} status change to : ${resource_group_status} successful"
                lssam -nocolor
                break
            else
                echo "${inst_resource_group} should be Offline, but is ${resource_group_status} instead, try=${count}"
                sleep 10
                if [[ ${i} -eq 10 ]]; then
                    logger_error "stop resource group timeout"
                    logger_end
                    return 1
                fi
            fi
        done
    fi
    logger_end
}


start_ha_domain ()
{
    logger_begin    
    
    local rpdomain resource_group domain_status resource_group_status rc short_hostname
    rpdomain=$(lsrpdomain | tail -n1 | awk '{print $1}')

    # Start the server and bring the resource group back online:
    logger_info "startrpdomain ${rpdomain}"
    startrpdomain ${rpdomain}
    rc=$?
    logger_info "startrpdomain ${rpdomain}, rc=${rc}"
    sleep 20
    rc=1
    while [ ${rc} -ne 0 ]
    do
        lsrpdomain
        rc=$?
        sleep 4
    done
    count=0
    while [ ${count} -le 20 ]
    do
        count=$((${count}+1))
        domain_status=$(lsrpdomain | tail -n1 | awk '{print $2}')
        logger_info "${rpdomain} domain status is ${domain_status}"
        if [[ "${domain_status}" == "Online" ]]; then
            logger_info "${rpdomain} is (${domain_status}) now"
            break
        else
            logger_info "domain status should be Online, but {domain_status} instead"
            sleep 10
        fi
    done
    count=0
    while [ ${count} -le 20 ]
    do
        count=$((${count}+1))
        lssam -nocolor
        rc=$?
        if [[ $rc -eq 0 ]]; then
            logger_end
            return 0
        else
            logger_info "lssam not ready, count=${count}"
            sleep 10
        fi
    done
}

start_resource_group ()
{
    logger_begin
    logger_info "start_resource_group"
	local inst_name=${1}
	local rpdomain inst_resource_group domain_status resource_group_status rc short_hostname

	logger_info "Bring instance resource group online"
	rpdomain=$(lsrpdomain | tail -n1 | awk '{print $1}')
	if [[ "${rpdomain}" != "" ]]; then
		short_hostname=$(echo $(hostname) | tr '.' ' ' | awk '{ print $1; }')
        inst_resource_group=$(lssam -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${short_hostname}_ | awk 'BEGIN{FS=":"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}')
	else
	    logger_error "rpdomain is empty"
	    logger_end
		return 1
	fi
	
	logger_info "Check Control=StartInhibitedBecauseSuspended problem"
	lssam  -nocolor| grep "rs Control=StartInhibitedBecauseSuspended" | awk 'BEGIN{FS=":"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' |while read db_resource
	do
        logger_info "db_resource is ${db_resource}, state StartInhibitedBecauseSuspended"
	done
	
	logger_info "inst_resource_group is ${inst_resource_group}, chrg -o Online ${inst_resource_group}"
	chrg -o Online ${inst_resource_group}
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Error: chrg -o Online ${inst_resource_group}"
        logger_end
        return ${rc}
    else
        #check status
        count=0
        while [ ${count} -le 20 ]
        do
            count=$((${count}+1))
            resource_group_status=$(lssam -g ${inst_resource_group}  -nocolor | grep ${inst_resource_group} | awk 'BEGIN{FS="[ \t]"}{print $1}')
            if [[ "${resource_group_status}" == "Online" ]]; then
                logger_info "inst_resource_group: ${inst_resource_group} is Online now"
                break
            else
                logger_info "inst_resource_group: ${inst_resource_group} should be Online, but is ${resource_group_status} instead, count=${count}"
                sleep 10
                if [[ ${count} -eq 20 ]]; then
                	logger_error "start resource group timeout"
                fi
            fi
        done
	fi

    logger_info "Unlock database resource group"
	lssam  -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${inst_name}_ | awk 'BEGIN{FS="[:]"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' |while read db_resource_group
	do
        logger_info "lssam  -nocolor| grep IBM.ResourceGroup:${db_resource_group} | grep Request=Lock"
        lssam  -nocolor| grep IBM.ResourceGroup:${db_resource_group} | grep Request=Lock
        rc=$?
        if [[ $rc -eq 0 ]]; then
            logger_info "rgreq -o unlock ${db_resource_group}"
            rgreq -o unlock ${db_resource_group}
            count=0
            logger_info "Wait for database resource group to be online"
            while [ ${count} -le 20 ]
            do
                count=$((${count}+1))
                db_resource_group_status=$(lssam -nocolor| grep IBM.ResourceGroup:${db_resource_group} | awk 'BEGIN{FS="[ \t]"}{print $1}')
                if [[ "${db_resource_group_status}" == "Online" ]]; then
                    logger_info "db_resource_group: ${db_resource_group} is Online now"
                    break
                else
                    logger_info "db_resource_group: ${db_resource_group} should be Online, but is ${db_resource_group_status} instead, count=${count}"
                    sleep 10
                    if [[ ${count} -eq 20 ]]; then
                        logger_error "start resource group(${inst_resource_group}) timeout"
                    fi
                fi
            done
        fi
	done

    logger_info "Reset resource group status which is MemberInProblemState"
	lssam  -nocolor| grep "rs Control=MemberInProblemState" | awk 'BEGIN{FS=":"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' |while read db_resource
	do
        logger_info "db_resource is ${db_resource}, resetrsrc -s Name = ${db_resource} IBM.Application"
	    resetrsrc -s "Name = '${db_resource}'" IBM.Application
	    sleep 12
	done

    logger_info "Unlock instance resource group"
	lssam  -nocolor| grep IBM.ResourceGroup:${inst_resource_group} | grep Request=Lock
	rc=$?
    if [[ $rc -eq 0 ]]; then
        logger_info "rgreq -o unlock ${inst_resource_group}"
        rgreq -o unlock ${inst_resource_group}
        sleep 10
    fi

    logger_info "Activate database on standby host"
    lssam  -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${inst_name}_ | awk 'BEGIN{FS="[:]"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' | awk 'BEGIN{FS="[_-]"}{print $4}' |while read db_name
    do
        logger_info "Activate ${db_name}, on standby "
        status=$(lssam  -nocolor| grep "Offline IBM.Application:db2_${inst_name}_${inst_name}_${db_name}")
        logger_info "status = ${status}"
        logger_info "su - ${inst_name} -c db2 activate db ${db_name}"
        su - "${inst_name}" -c "db2 activate db ${db_name}"
    done
    
    logger_info "Final unlock database resource group"
	lssam  -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${inst_name}_ | awk 'BEGIN{FS="[:]"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' |while read db_resource_group
	do
        logger_info "lssam  -nocolor| grep IBM.ResourceGroup:${db_resource_group} | grep Request=Lock"
        lssam  -nocolor| grep IBM.ResourceGroup:${db_resource_group} | grep Request=Lock
        rc=$?
        if [[ $rc -eq 0 ]]; then
            logger_info "rgreq -o unlock ${db_resource_group}"
            rgreq -o unlock ${db_resource_group}
            sleep 10
        fi
	done

    logger_info "Final check database resource group status"
	lssam  -nocolor| grep IBM.ResourceGroup:db2_${inst_name}_${inst_name}_ | awk 'BEGIN{FS="[:]"}{print $2}'| awk 'BEGIN{FS=" "}{print $1}' |while read db_resource_group
	do
        logger_info "Check if database resource group:${db_resource_group} is online"
        while [ ${count} -le 20 ]
        do
            count=$((${count}+1))
            db_resource_group_status=$(lssam -nocolor| grep IBM.ResourceGroup:${db_resource_group} | awk 'BEGIN{FS="[ \t]"}{print $1}')
            logger_info "db_resource_group ${db_resource_group} is ${db_resource_group_status}" 
            if [[ "${db_resource_group_status}" == "Online" ]]; then
                logger_info "db_resource_group: ${db_resource_group} is Online now"
                lssam -nocolor
                break
            else
                logger_info "db_resource_group: ${db_resource_group} should be Online, but is ${db_resource_group_status} instead, count=${count}"
                sleep 10
                if [[ ${count} -eq 20 ]]; then
                    logger_error "start resource group ${inst_resource_group} timeout"
                fi
            fi
        done
	done

	logger_info "start_resource_group done for ${inst_resource_group} "
	
	
    logger_info "Check TSA tiebreaker configuration..."
    lsrsrc -c IBM.PeerNode OpQuorumTieBreaker | grep 'DB2_HADR_TB'    
    rc=$?
    if [[ $rc -eq 0 ]]; then
        if chk_if_linux; then
            logger_info "iSCSI tiebreaker is configured, start iscsi service for linux"
            service iscsi start   
            NODE_KEY=`/usr/sbin/rsct/bin/lsnodeid`
            ISCSI_DEVICE=`iscsiadm -m session -P 3 | grep 'scsi disk' | awk '{print $4}'`
            sg_persist --out --no-inquiry --register --param-sark=0x${NODE_KEY} --device="/dev/${ISCSI_DEVICE}"
            sg_persist --out --no-inquiry --clear --param-rk=0x${NODE_KEY} --device="/dev/${ISCSI_DEVICE}"
        fi        
        
        if chk_if_aix; then
            logger_info "iSCSI tiebreaker is configured, assign pvid to new disk"
            new_PV=`lspv | grep None | awk '{print $1}'`
            chdev -l $new_PV -a pv=yes
            lspv
        fi           
    fi
    
    
    
	logger_end
	return 0
}


migrate_check ()
{
    logger_begin
    logger_info "migrate_check"
	# Migrate the TSA domain:
	export CT_MANAGEMENT_SCOPE=2
	runact -c IBM.PeerDomain CompleteMigration Options=0
	samctrl -m<<EOF
Y
EOF
	# Ensure that MixedVersions is no longer set to Yes for the cluster component:
	mixed_versions=$(lsrpdomain | tail -n1 | awk -F' ' '{print $4}')
	if [[ "${mixed_versions}" == "Yes" ]]; then
	    logger_error "mixed_versions=${mixed_versions}"
	    logger_end
		return 1
	fi

	# Ensure that the active version number (AVN) matches the installed version number (IVN) for the HA manager:
	avn_version=$(lssrc -l -s IBM.RecoveryRM |grep "AVN" | awk '{print $4}')
	ivn_version=$(lssrc -l -s IBM.RecoveryRM |grep "IVN" | awk '{print $4}')
	if [[ "${avn_version}" != "${ivn_version}" ]]; then
	    logger_error "avn_version=${avn_version}, ivn_version=${ivn_version}"
		return 1
	fi
	logger_end
	return 0
}

hadr_rolling_uprade ()
{
	logger_begin
	logger_info "hadr_rolling_uprade"
	dbms_home=${1}
	fixpack_dir=${2}
	instance_name=${3}
	#make sure instance is online
	logger_info "start_ha_domain"
	start_ha_domain
	logger_info "start_resource_group ${instance_name}"
	start_resource_group ${instance_name}

    logger_info "stop_resource_group ${instance_name}"
	stop_resource_group ${instance_name}
	logger_info "stop_rp_node"
	stop_rp_node || (logger_end && return $?)
	logger_info "db2_upgrade ${fixpack_dir} ${dbms_home}"
	db2_upgrade ${fixpack_dir} ${dbms_home}
	rc=$?
	logger_info "db2_upgrade ${fixpack_dir} ${dbms_home} , rc=${rc}"
	logger_info "start_ha_domain"
	start_ha_domain || (logger_end && return $?)
	logger_info "start_resource_group ${instance_name}"
	start_resource_group ${instance_name}
	logger_end
	return ${rc}
}

hadr_start_all ()
{
    logger_info "start_ha_domain"
	start_ha_domain
	${dbms_home}/instance/db2ilist|while read instance_name
	do
	  logger_info "start_resource_group ${instance_name}"
	  start_resource_group ${instance_name}
	done
}

#=========================For DBMS===================================#
install_dbms()
{
	if [[ $# -lt 1 ]]; then
	    echo "Wrong number of arguments"
	    echo "$0 <installDir>"
	    return 1
	fi
	
	local installDir=$1
	# ref. http://publib.boulder.ibm.com/infocenter/db2luw/v9/topic/com.ibm.db2.udb.uprun.doc/doc/t0023683.htm
	${installDir}/bin/db2greg -addservrec service=DB2,specialinstallnumber=0
	
	# ref. http://publib.boulder.ibm.com/infocenter/db2luw/v9r7/topic/com.ibm.db2.luw.admin.cmd.doc/doc/r0023668.html
	ln -sf ${installDir}/install/db2ls /usr/local/bin/db2ls
	return $?
}

install_tsamp()
{
    if [[ $# -lt 2 ]]; then
        echo "Wrong number of arguments"
        echo "$0 <installDir>"
        return 1
    fi
    
    if chk_if_linux;then

    	version_info=`cat /etc/redhat-release |awk -F" " '{print $7}'`
    	if [[ $version_info > 7.0 ]];then
    		local tsampDir=${1}/tsamp64
    	elif [[ ${2} -eq 1 ]];then
    		local tsampDir=${1}/tsamp32
    	else 
    		local tsampDir=${1}/tsamp64
    	fi
        #for backward compatibility with 1.2.1.0 where
        #we do not have 64 and 32 bit tsamp dirs
        if [[ ! -d ${tsampDir} ]];then
        	local tsampDir=${1}/tsamp
        fi
    else
    	local tsampDir=${1}/tsamp
    	# to fix defect 235183
    	# prereqSAM file need to updated
    	cd ${tsampDir}
    	sed 's/$GREP -Ev ".*64.*"/$GREP -E "32-bit"/g' prereqSAM > prereqSAM.$$
    	sed 's/$GREP -Ev ".*64.*"/$GREP -E "32-bit"/g' installSAM > installSAM.$$
    	mv prereqSAM.$$ prereqSAM   
    	mv installSAM.$$ installSAM 	
    	chmod 555 prereqSAM installSAM   	
    fi
    
    if [[ -d ${tsampDir} ]]; then
       cd ${tsampDir}
       ${tsampDir}/installSAM --noliccheck --silent
    fi
    return $?
}

configure_tsm()
{
    logger_begin
    logger_info "Params: $*" |pipe_mask "$3"
    
    # Executed by root
    
    local inst_name=${1:?}
    #db_name=${2:?}
    local adminusername=${2:?}
    local adminpassword=${3:?}
    local nodename=${4:?}
    local db2domain=${5:?}
    local public_ip=${6:?}
    
    configure_tsm_node "${nodename}" "${public_ip}" || exit $?
    config_instance_for_tsm "${inst_name}" || exit $?
    #config_database_for_tsm "${inst_name}" "${db_name}" "${adminpassword}" || exit $?
    #config_database_as_tsm_archive "${inst_name}" "${db_name}" || exit $?
    register_tsm_node "${adminusername}" "${adminpassword}" "${db2domain}" || exit $?
    
    logger_end
    return 0
}

set_lang()
{
	local territory=${1:?}
	local codeset=${2:?}
	local database=${3?}
	local locale
                 
	# get territory and codeset from db cfg if not provided
	if [[ " " == "${territory}"  ||  " " == "${codeset}" ]];then
		__getTerritoryCodesetFromDB()
		{
			local database=${1?}
		    local cmd="GET DB CFG FOR ${database} | egrep -i 'territory|code set'"
		    local tmpvar
		    tmpvar=$(db2 terminate;export LANG=C;db2 -v ${cmd}) || return $?
		    territory=$(echo "${tmpvar}" | grep "territory" | awk -F= '{print $2}' | tr -d " ")
		    codeset=$(echo "${tmpvar}" | grep "code set" | awk -F= '{print $2}' | tr -d " ")
		    return $?
		}
		__getTerritoryCodesetFromDB ${database}
	fi

	locale=$(territory_locale_mapping ${territory})
	if [[ ! -n ${locale} ]];then
		locale="en_US"
	fi

	if [[ ! -n ${codeset} ]];then
		codeset="UTF-8"
	fi
	
	echo "export LANG=${locale}.${codeset}"
	return $?
}

territory_locale_mapping()
{
	local territory=$1
	  # Supported Territory list #
	  ###################################################
	  #		US AL AA AU AT AZ BY BE BG BR \
	  #       CA CN HR CZ DK EE FI MK FR DE \
	  #       GR HK HU IS IN ID IE IL IT JP \
	  #       KZ KR Lat LV LT MY MT ME NL NZ \
	  #       NO PK PL PT RO RU SP SK SI ZA \
	  #       ES SE CH TW TH TR GB UA VN  
	  ###################################################
	  
	case ${territory} in
		"US")
			echo "en_US";;
		"AL")
			echo "sq_AL";;
		"AA")
			echo "ar_AA";;
		"AU")
			echo "en_AU";;
		"AZ")
			echo "";;
		"BY")
			echo "be_BY";;
		"BE")
			echo "fr_BE";;
		"BG")
			echo "bg_BG";;
		"BR")
			echo "pt_BR";;
		"CA")
			echo "en_CA";;
		"CN")
			echo "zh_CN";;
		"HR")
			echo "hr_HR";;
		"CZ")
			echo "cs_CZ";;
		"DK")
			echo "da_DK";;
		"EE")
			echo "Et_EE";;
		"FI")
			echo "fi_FI";;
		"MK")
			echo "mk_MK";;
		"FR")
			echo "fr_FR";;
		"DE")
			echo "de_DE";;
		"GR")
			echo "el_GR";;
		"HK")
			echo "zh_HK";;
		"HU")
			echo "hu_HU";;
		"IS")
			echo "is_IS";;
		"IN")
			echo "hi_IN";;
		"ID")
			echo "";;
		"IE")
			echo "en_IE";;
		"IL")
			echo "iw_IL";;
		"IT")
			echo "it_IT";;
		"JP")
			echo "ja_JP";;
		"KZ")
			echo "";;
		"KR")
			echo "ko_KR";;
		"Lat")
			echo "";;
		"LV")
			echo "Lv_LV";;
		"LT")
			echo "Lt_LT";;
		"MY")
			echo "";;
		"MT")
			echo "";;
		"ME")
			echo "";;
		"NL")
			echo "nl_NL";;
		"NZ")
			echo "en_NZ";;
		"NO")
			echo "no_NO";;
		"PK")
			echo "";;
		"PL")
			echo "pl_PL";;
		"PT")
			echo "pt_PT";;
		"RO")
			echo "ro_RO";;
		"RU")
			echo "ru_RU";;
		"SP")
			echo "sr_SP";;
		"SK")
			echo "sk_SK";;
		"SI")
			echo "sl_SI";;
		"ZA")
			echo "en_ZA";;
		"ES")
			echo "es_ES";;
		"SE")
			echo "sv_SE";;
		"CH")
			echo "de_CH";;
		"TW")
			echo "zh_TW";;
		"TH")
			echo "th_TH";;
		"TR")
			echo "tr_TR";;
		"GB")
			echo "en_GB";;
		"UA")
			echo "uk_UA";;
		"VN")
			echo "Vi_VN";;
	esac	
}

check_db2_prereq()
{
local temp_fixpackdir=${1}
   
   logger_info "DB2 Install Path - ${temp_fixpackdir}"
   if chk_if_aix; then
	message=$(echo "yes" | ${temp_fixpackdir}/universal/db2prereqcheck -l 2>&1 | grep -E "No space left on device|does not have enough free space")
   else
	message=$(${temp_fixpackdir}/universal/db2prereqcheck -l 2>&1 | grep -E "No space left on device|does not have enough free space")
   fi
   if [[ "${message}" == "" ]]; then
      echo "${message}"
      echo "--------------------Prereq check successful for space availability------------------------"
      return 1
   else
      echo "${message}"
      echo "--------------------Prereq check failed for space availability----------------------"
      echo $(df -h)
      return 0
   fi
   
}

set_tsm_const
NONSSH_GROUP=nonssh
PYTHON_CMD=/opt/python*/bin/python