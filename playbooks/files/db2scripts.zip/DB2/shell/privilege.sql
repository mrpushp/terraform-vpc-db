--=========================================================================
--*
--* Licensed Materials - Property of IBM
--* 5725F36, 5725F48
--* Copyright IBM Corporation 2009, 2020.
--* US Government Users Restricted Rights - Use, duplication or disclosure
--* restricted by GSA ADP Schedule Contract with IBM Corp.
--*
--=========================================================================
-- APPDBA
CREATE ROLE <ROLE_APPDBA>;

-- Grant authorities to role
GRANT DBADM, CREATE_NOT_FENCED, LOAD, CREATE_EXTERNAL_ROUTINE 
    ON DATABASE TO ROLE <ROLE_APPDBA>;

-- Grant role to user
GRANT ROLE <ROLE_APPDBA> TO USER <USER_APPDBA>;

