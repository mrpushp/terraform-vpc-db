#!/bin/sh

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
# Recommended when using TSA commandline tooling.
export CT_MANAGEMENT_SCOPE=2
# Set name of TSA domain for DB2.
TSADOMAIN=`lsrpdomain | tail -n1 | awk '{print $1}'`

OS=`/bin/uname`

if [ "$OS" == "Linux" ]; then
    ISCSI_DEVICE=`iscsiadm -m session -P 3 | grep 'scsi disk' | awk '{print $4}'`
    # Print ID of local TSA node.
    /usr/sbin/rsct/bin/lsnodeid
    # Test iSCSI device tiebreaker by obtaining lock.
    /usr/sbin/rsct/bin/tb_break -l -t SCSIPR "DEVICE=/dev/${ISCSI_DEVICE}"
    # Confirming that iSCSI device has been locked by local TSA node.
    sg_persist --read-reservation /dev/${ISCSI_DEVICE}
    # Test iSCSI device tiebreaker by releasing lock.
    /usr/sbin/rsct/bin/tb_break -u -t SCSIPR "DEVICE=/dev/${ISCSI_DEVICE}"
    # Define new tiebreaker using iSCSI device in TSA.
    mkrsrc IBM.TieBreaker Name="DB2_HADR_TB" Type=SCSIPR DeviceInfo="DEVICE=/dev/${ISCSI_DEVICE}" HeartbeatPeriod=1    
else
     ISCSI_DEVICE=`lspv | grep None | awk '{print $2}'`
     # Test iSCSI device tiebreaker by obtaining lock
     /usr/sbin/rsct/bin/tb_break �l �t DISK "PVID=${ISCSI_DEVICE}"
     # Test iSCSI device tiebreaker by releasing lock.
     /usr/sbin/rsct/bin/tb_break -u -t DISK "PVID=${ISCSI_DEVICE}"
     # Define new tiebreaker using iSCSI device in TSA.
     mkrsrc IBM.TieBreaker Name="DB2_HADR_TB" Type=DISK DeviceInfo="PVID=${ISCSI_DEVICE}" HeartbeatPeriod=1
fi

# List newly defined iSCSI tiebreaker in TSA.
lsrsrc -s 'Name like "DB2_HADR_TB"' IBM.TieBreaker
# Set current tiebreaker in TSA to newly defined iSCSI tiebreaker.
chrsrc -c IBM.PeerNode OpQuorumTieBreaker="DB2_HADR_TB"
# List tiebreaker currently set in TSA.
lsrsrc -c IBM.PeerNode OpQuorumTieBreaker
# Restart TSA domain in order to ensure that any changes in /var/ct/cfg/netmon.cf are taken into account...
stoprpdomain -f ${TSADOMAIN}; lsrpdomain; sleep 30; startrpdomain ${TSADOMAIN}; sleep 30; lsrpdomain
