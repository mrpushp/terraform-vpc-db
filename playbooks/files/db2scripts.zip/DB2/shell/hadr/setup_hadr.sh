#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#******************************************************************************
#
# Command-line arguments:
#   -database                 [string]    SAMPLE
#   -instance                 [string]    db2inst1
#   -group                    [string]    db2iadm1
#
#   -hadr_service_1           [string]    DB2_HADR_1
#   -hadr_port_1              [int]       55001
#   -hadr_service_2           [string]    DB2_HADR_2
#   -hadr_port_2              [int]       55002
#
#   -standby_db2_host         [string]    example.com
#   -standby_instance         [string]    db2inst1
#   -standby_group            [string]    db2iadm1
#
#   -standby_hadr_service_1   [string]    DB2_HADR_1
#   -standby_hadr_port_1      [int]       55001
#   -standby_hadr_service_2   [string]    DB2_HADR_2
#   -standby_hadr_port_2      [int]       55002
#
#   -standby_root_username    [string]    root
#   -standby_root_password    [string]    password
#   -standby_root_keyfile     [string]    key.rsa
#
#******************************************************************************

if [ -z "$DB2_SCRIPTS_PATH" ]; then
  echo "Error: DB2_SCRIPTS_PATH not defined in setup_hadr.sh"
  export DB2_SCRIPTS_PATH=`echo $(cd $(dirname $0)/../; pwd)`
  echo 
fi

parse_args="$DB2_SCRIPTS_PATH/hadr/parse_arguments.sh"

hadr_database=`         $parse_args hadr_database         SAMPLE      $@`
primary_db2_instance=`  $parse_args primary_db2_instance  db2inst1    $@`
hadr_db2_group=`        $parse_args hadr_db2_group        db2iadm1    $@`
standby_root_username=` $parse_args standby_root_username root        $@`
standby_db2_host=`      $parse_args standby_db2_host      localhost   $@`
standby_public_ip=`     $parse_args standby_public_ip     localhost   $@`
standby_node_name=`     $parse_args standby_node_name       OS_Node_1   $@`
virtual_ip=`            $parse_args virtual_ip            notdefined   $@`
parameters=$@

echo "Doing primary database configuration"
"$DB2_SCRIPTS_PATH/hadr/config_primary_db.sh" $parameters
echo "=========================================="

#The below code for secondary_ip is not used anywhere and does not work for IPv6 IP.Commenting out..@kishore.nalam@in.ibm.com
#echo "Getting secondary ip"
#set -x
#secondary_ip=`nslookup $standby_db2_host | tail -2 | head -1 | awk '{print $2}'`
#set -
#echo

OS=`uname`
if [ "${OS}" = "AIX" ] ; then
    . ${HOME}/.profile
else
	. ${HOME}/.bash_profile
fi

ssh_param="$standby_root_username@$standby_public_ip"
scp_parm="$standby_root_username@$standby_db2_host"

echo "Verify that the remote host can be pinged"
set -x
ping -c 1 $standby_db2_host 2>&1
echo "=========================================="

# Copy|sync the db2 virtual ip details to standby host for standby db configuration
if [[ -e "/etc/db2vip.conf" ]];then
	scp /etc/db2vip.conf $scp_parm:/etc/db2vip.conf
fi
set -
echo "Doing standby database configuration"
validatecount=0
rc=1
set -x
while([[ $validatecount -lt 2  ]] && [[ $rc -ne 0 ]])
do
	REMOTE_DB2_SCRIPTS_PATH="/opt/IBM/maestro/agent/usr/servers/${standby_node_name}/scripts/DB2/shell"
	ssh $ssh_param "$REMOTE_DB2_SCRIPTS_PATH/hadr/config_standby_db.sh" $parameters
	echo "=========================================="

	#echo "Activating HADR to confirm success"
	"$DB2_SCRIPTS_PATH/hadr/activate_hadr.sh" $parameters
	#echo "=========================================="
	
	#echo "Doing validation of HADR to confirm success"
	let validatecount=$validatecount+1
	#"$DB2_SCRIPTS_PATH/hadr/validate_hadr.sh" $parameters
	int=0
	rc=0

	while(( $int<=3 ))
	do
		status=`su - $primary_db2_instance -c "db2pd -hadr -db $hadr_database" | head -9 | tail -1 | awk -F= '{print $2}'`
		if [[ "${status}" != " PEER" ]]; then
			echo "status is: ${status}"
			echo "Validate HADR status failed, nodes are not in Peer status!"
			let int=$int+1
			rc=1
			sleep 30
		else
			echo "validate HADR status successfully"
			rc=0
			break
		fi
	done
done
set -
#echo "=========================================="

exit $rc

