#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#******************************************************************************
#
# Command-line arguments:
#   -config                   [string]    /db2scripts/config/cloudburst.sh
#   -database                 [string]    SAMPLE
#   -instance                 [string]    db2inst1
#   -group                    [string]    db2iadm1
#
#   -standby_db2_host         [string]    example.com
#   -standby_instance         [string]    db2inst1
#   -standby_group            [string]    db2iadm1
#
#   -standby_root_username    [string]    root
#   -standby_root_password    [string]    password
#   -standby_root_keyfile     [string]    key.rsa
#
#
#******************************************************************************

if [ -z "$DB2_SCRIPTS_PATH" ]; then
  echo "Error: DB2_SCRIPTS_PATH not defined in config_primary_db.sh"
  export DB2_SCRIPTS_PATH=`echo $(cd $(dirname $0)/../; pwd)`
  echo
fi


parse_args="$DB2_SCRIPTS_PATH/hadr/parse_arguments.sh"

hadr_database=`           $parse_args hadr_database             SAMPLE      $@`
primary_db2_instance=`    $parse_args primary_db2_instance      db2inst1    $@`
standby_db2_instance=`    $parse_args standby_db2_instance      db2inst1    $@`
standby_root_username=`   $parse_args standby_root_username     root        $@`
standby_db2_host=`        $parse_args standby_db2_host          localhost   $@`
standby_public_ip=`       $parse_args standby_public_ip         localhost   $@`

echo "=========================================="

echo "Done running commands on secondary machine"
echo

echo "Getting secondary ip"
set -x
standy_ip=`nslookup $standby_db2_host | tail -2 | head -1 | awk '{print $2}'`
set -
echo

ssh_param="$standby_root_username@$standby_public_ip"

echo "Verify that the remote host can be pinged"
set -x
ping $standy_ip -c 1 2>&1
set -
echo "=========================================="

echo "Doing start HADR on standby"
set -x

cmd_start_standy="db2 start hadr on database $hadr_database as standby"
ssh $ssh_param "su - $standby_db2_instance -c \"$cmd_start_standy\""
rc=$?
if [ $rc -eq 4 ]; then
  echo "got rc=$rc, wait 10 seconds and try again"
  sleep 20
  ssh $ssh_param "su - $standby_db2_instance -c \"$cmd_start_standy\""
  rc=$?
  echo $rc
fi
set -
echo "=========================================="

echo "Done running commands on secondary machine"
echo

echo "=========================================="

echo "Done running commands on primary machine"
echo

echo "Getting secondary ip"
local_host=`hostname`
set -x
primary_ip=`nslookup $local_host | tail -2 | head -1 | awk '{print $2}'`
set -
echo

echo "Doing start HADR on primary"
set -x

cmd_active_primary="db2 start hadr on database $hadr_database as primary"
su - $primary_db2_instance -c "$cmd_active_primary"
rc=$?
if [[ $rc -ne 0 ]]; then
  echo "got rc=$rc, wait 20 seconds and try again"
  sleep 20
  su - $primary_db2_instance -c "$cmd_active_primary"
  rc=$?
  echo $rc
fi

set -
echo "=========================================="

echo "Done running commands on primary machine"
echo