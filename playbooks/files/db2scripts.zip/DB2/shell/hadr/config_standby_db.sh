#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#******************************************************************************
# Runs on: Primary
#
# Command-line arguments:
#   -config                   [string]    /db2scripts/config/cloudburst.sh
#   -database                 [string]    SAMPLE
#   -instance                 [string]    db2inst1
#   -group                    [string]    db2iadm1
#
#   -standby_db2_host         [string]    example.com
#   -standby_instance         [string]    db2inst1
#   -standby_group            [string]    db2iadm1
#
#   -standby_root_username    [string]    root
#   -standby_root_password    [string]    password
#   -standby_root_keyfile     [string]    key.rsa
#
# Configuration file parameters:
#
#******************************************************************************

if [ -z "$DB2_SCRIPTS_PATH" ]; then
  echo "Warning: DB2_SCRIPTS_PATH not defined in config_standby_db.sh"
  export DB2_SCRIPTS_PATH=`echo $(cd $(dirname $0)/../; pwd)`
  echo "DB2_SCRIPTS_PATH=$DB2_SCRIPTS_PATH"
  echo
fi

parse_args="$DB2_SCRIPTS_PATH/hadr/parse_arguments.sh"

hadr_database=`           $parse_args hadr_database             SAMPLE      $@`
primary_db2_instance=`    $parse_args primary_db2_instance      db2inst1    $@`
standby_db2_instance=`    $parse_args standby_db2_instance      db2inst1    $@`
hadr_db2_group=`          $parse_args hadr_db2_group            db2iadm1    $@`
standby_root_username=`   $parse_args standby_root_username     root        $@`
standby_db2_host=`        $parse_args standby_db2_host          localhost   $@`
standby_db2_service_port=`$parse_args standby_db2_service_port  50000       $@`
hadr_type=`             $parse_args hadr_type             PRIMARY     $@`
hadr_name_1=`           $parse_args hadr_name_1           DB2_HADR_1  $@`
hadr_port_1=`           $parse_args hadr_port_1           55001       $@`
hadr_name_2=`           $parse_args hadr_name_2           DB2_HADR_2  $@`
hadr_port_2=`           $parse_args hadr_port_2           55002       $@`
hadr_sync_mode=`        $parse_args hadr_sync_mode        SYNC    $@`
hadr_timeout=`          $parse_args hadr_timeout          150         $@`
hadr_peer_window=`      $parse_args hadr_peer_window      120         $@`
primary_db2_host=`        $parse_args primary_db2_host_full          localhost   $@`
primary_db2_service_port=`$parse_args primary_db2_service_port  50000   $@`
standby_hadr_port_1=`   $parse_args standby_hadr_port_1   55001       $@`
standby_hadr_port_2=`   $parse_args standby_hadr_port_2   55002       $@`
virtual_ip=`            $parse_args virtual_ip            notdefined   $@`

set -x
local_host=`uname -n`
primary_db2_host_short=`echo $primary_db2_host | awk -F. '{ print $1 }'`
standby_db2_host_short=`echo $standby_db2_host | awk -F. '{ print $1 }'`

if [[ -e "/etc/db2vip.conf" ]];then
	if [[ $virtual_ip != "notdefined" ]];then
		db2vip_update="db2 update alternate server for db $hadr_database using hostname $virtual_ip port $primary_db2_service_port"
	fi
fi
set -

echo "Running commands on standby machine"
su - $standby_db2_instance -c sh <<EOF
  echo "Configuring DB2 on standby"
  set -x
  db2 update alternate server for database $hadr_database using hostname $primary_db2_host port $primary_db2_service_port
  db2 update db cfg for $hadr_database using HADR_LOCAL_HOST $standby_db2_host_short
  db2 update db cfg for $hadr_database using HADR_REMOTE_HOST $primary_db2_host_short
  db2 update db cfg for $hadr_database using HADR_LOCAL_SVC $standby_hadr_port_1
  db2 update db cfg for $hadr_database using HADR_REMOTE_SVC $standby_hadr_port_2
  db2 update db cfg for $hadr_database using HADR_REMOTE_INST $primary_db2_instance
  db2 update db cfg for $hadr_database using HADR_SYNCMODE $hadr_sync_mode
  db2 update db cfg for $hadr_database using HADR_TIMEOUT $hadr_timeout
  db2 update db cfg for $hadr_database using HADR_PEER_WINDOW $hadr_peer_window
  db2 update db cfg for $hadr_database using LOGINDEXBUILD on
 set -
if [[ -n "$db2vip_update" ]];then
	set -x
	echo $db2vip_update
	$db2vip_update
 fi

  set -
  echo
  
  echo "deactivate and activate $hadr_database on secondary"
  set -x
  db2 deactivate db $hadr_database
  db2 activate db $hadr_database
  rc=$?
if [[ $rc -ne 0 ]]; then
    echo "got rc=$rc, wait 20 seconds and try again"
    sleep 20
    db2 activate db $hadr_database
    rc=$?
    echo $rc
  fi
  set -
  echo  
EOF

#  echo "Enabling Read on Standby"
#  set -x
#  db2set DB2_HADR_ROS=YES
#  db2set DB2_STANDBY_ISO=UR
#  set -

# db2set DB2_HADR_ROS=OFF && db2set DB2_STANDBY_ISO=NULL
