#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

. "$(dirname "$0")"/common.sh
logger_begin
logger_info "Params: $*" |pipe_mask "$4"

# Executed by root

inst_name=${1:?}
db_name=${2:?}
adminusername=${3:?}
adminpassword=${4:?}
db2domain=${5:?}
#node_name=${6:?}
as_node_name=${6:?}
hadr_role=${7:?}

#configure_tsm_node_for_hadr "${node_name}" "${as_node_name}" || exit $?
configure_tsm_node_for_hadr "${as_node_name}" || exit $?

#config_instance_for_tsm "${inst_name}" || exit $?
if [[ "${hadr_role}" == "PRIMARY" ]]; then
	register_tsm_node_for_hadr "${adminusername}" "${adminpassword}" "${db2domain}" || exit $?
	config_hadr_database_for_tsm "${inst_name}" "${db_name}" "${adminpassword}" || exit $?
	config_hadr_database_as_tsm_archive "${inst_name}" "${db_name}" || exit $?
fi

logger_end
exit 0
