var1=`/usr/local/bin/db2ls | tail -1`
echo "${var1}" | awk '{print $2}'
echo "${var1}" | awk '{print $1}'
