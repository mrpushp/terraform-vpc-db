#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

inst_name=$1
db_name=$2
tsm_node_name=$3
as_node_name=$4
adminusername=$5
adminpassword=$6

OS=`uname`
if [ "${OS}" = "AIX" ] ; then
. /home/${inst_name}/.profile
fi

dsmadmc -id=${adminusername:?} -password="${adminpassword:?}" <<EOF
grant proxynode target=${as_node_name} agent=${tsm_node_name}
EOF

db2 update db cfg for ${db_name} USING TSM_NODENAME ${tsm_node_name}
db2 update db cfg for ${db_name} USING TSM_OWNER ${tsm_node_name}

exit 0