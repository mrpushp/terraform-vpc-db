#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#


inst_name=$1
db_name=$2
timestamp_str=$3
dbpath=$4

OS=`uname`
if [ "${OS}" = "AIX" ] ; then
. /home/${inst_name}/.profile
fi
outStr=$(db2 RESTORE DB ${db_name} USE TSM TAKEN AT ${timestamp_str} DBPATH on ${dbpath} REPLACE HISTORY FILE WITHOUT PROMPTING)

RC=$?
if [[ ${RC} -ne 0 ]] && [[ ${RC} -ne 2 ]]; then
   echo "restore error message is ${outStr}"
   exit ${RC}
fi
