#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

. "$(dirname "$0")"/common.sh
logger_begin
logger_info "Params: $*"

# Executed by root

usage ()
{
    echo "Usage:"
    echo "$0"
    echo "    inst_name=INST_NAME db_name=DB_NAME"
    echo "    databaseUser=APPDBA"
    return 0
}

eval export "$@"
check_status $? "Failed while setting provision variables"

set_privileges ()
{
    logger_info "Setting database privileges..."
    local sqlfile=$(dirname $0)/privilege.sql
    local temp_sqlfile=${sqlfile}.$$
    local sqlfile_log=${temp_sqlfile}.log

    sed "s/<ROLE_APPDBA>/DBA/g;s/<USER_APPDBA>/${databaseUser}/g" ${sqlfile} > ${temp_sqlfile}

    load_sqlfile_for_db2 "${inst_name}" "${db_name}" "${inst_name}" "" "${temp_sqlfile}" "${sqlfile_log}"
    rm -f ${temp_sqlfile}
    
    return $?
}

set_privileges || exit $?

set_optim_support ()
{
    logger_info "Setting database to support optim tools..."
    local list=$(get_tablespace_list "${inst_name}" "${db_name}")
    logger_info "Get database ${db_name}'s tablespace list: [${list}]"
    local ts rc=0
    for ts in systoolspace systoolstmpspace
    do
        if ! echo "${list}" |grep -iq "^${ts}$" ; then
            local sqlfile=$(dirname $0)/create_${ts}.sql
            local sqlfile_log=${sqlfile}.log.$$
            load_sqlfile_for_db2 "${inst_name}" "${db_name}" "${inst_name}" "" "${sqlfile}" "${sqlfile_log}"
            rc=$(( $? + rc ))
        else
            logger_info "Tablespace ${ts} is existing, skipped."
        fi
    done
	logger_info "set_optim_support returns ${rc}"
}

set_optim_support

if [[ ${tsm_enabled} == "true" ]]; then
	config_database "${inst_name}" "${db_name}" \
	    trackmod=${trackmod} \
	    num_db_backups=${num_db_backups} \
	    rec_his_retentn=${rec_his_retentn} \
	    auto_del_rec_obj=${auto_del_rec_obj} \
	    || exit $?
fi

logger_end
exit 0
