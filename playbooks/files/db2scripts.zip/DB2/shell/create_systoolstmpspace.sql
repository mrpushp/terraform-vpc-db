--=========================================================================
--*
--* Licensed Materials - Property of IBM
--* 5725F36, 5725F48
--* Copyright IBM Corporation 2009, 2020.
--* US Government Users Restricted Rights - Use, duplication or disclosure
--* restricted by GSA ADP Schedule Contract with IBM Corp.
--*
--=========================================================================
CREATE USER TEMPORARY TABLESPACE SYSTOOLSTMPSPACE IN IBMCATGROUP
  MANAGED BY AUTOMATIC STORAGE
  EXTENTSIZE 4
;
