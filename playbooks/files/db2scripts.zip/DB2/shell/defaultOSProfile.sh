addOSProfile ()
{
   local instance_name=$1
   local user_name=$2
   local default_user_model=${3:-'False'}

   if chk_if_linux; then
      user_profile="/home/${user_name}/.bash_profile"
   else
      user_profile="/home/${user_name}/.profile"
   fi

   cmd=". /home/${instance_name}/sqllib/db2profile"
   if ! grep -q "${cmd}" ${user_profile} ; then
        echo "${cmd}" >> ${user_profile}
        rc=$?
        if [[ ${rc} -ne 0 ]] ; then
            logger_error "Failed while updating file ${user_profile}"
            return ${rc}
        fi
    fi

    chown ${user_name}:`id -g ${user_name}` ${user_profile}

    if [[ ${default_user_model_user} == "True" ]] ; then
        chmod 755 /home/${user_name}
    fi
    return 0
}

#3Main
instance_name=$1
user_name=$2
default_user_model=$3
return addOSProfile(instance_name, user_name, default_user_model)
