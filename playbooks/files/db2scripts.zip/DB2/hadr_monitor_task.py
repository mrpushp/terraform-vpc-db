#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import maestro
import os
import sys
import logging
import json
import traceback
import copy
logger = logging.getLogger('DB2/hadr_monitor_task.py')
scriptPath = maestro.node['scriptdir']
basePath = os.path.join(scriptPath, 'DB2')
libPath = os.path.join(scriptPath, 'DB2', 'lib')
shellPath = os.path.join(scriptPath, 'DB2', 'shell')
if not libPath in sys.path:
    sys.path.append(libPath)
if not basePath in sys.path:
    sys.path.append(basePath)

#Retrieve HADR status for one database
def retrieveHADRState(db_name):
    shellScript = os.path.join(shellPath, 'hadr_monitor.sh')
    args = [shellScript]
    args.append(db_name)
    args.append(maestro.parms['instanceOwner'])
    rc, status = maestro.trace_stderr_call(logger, args)
    logger.debug(status)
    if rc == 0 and status is not None:
        return json.loads(status)
    return None

def start():
    logger.debug('HADR monitor begin now!')
    need_export = False
    if 'DATABASES' in maestro.export:
        databases = copy.deepcopy(maestro.export['DATABASES'])
        for db_name in databases['databases']:
            if 'HADR' in databases['databases'][db_name] and databases['databases'][db_name]['HADR'] == 'true':
                currentState = retrieveHADRState(db_name)
                if currentState is None:
                    #TODO check the HADR TSA resource and fix issues by resetrsrc if any.
                    continue
                else:
                    previousState = databases['databases'][db_name]['HADR_ROLE']
                    if currentState['role'].upper() not in ['STANDBY', 'PRIMARY']:
                        #TOD check HADR TSA and fix issues by restart TSA resource or reset it.
                        pass
                    elif currentState['role'].upper() != previousState.upper():
                        databases['databases'][db_name]['HADR_ROLE'] = currentState['role'].upper()
                        databases['databases'][db_name]['Action'] = 'Takeover'
                        need_export = True
    if need_export:
        maestro.export['DATABASES'] = databases
    script = 'hadr_monitor_task.py'
    interval = 60
    task = {}
    task['script'] = script
    task['interval'] = interval
    maestro.tasks.append(task)
    logger.debug('HADR monitor done now!')

try:
    start()
except:
    traceback.print_exc()