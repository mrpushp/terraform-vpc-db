/opt/IBM/db2/V115/instance/db2idrop db2inst1
userdel db2inst1
userdel db2fenc1
userdel dasusr1
groupdel dasadm1
groupdel db2fsdm1
groupdel db2iadm1
rm -rf /home/db2inst1
rm -rf /home/db2fenc1
rm -rf /home/dasusr1
cd /opt/IBM/db2/V115/install
./db2_deinstall -a
rm -rf /opt/IBM/db2
rm -rf /opt/rsct
