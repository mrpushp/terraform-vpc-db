# DB2_CPS

## Exploratory work for DB2 instal via teraform

* clone repo to /tmp/db2scripts

* change directory to /tmp/db2scripts

* installer should be availale here /tmp/db2server/IPAS_DBaaS_1.2.12.0_linuxx64_server_11.5.0.0.tgz

* execute installable as following command

  `python2.7 db2_install.py "/opt/IBM/db2/V11.1" "db2inst1" "passw0rd" "50000" "db2fenc1"`
