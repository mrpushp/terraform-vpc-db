#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#******************************************************************************
# Runs on: Primary
#
# Command-line arguments:
#   -hadr_database                 [string]    SAMPLE
#   -hadr_db2_instance                 [string]    db2inst1
#   -hadr_db2_group                    [string]    db2iadm1
#
#   -hadr_service_1           [string]    DB2_HADR_1
#   -hadr_port_1              [int]       55001
#   -hadr_service_2           [string]    DB2_HADR_2
#   -hadr_port_2              [int]       55002
#
#   -standby_db2_host         [string]    example.com
#   -standby_instance         [string]    db2inst1
#   -standby_group            [string]    db2iadm1
#
#   -standby_hadr_service_1   [string]    DB2_HADR_1
#   -standby_hadr_port_1      [int]       55001
#   -standby_hadr_service_2   [string]    DB2_HADR_2
#   -standby_hadr_port_2      [int]       55002
#
#   -standby_root_username    [string]    root
#   -standby_root_password    [string]    password
#   -standby_root_keyfile     [string]    key.rsa
#
#******************************************************************************

export DB2_SCRIPTS_PATH=`echo $(cd $(dirname $0); pwd)`
export DB2_SCRIPTS_LOG_PATH="$DB2_SCRIPTS_PATH/log"

echo "do_hadr_setup.sh $@"

parse_args="$DB2_SCRIPTS_PATH/hadr/parse_arguments.sh"

hadr_type=`             $parse_args hadr_type             STANDBY     $@`
hadr_name_1=`           $parse_args hadr_name_1           DB2_HADR_1  $@`
hadr_port_1=`           $parse_args hadr_port_1           55001       $@`
hadr_name_2=`           $parse_args hadr_name_2           DB2_HADR_2  $@`
hadr_port_2=`           $parse_args hadr_port_2           55002       $@`
hadr_sync_mode=`        $parse_args hadr_sync_mode        SYNC    $@`
hadr_timeout=`          $parse_args hadr_timeout          150         $@`
hadr_peer_window=`      $parse_args hadr_peer_window      120         $@`
standby_db2_host=`      $parse_args standby_db2_host      localhost   $@`
standby_hadr_port_1=`   $parse_args standby_hadr_port_1   55001       $@`
standby_hadr_port_2=`   $parse_args standby_hadr_port_2   55002       $@`
standby_root_username=` $parse_args standby_root_username root        $@`
hadr_database=`         $parse_args hadr_database         SAMPLE      $@`
hadr_db2_group=`        $parse_args hadr_db2_group        db2iadm1    $@`
virtual_ip=`            $parse_args virtual_ip            notdefined  $@`

if [ "$hadr_type" != "PRIMARY" ]; then
  echo "This is not the PRIMARY machine. Exiting."
  exit 0
else
  echo "This is the PRIMARY machine. Proceeding."
fi

# Configure HADR
echo "Executing setup_hadr.sh"
"$DB2_SCRIPTS_PATH/hadr/setup_hadr.sh" $@
rc=$?
if [[ ${rc} -ne 0 ]]; then
	echo "Fail to setup hadr. Exiting..."
	exit 1
fi
echo
exit 0
