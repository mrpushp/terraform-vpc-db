#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
db2_db_name=$1
db2_inst_name=$2
hadr_role=`su - $db2_inst_name -c "db2pd -db $db2_db_name -hadr" | grep "HADR_ROLE" | awk -F= '{print $2}'`
hadr_state=`su - $db2_inst_name -c "db2pd -db $db2_db_name -hadr" | grep "HADR_STATE" | awk -F= '{print $2}'`
hadr_role=`echo ${hadr_role} | sed 's/^ //;s/ $//'`
hadr_state=`echo ${hadr_state} | sed 's/^ //;s/ $//'`
echo "{\"role\":\"$hadr_role\", \"hadr_status\":\"$hadr_state\"}"