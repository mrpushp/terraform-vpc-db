#!/usr/bin/expect -f
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

# For example:
#  ./exp_checkpasswd user1 passw0rd
# ----------------------------------------------------------------------

# set Variables
# set Variables
set user_name [lrange $argv 0 0]
set oldpassword [lrange $argv 1 1]
set newpassword ${oldpassword}

set timeout -1
spawn su ${user_name} -c passwd
match_max 100000
expect {
   -re "(.*) does not exist" {
    	send_user "The user does not exist"
		exit 2
   }
   -re " Old password:| UNIX password: " {
    	send -- "${oldpassword}\r"
    	exp_continue
   }
   -re "passwd: Authentication token manipulation error|password mismatch.|does not match the old password." {
    	send_user "password is wrong"
    	exit 1
   }
   -re ".*New (.*)password:" {
    	exit 0
   }
   default {
		send_user "error because of unknown issue \r"
    	exit 1
   }
}
expect eof

set ret [exp_wait]
set pid         [lindex $ret 0]
set spawn_id    [lindex $ret 1]
set os_error    [lindex $ret 2]
set exit_status [lindex $ret 3]
exit $exit_status
