#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
. "$(dirname "$0")"/common.sh
logger_begin

inst_name=$1
db_name=$2
old_db_name=$3
node_name=$4
timestamp_str=$5
node_password=$6
backup_mode=$7
vendoropt=$8
datapath=${9}

db2 -v create db ${db_name}
db2 -v  update db cfg for ${db_name} using TSM_NODENAME  ${node_name}
db2 -v update db cfg for ${db_name} using TSM_OWNER  ${node_name}
db2 -v update db cfg for ${db_name} using LOGARCHMETH1 TSM
db2 update db cfg for ${db_name} using tsm_password ${node_password}
db2 -v update db cfg for ${db_name} using vendoropt ${vendoropt}
#db2stop force; db2start

# create redirect SQL script
redirect_script=/tmp/redirect_${inst_name}_${old_db_name}_${db_name}.sql

if [[ ${backup_mode} = "ONLINE" ]]; then
 LogArchivePath=${datapath}/archlog
   rm -rf ${LogArchivePath}
   mkdir -p ${LogArchivePath}
   outStr=$(export LANG=C;db2 -v RESTORE DB ${old_db_name} USE TSM TAKEN AT ${timestamp_str} on ${datapath} INTO ${db_name} LOGTARGET ${LogArchivePath} redirect generate script ${redirect_script} WITHOUT PROMPTING)
else
   outStr=$(export LANG=C;db2 -v RESTORE DB ${old_db_name} USE TSM TAKEN AT ${timestamp_str} on ${datapath} INTO ${db_name}  redirect generate script ${redirect_script} WITHOUT PROMPTING)
fi

RC=$?
if [[ ${RC} -ne 0 ]] && [[ ${RC} -ne 2 ]]; then
   echo "restore error message is ${outStr}"
   exit ${RC}
fi

redirect_script_new=/tmp/redirect_${inst_name}_${old_db_name}_${db_name}_new.sql
awk -v inst_name=${inst_name} -v db_name=${db_name} -f $(dirname "$0")/redirect.awk ${redirect_script} > ${redirect_script_new}
cat ${redirect_script_new}

# perform restore and redirect
db2 -tvf "${redirect_script_new}"
RC=$?
if [[ ${RC} -ne 0 ]] && [[ ${RC} -ne 2 ]]; then
   echo "failed to restore db with redirect"
   exit ${RC}
fi

if [[ ${backup_mode} = "ONLINE" ]]; then
      outStr=$(db2 -v "ROLLFORWARD DB ${db_name} TO END OF BACKUP AND COMPLETE OVERFLOW LOG PATH (${LogArchivePath})")
else
   outStr=$(db2 -v "ROLLFORWARD DB ${db_name} COMPLETE")
fi

RC=$?
if [[ ${RC} -ne 0 ]] && [[ ${RC} -ne 2 ]]; then
   echo "ROLLFORWARD error message is ${outStr}"
   exit ${RC}
fi

db2 -v update db cfg for ${db_name} using vendoropt NULL

remote_host=$(export LANG=C;db2 -v get db cfg for ${db_name}|grep HADR_REMOTE_HOST|awk -F"= " '{print $NF}')

if [[ ! -z ${remote_host} ]]; then
    echo "cleanup the hadr setting for ${db_name}"
    db2 -v update db cfg for ${db_name} using HADR_LOCAL_HOST NULL
    db2 -v update db cfg for ${db_name} using HADR_REMOTE_HOST NULL
    db2 -v update db cfg for ${db_name} using HADR_LOCAL_SVC NULL
    db2 -v update db cfg for ${db_name} using HADR_REMOTE_SVC NULL
    db2 -v update db cfg for ${db_name} using HADR_REMOTE_INST NULL
    db2 -v update db cfg for ${db_name} using HADR_SYNCMODE NEARSYNC
    db2 -v update db cfg for ${db_name} using HADR_TIMEOUT  120
    db2 -v update db cfg for ${db_name} using HADR_PEER_WINDOW 0
    db2 -v update db cfg for ${db_name} using LOGINDEXBUILD OFF
fi