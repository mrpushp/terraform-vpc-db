#!/bin/sh
#exec > /tmp/setupPasswordlessSSH.tmp 2>&1
#set -x

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

# Usage:
# id_rsa.pub and id_rsa are in /root/.ssh/
#

USER=$1
GROUP=$2
HomeDir=$3
keyFileName=$4

if [[ ! -d $HomeDir ]]; then
   mkdir -p $HomeDir
fi

OSNAME=$(uname)
if [ "${OSNAME}" = "AIX" ] ; then
	if [ "$USER" = "root" ]; then
		GROUP="system"
	fi
fi
   
#***************Set permissions***************
chmod 700 $HomeDir
chmod 400 $keyFileName
chown $USER:$GROUP $HomeDir
chown $USER:$GROUP $keyFileName
#**********************************************

#***************Copy id_rsa.pub into authorized keys for reverse passwordless ssh*****
cat $keyFileName.pub >> $HomeDir/authorized_keys
chmod 600 $HomeDir/authorized_keys
chown $USER:$GROUP $HomeDir/authorized_keys
#*************************************************************************************

#***************Configure ssh*********************************************************
config_file=$HomeDir/config
config_content="StrictHostKeyChecking no"
config_content2="LogLevel error"
if [[ ! -f ${config_file} ]] ; then
    touch ${config_file}
    chmod 600 ${config_file}
    chown $USER:$GROUP ${config_file}
    echo "${config_content}" > ${config_file}
    echo "${config_content2}" >> ${config_file}
else
    if ! grep -q "${config_content}" ${config_file} ; then
        echo "${config_content}" >> $config_file
        echo "${config_content2}" >> ${config_file}
    fi
fi
#*************************************************************************************