#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

. "$(dirname "$0")"/common.sh
logger_begin
logger_info "Params: $*" | pipe_mask_after default_user_password= 

# Executed by root

usage ()
{
    echo "Usage:"
    echo "$0"
    echo "    inst_name=INST_NAME appdba=APPDBA 'appdba_password=\"APPDBA_PASSWORD\"' appuser=APPUSER 'appuser_password=\"APPUSER_PASSWORD\"'"
    return 0
}

eval export "$@"
check_status $? "Failed while setting provision variables"

logger_info "Creating users and groups for database user and administrator"
add_user "${databaseUser}" "${databaseUserPassword}" || exit $?

config_db2_client_for_user "${databaseUser}" "${inst_name}" || exit $?

set_ssh_denygroup ${NONSSH_GROUP} || exit $?
disable_ssh_for_user "${databaseUser}" || exit $?

logger_end
exit 0
