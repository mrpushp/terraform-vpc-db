#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

. "$(dirname "$0")"/common.sh
logger_begin
logger_info "Params: $*"

# Executed by root

usage ()
{
    echo "Usage:"
    echo "$0 -i INST_NAME -d DB_NAME -t [M|B|A] -g <F|N|I|O|D|E> -n IMAGE_NAME -s IMAGE_DESCRIPTION -o OUT_FILE [-z]"
    return 0
}

while getopts "i:v:d:t:g:n:s:p:r:o:z" opt
do
    case ${opt} in
        i)
            inst_name=${OPTARG};;
        v)
            vm_template_id=${OPTARG};;
        d)
            db_name=${OPTARG};;
        t)
            image_request=${OPTARG};;
        g)
            image_flag=${OPTARG};;
        n)
            image_name=${OPTARG};;
        s)
            image_desc=${OPTARG};;
        p)
            deployment_id=${OPTARG};;
        r)
            role_name=${OPTARG};;
        o)
            # succ: [timestamp]
            # fail: [sqlcode, sc], [ic, tokens]
            out_file=${OPTARG};;
        z)
            compress_option="COMPRESS";;
        \?)
            usage
            exit 1
            ;;
    esac
done
unset OPTIND

tmpdir=$(dirname "${out_file}")
mkdir -p "${tmpdir}"

chk_if_database_tsm_archived "${inst_name:?}" "${db_name:?}"
rc=$? 
if [[ ${rc} -ne 0 ]] ; then
   if [[ ${rc} -eq 4 ]] ; then
     #SQL1013N  The database alias name or database name "DB3" could not be found.
     logger_error "The database alias name or database name could not be found!"
     check_fail 1 "${out_file}" "" "" "1013N"
   else
     logger_error "DB2 database is not configured as TSM Archive. Backup is not supported in this way!"
     check_fail 1 "${out_file}" "" "" "1102W"
   fi 
fi

out_file2=${out_file}.2
backup_db \
    -i "${inst_name}" \
    -d "${db_name}" \
    -t "TSM" \
    -g "${image_flag}" \
    -o "${out_file2:?}" \
    ${compress_option}
rc=$?
if [[ ${rc} -ne 0 ]] ; then
    logger_error "Failed to call backup_db"
    check_fail ${rc} "${out_file}" "$(get_sqlcode "${out_file2}")" "$(get_reasoncode "${out_file2}")"
fi

timestamp=$(get_backup_timestamp_from_output "${out_file2}")
/bin/rm -f "${out_file2}"

if [[ -z ${timestamp} ]] ; then
    logger_error "Failed to get timestamp"
    check_fail 1 "${out_file}" "" "" "103"
fi

#do not store the baseline
if [[ ${image_request} != 'B' ]] ; then
	meta_file=$(generate_image_meta_file \
	    "${inst_name}" \
    	"${vm_template_id}" \
	    "${db_name}" \
	    "${image_request}" \
	    "${image_flag}" \
	    "${image_name}" \
	    "${image_desc}" \
	    "${timestamp}" \
	    "${deployment_id}" \
	    "${role_name}"
	)
	rc=$?
	if [[ ${rc} -ne 0 ]] ; then
	    logger_error "Failed to generate image meta file ${meta_file}"
	    check_fail ${rc} "${out_file}" "" "" "104"
	fi
	
	if [[ ! -s ${meta_file} ]] ; then
	    logger_error "Failed to generate image meta file"
	    check_fail ${rc} "${out_file}" "" "" "105"
	fi
	
	save_image_meta_file "${meta_file}"
	rc=$?
	if [[ ${rc} -ne 0 ]] ; then
	    logger_error "Failed to save image metadata for the DB2 database."
	    check_fail ${rc} "${out_file}" "" "" "106"
	fi
	
	grant_image_meta_file "${meta_file}"
	rc=$?
	if [[ ${rc} -ne 0 ]] ; then
	    logger_error "Failed to grant image metadata access rights to database users."
	    check_fail ${rc} "${out_file}" "" "" "1"
	fi
	
	logger_info "Delete ${meta_file}"
	/bin/rm -f "${meta_file}"
fi

if [[ ${image_request} == 'A' ]] ; then
    delete_database_image A "${deployment_id}" "${vm_template_id}" "${role_name}" "${inst_name}" "${db_name}" 7
    rc=$?
    if [[ ${rc} -ne 0 ]] ; then
        logger_error "Failed to delete database image"
        check_fail ${rc} "${out_file}" "" "" "107"
    fi
fi

check_succ 0 "${out_file}" "${timestamp}"

logger_end
exit 0

