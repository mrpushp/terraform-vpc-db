#!/usr/bin/env perl
#-----------------------------------------------------------------------------------------------------#
#*
#* Licensed Materials - Property of IBM
#* 5725F36, 5725F48
#* Copyright IBM Corporation 2009, 2020.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#-----------------------------------------------------------------------------------------------------#
# Haicu           Sets up DB2 HAICU using HADR
#-----------------------------------------------------------------------------------------------------#


use strict;
use 5.004;
use warnings;
use File::Basename;
use FindBin qw($Bin);
use Getopt::Std;
use Sys::Syslog;


my $PROGNAME         = basename($0);
my $PROGPATH         = $Bin;
my $PID              = $$;
my $TEMP             = "/tmp/haicu.$PID";
my $QUORUM_DEVICE_IP    = 'db2HAdomain';
my $RSCT_CLUSTER_NAME   = 'db2HAdomain';

#==============================================================================
# Constants
#==============================================================================
use constant EMPTY_BUFFER  => 'EMPTY_BUFFER';
use constant ROOT_USER     => 'root';

#==============================================================================
# Error code definitions
#==============================================================================
use constant RC_OK            =>    0;    # ok
use constant RC_FAIL          =>    1;    # failure

#==============================================================================
# Global variables
#==============================================================================
my %inputs     = ();

my $osname = $^O;
my $ssh_key_file = '';
# ssh file location
if( $osname eq 'aix' ) {
   $ssh_key_file = '/.ssh/id_rsa'; 
}
else {
   $ssh_key_file = '/root/.ssh/id_rsa'; 
}

#==============================================================================
# Subroutines Definitions
#==============================================================================
sub CheckIWDInputs();  		 # Check Inputs
sub RunBashCommands(@);          # Run commands in bash shell
sub ExitScript(@);               # Exit script cleanly
sub MakeHaicuXml(@);             # Generate the db2haicu configuration XML file
sub SetupHaicu(@);               # Run db2haicu to configure the cluster   
sub Main();

#==============================================================================
# Script
#==============================================================================

# Call Main to run script
Main();

sub CheckIWDInputs() {
   #==============================================================================
   # CheckIWDInputs(@) - Parse command-line inputs.
   #
   # Function call format:
   #   ( $dbname, $dbinst, $primaryIp, $primaryHostname, $secondaryIp, $secondaryHostname ) = &CheckIWDinputs();
   #==============================================================================
	
	syslog ( 'info', "CheckIWDInputs ..."   );
	
	# Parse the command line arguments
	# e will be the quorum device
	getopts("n:i:r:a:b:c:d:e:f:g:h:k:l:s:",\%inputs);	

	if ( $inputs{n} ) {
		chomp $inputs{n};
	}
        if ( $inputs{i} ) {
                chomp $inputs{i};
        }
        if ( $inputs{r} ) {
                chomp $inputs{r};
        }        
        if ( $inputs{a} ) {
                chomp $inputs{a};
        }
        if ( $inputs{b} ) {
                chomp $inputs{b};
        }
        if ( $inputs{c} ) {
                chomp $inputs{c};
        }
        if ( $inputs{d} ) {
                chomp $inputs{d};
        }
        if ( $inputs{e} ) {
                chomp $inputs{e};
        }
        if ( $inputs{f} ) {
                chomp $inputs{f};
        }
        if ( $inputs{g} ) {
                chomp $inputs{g};
        }
        if ( $inputs{h} ) {
                chomp $inputs{h};
        }
        if ( $inputs{k} ) {
                chomp $inputs{k};
        }
        if ( $inputs{l} ) {
                chomp $inputs{l};
        }
        if ( $inputs{s} ) {
        	chomp $inputs{s};
        }
	return ($inputs{n}, $inputs{i}, $inputs{r}, $inputs{a}, $inputs{b}, $inputs{c}, $inputs{d}, $inputs{e}, $inputs{f}, $inputs{g}, $inputs{h}, $inputs{k}, $inputs{l}, $inputs{s});
}

sub ExitScript(@) {
   #==============================================================================
   # ExitScript(@) - Closes the log and exits the script with the supplied RC
   #
   # Function call format:
   #   &ExitScript( $rc );
   #==============================================================================

   my $rc = shift;
   syslog ( 'info' , "******EXITING script. RC = $rc" );
   # Close the system log
   closelog;
   # Exit script with supplied RC
   exit $rc;
}

sub RunBashCommands(@) {
   #==============================================================================
   # RunBashCommands(@) - Run the supplied $command in the bash
   #                      shell of $user on $node_ref.
   #                      Save the output and return the command's RC.
   #
   # Function call format:
   #   $rc = &RunBashCommands( $node_ref, $user, $command, \$output_buffer, $ssh_key_file );
   #==============================================================================

   my $node_ref         = shift; # Node information
   my $user             = shift; # User to run command from
   my $command          = shift; # Bash statement to run
   my $out_buffer_ref   = shift; # Reference to output buffer
   my $ssh_key_file     = shift;

   my $node_addr  = $node_ref->{'public_ip'};
   my $output;
   my $rc;

   if ( $user ne ROOT_USER ) {
      syslog ( 'info', "Running bash command: ssh $node_addr su - $user -c \\\"$command\\\"" );
      # Switch to $user and run $command; grab all output including errors
      $output = `ssh $node_addr su - $user -c \\\"$command\\\" 2>&1`;
      # Get the RC
      $rc = $?;
   }
   else {
      syslog ( 'info', "Running bash command: ssh $node_addr \"$command\"" );
      # No need to `su`
      $output = `ssh $node_addr \"$command\" 2>&1`;
      # Get the RC
      $rc = $?;
   }

   # Save the output if there was any
   if ( ! ( $output eq '' ) ) {
      ${$out_buffer_ref} = $output;
   }
   # Else indicate EMPTY_BUFFER
   else {
      ${$out_buffer_ref} = EMPTY_BUFFER;
   }

   syslog ( 'info', "Command output: $output" );

   # Return the command's RC
   return $rc;
}

sub MakeHaicuXml(@) {
   #==============================================================================
   # MakeHaicuXml(@) - Generates the db2haicu XML configuration file for
   #                   promptless-setup.
   #                   Returns a string containing the file contents.
   #
   # Function call format:
   #   $xml_file = &MakeHaicuXml( $local_node_ref, $remote_node_ref, $db2_dbname, $db2_inst );
   #==============================================================================
   my $local_node_ref   = shift;
   my $remote_node_ref  = shift;
   my $db2_dbname       = shift;
   my $db2_inst         = shift;
   my $remote_db2_inst  = shift;
   my $pub_interface    = shift;
   my $pub_subnetMask   = shift;
   my $load_type		= shift;
   my $xml_file;

   # file $DB2_INFO{'storage_fs'}/$db2_inst/sqllib/samples/ha/xml/db2ha_sample_HADR.xml

	syslog('info', "$db2_dbname");	
        syslog('info', "$db2_inst");
        syslog('info', "$remote_db2_inst");
        syslog('info', "local is: $local_node_ref->{'public_hostname'}");
        syslog('info', "local IP is: $local_node_ref->{'public_ip'}");
        syslog('info', "remote is: $remote_node_ref->{'public_hostname'}");
        syslog('info', "remote IP is: $remote_node_ref->{'public_ip'}");
	syslog('info', "rsct cluster name: $RSCT_CLUSTER_NAME");
	syslog('info', "quorum device is: $QUORUM_DEVICE_IP");
        syslog('info', "public interface is: $pub_interface");
        syslog('info', "public subnetMask is: $pub_subnetMask");
	syslog('info', "$PROGNAME");
    if ( $load_type eq 'INIT' ) {
   $xml_file = <<"END";
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!--
****************************************************************************
** Licensed Materials - Property of IBM
**
** Governed under the terms of the International
** License Agreement for Non-Warranted Sample Code.
**
** (C) COPYRIGHT International Business Machines Corp. 2007
** All Rights Reserved.
**
** US Government Users Restricted Rights - Use, duplication or
** disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*****************************************************************************
**
** Generated by $PROGNAME
**
*****************************************************************************/
-->
<DB2Cluster xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"db2ha.xsd\" clusterManagerName=\"TSA\" version=\"1.0\">
   <ClusterDomain domainName=\"$RSCT_CLUSTER_NAME\">
      <Quorum quorumDeviceProtocol=\"network\" quorumDeviceName=\"$QUORUM_DEVICE_IP\"/>
      <PhysicalNetwork physicalNetworkName="db2_public_network_0" physicalNetworkProtocol="ip">
       	<Interface interfaceName=\"$pub_interface\" clusterNodeName=\"$local_node_ref->{'public_hostname'}\">
         	<IPAddress baseAddress=\"$local_node_ref->{'public_ip'}\" subnetMask=\"$pub_subnetMask\" networkName="db2_public_network_0"/>
       	</Interface>
       	<Interface interfaceName=\"$pub_interface\" clusterNodeName=\"$remote_node_ref->{'public_hostname'}\">
      		<IPAddress baseAddress=\"$remote_node_ref->{'public_ip'}\" subnetMask=\"$pub_subnetMask\" networkName="db2_public_network_0"/>
      	</Interface>
      </PhysicalNetwork>
      <ClusterNode clusterNodeName=\"$local_node_ref->{'public_hostname'}\"/>
      <ClusterNode clusterNodeName=\"$remote_node_ref->{'public_hostname'}\"/>
   </ClusterDomain>
   <FailoverPolicy>
      <HADRFailover></HADRFailover>
   </FailoverPolicy>
   <DB2PartitionSet>
      <DB2Partition dbpartitionnum=\"0\" instanceName=\"$db2_inst\">
      </DB2Partition>
   </DB2PartitionSet>
   <HADRDBSet>
      <HADRDB databaseName=\"$db2_dbname\" localInstance=\"$db2_inst\" remoteInstance=\"$remote_db2_inst\" localHost=\"$local_node_ref->{'public_hostname'}\" remoteHost=\"$remote_node_ref->{'public_hostname'}\" />
   </HADRDBSet>
</DB2Cluster>
END
}
else {
   $xml_file = <<"END";
<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!--
****************************************************************************
** Licensed Materials - Property of IBM
**
** Governed under the terms of the International
** License Agreement for Non-Warranted Sample Code.
**
** (C) COPYRIGHT International Business Machines Corp. 2007
** All Rights Reserved.
**
** US Government Users Restricted Rights - Use, duplication or
** disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*****************************************************************************
**
** Generated by $PROGNAME
**
*****************************************************************************/
-->
<DB2Cluster xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"db2ha.xsd\" clusterManagerName=\"TSA\" version=\"1.0\">
   <ClusterDomain domainName=\"$RSCT_CLUSTER_NAME\">
      <Quorum quorumDeviceProtocol=\"network\" quorumDeviceName=\"$QUORUM_DEVICE_IP\"/>
      <PhysicalNetwork physicalNetworkName="db2_public_network_0" physicalNetworkProtocol="ip">
       	<Interface interfaceName=\"$pub_interface\" clusterNodeName=\"$local_node_ref->{'public_hostname'}\">
         	<IPAddress baseAddress=\"$local_node_ref->{'public_ip'}\" subnetMask=\"$pub_subnetMask\" networkName="db2_public_network_0"/>
       	</Interface>
       	<Interface interfaceName=\"$pub_interface\" clusterNodeName=\"$remote_node_ref->{'public_hostname'}\">
      		<IPAddress baseAddress=\"$remote_node_ref->{'public_ip'}\" subnetMask=\"$pub_subnetMask\" networkName="db2_public_network_0"/>
      	</Interface>
      </PhysicalNetwork>
      <ClusterNode clusterNodeName=\"$local_node_ref->{'public_hostname'}\"/>
      <ClusterNode clusterNodeName=\"$remote_node_ref->{'public_hostname'}\"/>
   </ClusterDomain>
   <FailoverPolicy>
      <HADRFailover></HADRFailover>
   </FailoverPolicy>
   <HADRDBSet>
      <HADRDB databaseName=\"$db2_dbname\" localInstance=\"$db2_inst\" remoteInstance=\"$remote_db2_inst\" localHost=\"$local_node_ref->{'public_hostname'}\" remoteHost=\"$remote_node_ref->{'public_hostname'}\" />
   </HADRDBSet>
</DB2Cluster>
END
}

	#if (!($xml_file)) {
		#syslog('info', "xml file is: empty);
	#}

   return $xml_file;
}

sub SetupHaicu(@) {
   #==============================================================================
   # SetupHaicu(@) - Set up DB2 HAICU cluster for the database provided
   #                 between the two nodes.
   #
   # Function call format:
   #   $rc = &SetupHaicu( $db2_dbname, $db2_inst, $primary_node_ref, $standby_node_ref, $ssh_key_file );
   #==============================================================================
   my $db2_dbname       = shift;
   my $db2_inst         = shift;
   my $standby_db2_inst = shift;
   my $primary_node_ref = shift;
   my $standby_node_ref = shift;
   my $ssh_key_file     = shift;
   my $pub_interface    = shift;
   my $pub_subnetMask   = shift;
   my $load_type		= shift;
   my $crit_rsrc_prot_method = shift;

   my $cmd_buffer;
   my $out_buffer;
   my $rc;
   my $outmsg;
   
   if( $osname eq 'aix' ) {
      $outmsg = `. /root/.profile`; 
   }
   else {
      $outmsg = `. /root/.bash_profile`;
   };
   
   syslog('info', "The output is $outmsg");
   
   # Prepare nodes for TSA control
   $cmd_buffer = "preprpnode $primary_node_ref->{'public_hostname'} $standby_node_ref->{'public_hostname'}";

   syslog('info', "primary node ref's public hostname is: $primary_node_ref->{'public_hostname'}");

   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   $rc = &RunBashCommands( $standby_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );

   # Adds nodes to the TSA cluster domain definition
   syslog('info', "add primary node to cluster: $primary_node_ref->{'public_hostname'}");
   $cmd_buffer = "lsrpnode $primary_node_ref->{'public_hostname'}; if [[ $? -eq 6 ]]; then addrpnode $primary_node_ref->{'public_hostname'}; fi";
   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   
   syslog('info', "add standby node to cluster: $standby_node_ref->{'public_hostname'}");
   $cmd_buffer = "lsrpnode $standby_node_ref->{'public_hostname'}; if [[ $? -eq 6 ]]; then addrpnode $standby_node_ref->{'public_hostname'}; fi";
   $rc = &RunBashCommands( $standby_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   
   # DB2haicu configuration XML files setup (primary and standby)

   my $primary_haicu_xml = &MakeHaicuXml( $primary_node_ref, $standby_node_ref, $db2_dbname, $db2_inst, $standby_db2_inst, $pub_interface, $pub_subnetMask, $load_type);   # Generate the XML file contents
   my $primary_xml_file = '/tmp/primaryxmlfile';
   
   open ( PRIMARYXMLFILE, '>', $primary_xml_file);
   print PRIMARYXMLFILE $primary_haicu_xml;
   close ( PRIMARYXMLFILE );

   my $standby_haicu_xml = &MakeHaicuXml( $standby_node_ref, $primary_node_ref, $db2_dbname, $standby_db2_inst, $db2_inst, $pub_interface, $pub_subnetMask, $load_type);
   my $standby_xml_file = '/tmp/standbyxmlfile';

   open ( STANDBYXMLFILE, '>', $standby_xml_file);
   print STANDBYXMLFILE $standby_haicu_xml;
   close ( STANDBYXMLFILE );

   if($standby_node_ref->{'public_ip'} =~ /:/) {
      $cmd_buffer = "scp $standby_xml_file [$standby_node_ref->{'public_ip'}]:/tmp";    # Save file
   }
   else {
      $cmd_buffer = "scp $standby_xml_file $standby_node_ref->{'public_ip'}:/tmp";    # Save file
   };
   
   `$cmd_buffer`;
#   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   $cmd_buffer = "chmod 777 $primary_xml_file";
   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   $cmd_buffer = "chmod 777 $standby_xml_file";
   $rc = &RunBashCommands( $standby_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );

   # Run db2haicu
   $cmd_buffer = "db2haicu -f $standby_xml_file";
   $rc = &RunBashCommands( $standby_node_ref, $standby_db2_inst, $cmd_buffer, \$out_buffer, $ssh_key_file );
   $cmd_buffer = "db2haicu -f $primary_xml_file";
   $rc = &RunBashCommands( $primary_node_ref, $db2_inst, $cmd_buffer, \$out_buffer, $ssh_key_file );
   
   # Minimize failover time by configuring quorum
   my $quorum_cfg = <<'END';
#!/bin/sh
export CT_MANAGEMENT_SCOPE=2;
#chrsrc -c IBM.PeerNode OpQuorumTieBreaker="Operator"
#chrsrc -s "Name like '%'" IBM.TieBreaker PostReserveWaitTime=1
#Commenting above line will leave the default setting to PostReserveWaitTime=30
#tbname=$(lsrsrc -s "Name like 'db2_Quor%'" IBM.TieBreaker Name | grep Name | tail -1 | awk '{print $3}' | tr \" " " | awk '{print $1}')
#chrsrc -c IBM.PeerNode OpQuorumTieBreaker=$tbname
chcomg -s 4 -p 4 -g -1 CG1
#Default settings : 4,1,-1 till DB2 v10.5.0.6
#Enable log/trace to flush to disk
chrsrc -c IBM.PeerNode CritRsrcProtMethod=$crit_rsrc_prot_method
END

   #my $quorum_file = $TEMP . '/' . $PID . rand() . '.sh';
   my $quorum_file = '/opt/ibm/db2/quorum';
   open ( QUORUMCFGFILE, '>', $quorum_file);
   print QUORUMCFGFILE $quorum_cfg;
   close ( QUORUMCFGFILE );
   $cmd_buffer = "chmod 777 $quorum_file";
   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   
   # Run quorum configurator
   $cmd_buffer = "$quorum_file";
   $rc = &RunBashCommands( $primary_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );
   $rc = &RunBashCommands( $standby_node_ref, ROOT_USER, $cmd_buffer, \$out_buffer, $ssh_key_file );

   return RC_OK;
}

sub Main() {
   # Open the system log
   openlog ( $PROGNAME , 'pid' , 'LOG_DAEMON' );
   syslog ( 'info' , "******STARTING script. Inputs: @ARGV" );

   my %local_node = ();   # Node information hashes
   my %remote_node = ();
   my $dbname;
   my $inst; 
   my $sinst;
   my $rc = RC_OK;
   my $quorum_hostname = $QUORUM_DEVICE_IP;
   my $public_interface;
   my $public_subnetMask;
   my $load_type;
   my $crit_rsrc_prot_method;

   ($dbname, $inst, $sinst, $local_node{'public_ip'}, $local_node{'public_hostname'}, $remote_node{'public_ip'}, $remote_node{'public_hostname'}, $quorum_hostname, $public_interface, $public_subnetMask, $local_node{'private_ip'}, $remote_node{'private_ip'}, $load_type, $crit_rsrc_prot_method) = &CheckIWDInputs();
   
   # give the quorum device an ip
   $QUORUM_DEVICE_IP=$quorum_hostname;
   
   #remove everything in remote_node hostname after '.' 
   $remote_node{'public_hostname'}=~ s/\..*//;
   $rc = &SetupHaicu( $dbname, $inst, $sinst, \%local_node, \%remote_node, $ssh_key_file, $public_interface, $public_subnetMask, $load_type, $crit_rsrc_prot_method );

   &ExitScript ($rc);
}
