#!/bin/sh

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#
iSCSI_IP=$1
iSCSI_IQN=$2

echo "iSCSI target host IP address is $iSCSI_IP"
echo "iSCSI target IQN id is $iSCSI_IQN"

ISCSI_PREFIX=`date +"%Y"`-`date +"%m"`
ISCSI_NAME=DB2_HADR.TSA_TB

OS=`/bin/uname`

if [ "$OS" == "Linux" ]; then
    S_HOSTNAME=`hostname`    
    INITIATOR=iqn.${ISCSI_PREFIX}.${S_HOSTNAME}:${ISCSI_NAME}
    rm -f /etc/iscsi/initiatorname.iscsi
    echo "InitiatorName=${INITIATOR}" > /etc/iscsi/initiatorname.iscsi    
    iscsiadm -m discovery -t sendtargets -p $iSCSI_IP    
    iscsiadm -m node -T $iSCSI_IQN --login        
else
    S_HOSTNAME=`hostname -s`    
    INITIATOR=iqn.${ISCSI_PREFIX}.${S_HOSTNAME}:${ISCSI_NAME}
    chdev  -l 'iscsi0' -a initiator_name="${INITIATOR}"
    mkdev -l iscsi0
    echo "$iSCSI_IP 3260 $iSCSI_IQN" >> /etc/iscsi/targets
    cfgmgr -vl iscsi0    
    new_PV=`lspv | grep None | awk '{print $1}'`
    chdev -l $new_PV -a pv=yes
    lspv
fi

echo "!IBQPORTONLY !ALL\n" > /var/ct/cfg/netmon.cf