#!/bin/sh
#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#

main()
{

	local opt=$1
	local def_value=$2
	shift 2
	local pramaters=$@
	local value=`echo ${pramaters} | awk '{for (i=1;i<=NF;i+=2){print substr($i,2)"="$(i+1)""}}' | grep "^$opt" | awk -F"=" '{print $2}'`
	#echo "OPT is ==> $opt | VALUE is ==> $value |"
	if [ "$value" = "" ];then
		value=$def_value
	fi

		#parses defination
	#####################################
	local hadr_database
	local hadr_db2_instance
	local hadr_db2_group
	local hadr_type
	local hadr_name_1
	local hadr_port_1
	local hadr_name_2
	local hadr_port_2
	local hadr_sync_mode
	local hadr_timeout
	local hadr_peer_window

	local standby_db2_host
	local standby_hadr_port_1
	local standby_hadr_port_2
	local standby_root_username
	local standby_root_password
	local standby_db2_service_port
	local standby_private_ip
	local standby_public_ip
	local standby_node_name
	local standby_db2_instance

	local primary_db2_host_full
	local primary_db2_instance
	local primary_db2_service_port
	local primary_private_ip
	local primary_public_ip
	local load_type
	local virtual_ip
	local crit_rsrc_prot_method
	
	#######################################

	case "$opt" in
	    hadr_database)
	        hadr_database=$value
	        echo $hadr_database
	        ;;
	    hadr_db2_instance)
	        hadr_db2_instance=$value
	        echo $hadr_db2_instance
	        ;;
	    hadr_db2_group)
	        hadr_db2_group=$value
	        echo $hadr_db2_group
	        ;;
	    hadr_type)
	        hadr_type=$value
	        echo $hadr_type
	        ;;
	    hadr_name_1)
	        hadr_name_1=$value
	        echo $hadr_name_1
	        ;;
	    hadr_port_1)
	        hadr_port_1=$value
	        echo $hadr_port_1
	        ;;
	    hadr_name_2)
	        hadr_name_2=$value
	        echo $hadr_name_2
	        ;;
	    hadr_port_2)
	        hadr_port_2=$value
	        echo $hadr_port_2
	        ;;
	    hadr_sync_mode)
	        hadr_sync_mode=$value
	        echo $hadr_sync_mode
	        ;;
	    hadr_timeout)
	        hadr_timeout=$value
	        echo $hadr_timeout
	        ;;
	    hadr_peer_window)
	        hadr_peer_window=$value
	        echo $hadr_peer_window
	        ;;
	    standby_db2_host)
	        standby_db2_host=$value
	        echo $standby_db2_host
	        ;;
	    standby_hadr_port_1)
	        standby_hadr_port_1=$value
	        echo $standby_hadr_port_1
	        ;;
	    standby_hadr_port_2)
	        standby_hadr_port_2=$value
	        echo $standby_hadr_port_2
	        ;;
	    standby_root_username)
	        standby_root_username=$value
	        echo $standby_root_username
	        ;;
	    standby_root_password)
	        standby_root_password=$value
	        echo $standby_root_password
	        ;;
	    standby_db2_service_port)
	        standby_db2_service_port=$value
	        echo $standby_db2_service_port
	        ;;
	    standby_private_ip)
	        standby_private_ip=$value
	        echo $standby_private_ip
	        ;;
	    standby_public_ip)
	        standby_public_ip=$value
	        echo $standby_public_ip
	        ;;	        
	    standby_node_name)
	    	standby_node_name=$value
	    	echo $standby_node_name
	    	;;
	    standby_db2_instance)
	    	standby_db2_instance=$value
	    	echo $standby_db2_instance
	    	;;
	    primary_db2_host_full)
	        primary_db2_host_full=$value
	        echo $primary_db2_host_full
	        ;;
	    primary_db2_instance)
	        primary_db2_instance=$value
	        echo $primary_db2_instance
	        ;;
	    primary_db2_service_port)
	        primary_db2_service_port=$value
	        echo $primary_db2_service_port
	        ;;
	    primary_private_ip)
	        primary_private_ip=$value
	        echo $primary_private_ip
	        ;;
	    primary_public_ip)
	        primary_public_ip=$value
	        echo $primary_public_ip
	        ;;
	    load_type)
	        load_type=$value
	        echo $load_type
	        ;;
	    virtual_ip)
	        virtual_ip=$value
	        echo $virtual_ip
	        ;;
	    crit_rsrc_prot_method)
	    	crit_rsrc_prot_method=$value
	    	echo $crit_rsrc_prot_method
	    	;;
	    \?)
	        echo "Invalid parameters"
	        return 1
	        ;;
	esac

}
main $@
