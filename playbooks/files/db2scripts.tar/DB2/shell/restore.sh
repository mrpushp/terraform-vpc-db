#!/bin/sh

#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
dbName=${1:?}
remotelHostName=${2:?}
remoteInstOwner=${3:?}
instOwner=${4:?}
dbpath=${5:?}
OS=`uname`
if [ "${OS}" = "AIX" ] ; then
    . /home/${instOwner}/.profile
else
	. /home/${instOwner}/.bash_profile
fi
mkfifo /tmp/tmppipe
ssh ${remoteInstOwner}@${remotelHostName} 'cat /tmp/tmppipe' > /tmp/tmppipe &
db2 restore db ${dbName} from /tmp/tmppipe on ${dbpath} replace history file replace existing
rm /tmp/tmppipe 
