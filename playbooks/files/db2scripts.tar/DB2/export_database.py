#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
import maestro
import copy
import logging

logger = logging.getLogger('export_database.py')
logger.debug('Export Database begin!')
op_parms = maestro.operation['parms']
db_name = op_parms['database_name']

if 'DATABASES' in maestro.export:
    databases = copy.deepcopy(maestro.export['DATABASES'])
else:
    databases = {}
    databases['databases'] = {}
    databases['instance_ip'] = maestro.node['instance']['public-ip'] 
    databases['instance_name'] = maestro.parms['instanceOwner']
    databases['instance_password'] = maestro.parms['instanceOwnerPassword']
    databases['instance_port'] = maestro.parms['instancePort']

#Start HADR monitor if there is HADR db
need_start_monitor = False
if op_parms['HADR'] == 'true':
    need_start_monitor = True
    for db in databases['databases']:
        if databases['databases'][db]['HADR'] == 'true':
            need_start_monitor = False
            break

databases['databases'][db_name] = op_parms
databases['databases'][db_name]['Action'] = 'Create'
#export database list
maestro.export['DATABASES'] = databases

if need_start_monitor:
    script = 'hadr_monitor_task.py'
    interval = 60
    task = {}
    task['script'] = script
    task['interval'] = interval
    maestro.tasks.append(task)
    logger.debug('Start HADR monitor in export_database.py')
logger.debug('Export Database done!')