#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2009, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================
#

import inspect
import os

this_file = inspect.currentframe().f_code.co_filename
this_dir = os.path.dirname(this_file)
execfile(os.path.join(this_dir, 'install.py'))
