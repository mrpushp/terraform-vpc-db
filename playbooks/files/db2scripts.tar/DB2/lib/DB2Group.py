#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#####################################
#   DB2 group definition            #
#####################################
import json
import copy
from time import gmtime, strftime

class DB2Group:
    def __init__(self, groupName = '', gid = '', description = '', accountType = 'OS', isSysAdmGrp = False):
        self.groupName = groupName
        self.gid = gid
        self.description = description
        self.accountType = accountType
        self.createdOn = strftime("%Y-%m-%d %H:%M:%S", gmtime())  # Time
        self.updatedOn = strftime("%Y-%m-%d %H:%M:%S", gmtime())  # Time
        self.consumers = []
        self.isSysAdmGrp = isSysAdmGrp

    def __str__(self):
        tempDictory = copy.copy(self.getDirectory())
        return 'The group %s profile: %s' % (self.groupName, json.dumps(tempDictory, sort_keys = True, indent = 4))

    def loadFromDict(self, existing_group):
        self.groupName = existing_group['groupName']
        self.gid = existing_group['gid']
        self.description = existing_group['description']
        self.accountType = existing_group['accountType']
        self.consumers = existing_group['consumers']
        self.createdOn = existing_group['createdOn']
        self.updatedOn = existing_group['updatedOn']
        self.isSysAdmGrp = existing_group['isSysAdmGrp']

    def getDirectory(self):
        self.dictory = {
                     'groupName':self.groupName,
                     'gid':self.gid,
                     'description':self.description,
                     'accountType':self.accountType,
                     'consumers':self.consumers,
                     'createdOn':self.createdOn,
                     'updatedOn':self.updatedOn,
                     'isSysAdmGrp':self.isSysAdmGrp
                     }
        return self.dictory

    def getGroupName(self):
        return self.groupName

    def getGroupId(self):
        return self.gid

    def setGroupId(self, gid):
        self.gid = gid

    def getIsSysAdmGrp(self):
        return self.isSysAdmGrp

    def setIsSysAdmGrp(self, isSysAdmGrp):
        self.isSysAdmGrp = isSysAdmGrp

    def getAccountType(self):
        return self.accountType

    def setAccountType(self, accountType):
        self.accountType = accountType

    def getDescription(self):
        return self.description

    def setDescription(self, value):
        self.description = value

    def getIsAdmin(self):
        return self.isAdmin

    def setIsAdmin(self, value):
        self.isAdmin = value

    def getconsumers(self):
        return self.consumers

    def setconsumers(self, value):
        self.consumers = value

    def addConsumer(self, new_consumer):
        self.consumers.append(new_consumer)

    def removeConsumer(self, consumer):
        try:
            self.consumers.index(consumer)
            self.consumers.remove(consumer)
            return True
        except ValueError:
            return False

    def hasConsumer(self, consumer):
        try:
            self.consumers.index(consumer)
            return True
        except ValueError:
            return False

    def getCreatedOn(self):
        return self.createdOn

    def setCreatedOn(self, value):
        self.createdOn = value

    def getUpdatedOn(self):
        return self.updatedOn

    def setUpdatedOn(self, value):
        self.updatedOn = value

    def delDescription(self):
        del self.description

    def delIsAdmin(self):
        del self.isAdmin

    def delconsumers(self):
        del self.consumers

    def delCreatedOn(self):
        del self.createdOn

    def delUpdatedOn(self):
        del self.updatedOn

    def addGroup(self):
        return 'add_group_with_id %s %s %s' % (self.groupName, self.gid, self.accountType)

    def delGroup(self):
        return 'delete_group %s %s' % (self.groupName, self.accountType)
