#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import logging
#import maestro
import os
import json
import traceback
import types
from GlobalLock import Lock

class StorehouseUtil(object):
    
    def __init__(self, LOCAL_FILE, URL):
        self.logger = logging.getLogger("StorehouseUtil.py")
        
        self.LOCAL_FILE = LOCAL_FILE
        self.URL = URL
        
        self.jsonObject = None
        self.eTag = None
        self.__deltaToDelete = {}
        self.__deltaToUpdate = {}
        
        self.LOCK_NAME = 'store_house_util_lock'

    '''
    def delete(self):
        rc = maestro.delete(self.URL)
        return rc
    '''
        
    def has_key(self, key):
        if self.jsonObject == None:
            self.download()
        return self.jsonObject.has_key(key)
    
    def generate(self, jsonObject, new_collection = None):
        with open(self.LOCAL_FILE, 'w') as f:
            json.dump(jsonObject, f, sort_keys = True, indent = 4)
            f.flush()
        self.jsonObject = jsonObject
        return True
        #etag = maestro.get_etag(self.URL)
#        #collection = '.'
#        rc, self.eTag = maestro.upload_if_match(self.URL, self.LOCAL_FILE, etag, collection = '.')    
#        rc, self.eTag = maestro.upload_if_new(self.URL, self.LOCAL_FILE)
        '''rc, self.eTag = maestro.upload_if_match(self.URL, self.LOCAL_FILE, etag=etag,
                                                collection = new_collection, content_type = 'application/json')
        
        if rc:
            self.logger.debug("Succeeded in uploading the json file")
            self.jsonObject = jsonObject
            return True, self.eTag
        else:
            self.logger.debug("Failed in uploading the json file to the store house")
            return False, self.eTag
        '''
    
    '''
    def exist(self):
        try:
            url = maestro.replaceIP_w_CN(self.URL)
            self.logger.debug("check exist : %s" % url)
            args = ['-H', '"Content-Type: application/json"', '-o', self.LOCAL_FILE, '-kf', '-D', '-', url]
            cmd = maestro.get_curl_args(args, None, incl_sc_parm = True)
            rc, sto = maestro.trace_stderr_call(self.logger, cmd)
            if rc != 0:
                sc, etag = maestro._parse_headers(sto, 'ETag')
                if sc == '404':
                    self.logger.debug("Not exist 404")
                    return False
                else:
                    raise Exception('Get file %s failed, the sc is %s.' % (url, sc))
            self.logger.debug("Exist: yes")
            return True
        except:
            traceback.print_exc()
            return False
        
    def download(self, needRenew=False):
        self.logger.debug("download")
        try:
            if (needRenew or self.eTag == None or self.jsonObject == None):
                rc, self.eTag = maestro.download_if_changed(self.URL, self.LOCAL_FILE, None)
            else:
                rc, self.eTag = maestro.download_if_changed(self.URL, self.LOCAL_FILE, self.eTag)
            if rc:
                with open(self.LOCAL_FILE) as f:
                    self.jsonObject = json.load(f)
                return self.jsonObject
            else:
                return self.jsonObject
        except:
            self.logger.debug("Failed to download, file dose not exist in SH")
            return self.jsonObject

    def downloadWithoutTrace(self, needRenew=False):
        if (needRenew or self.eTag == None or self.jsonObject == None):
            rc, self.eTag = self.download_if_changed_no_trace(self.URL, self.LOCAL_FILE, None)
        else:
            rc, self.eTag = self.download_if_changed_no_trace(self.URL, self.LOCAL_FILE, self.eTag)
        if rc:
            with open(self.LOCAL_FILE) as f:
                self.jsonObject = json.load(f)
            return self.jsonObject
        else:
            return self.jsonObject        
        
    def download_if_changed_no_trace(self, url, f, etag=None, user_token=None):
    
        ''' #Download storehouse resource url to file f if changed - returns (downloaded,etag)
    '''
        url = maestro.replaceIP_w_CN(url)
    
        d = os.path.dirname(f)
        if not os.path.isdir(d):
            os.makedirs(d)
        args = ['-f','-o',f,'-D','-']
        if etag: args.extend( ['-H','If-None-Match: "%s"' % etag] )
        # t77669 try for faster http download.  It needs port 8585 open, which firewall does, when it's installed.
        if maestro._httpDownloadEnabled():
            args.extend( [ '-H', 'StorehouseCommand: unsecuredDownload'] )
        args.append(url)
        cmd = maestro.get_curl_args( args, user_token, incl_sc_parm=True )
        rc, stdout = maestro.trace_stderr_call(self.logger, cmd)
        sc, etag, ticket, sha2Checksum, md5Checksum = maestro._parse_headers(stdout, maestro._ETAG, maestro._DOWNLOAD_TICKET, maestro._CONTENT_SHA2, maestro._CONTENT_MD5)
        if rc != 0: raise Exception('Failed to download.  curl rc == %d, status code == %s' % (rc, sc))
        # sc 304 means the file has not changed, and has not been downloaded
        changed = sc != '304'
        if changed and ticket:
            # t77669 faster http download available, so let's use it to get the file
            # t77669 validate checksum for security
            retryWithHTTPS = False
            if not sha2Checksum:
                retryWithHTTPS = True
            else:
                del args[-3:]
                #  t77669 use http: to port :8585 on filerserver, not https: to port :9444 on storehouse
                args.extend( [ '-H', 'FileServerTicket: %s' % ticket, url.replace('https://', 'http://', 1).replace(':9444/storehouse', ':8585/fileserver', 1) ] )
                cmd = maestro.get_curl_args( args, user_token, incl_sc_parm=True, isSSL=False, incl_authn_header=False )
                rc, stdout = maestro.trace_stderr_call(self.logger, cmd)
                if rc == 0:
                    try:
                        fileChecksum = maestro.sha2_checksum_for_file(f)
                        checksum = sha2Checksum
                    except:
                        self.logger.debug('can not calculate sha2 checksum for %s, try md5 checksum' % f)
                        fileChecksum = maestro.md5_checksum_for_file(f)
                        checksum = md5Checksum
                    if fileChecksum != checksum.lower(): # SH uses A-F, python (and sha512sum) use a-f for hex digits
                        retryWithHTTPS = True
                else:
                    sc = maestro._parse_headers(stdout)[0]
                    retryWithHTTPS = True
            if retryWithHTTPS:
                del args[-3:]
                args.append(url)
                cmd = maestro.get_curl_args( args, user_token, incl_sc_parm=True )
                rc, stdout = maestro.trace_stderr_call(self.logger, cmd)
                sc, etag = maestro._parse_headers(stdout, maestro._ETAG)
                if rc != 0:
                    raise Exception('Failed to download.  curl rc == %d, status code == %s' % (rc, sc))
        return changed, etag
        
    
    def __deleteItem(self, target, keyArray):        
        if len(keyArray) == 1:
            del target[keyArray[0]]
        else:
            self.__deleteItem(target[keyArray[0]], keyArray[1:])

    def __updateDelta(self, srcDict, desDict):
        for key in desDict.keys():
            value = desDict[key]
            if (not type(value) is types.DictType) or key not in srcDict.keys():
                srcDict[key] = value
            else:
                self.__updateDelta(srcDict[key], desDict[key])
            
    def upload(self, upload_if_match=True):
        self.logger.debug("upload begin")
        with Lock(self.LOCK_NAME):
            uploaded = False
            if self.__deltaToUpdate == None and self.__deltaToDelete == None:
                return 1
            while not uploaded:
                self.logger.debug("upload iteration begin")
                self.download(needRenew=True)
                if self.__deltaToUpdate != {}:
    #                for key in self.__deltaToUpdate.keys():
    #                    self.jsonObject[key]=self.__deltaToUpdate[key]
                    self.__updateDelta(self.jsonObject, self.__deltaToUpdate)
    #                self.jsonObject.update(self.__updateDelta)
                    
                if self.__deltaToDelete != {}:
                    for array in self.__deltaToDelete:
                        self.__deleteItem(self.jsonObject, array)
    
                with open(self.LOCAL_FILE, 'w') as f:
                    json.dump(self.jsonObject, f, sort_keys = True, indent = 4)
                    f.flush()
                self.logger.debug("Before upload, etag : %s" % str(self.eTag))
                if upload_if_match:
                    uploaded, self.eTag = maestro.upload_if_match(self.URL, self.LOCAL_FILE, self.eTag, collection = '.', content_type = 'application/json')
                else:
                    uploaded, self.eTag = maestro.upload_if_match(self.URL, self.LOCAL_FILE, content_type = 'application/json')
                if not uploaded:
                    self.logger.debug("upload_if_match fail due to etag no match")
                else:
                    self.logger.debug("upload_if_match succeeded")
                self.logger.debug("upload iteration end")
            self.logger.debug("upload end")
    '''
    '''
    def uploadJsonIfMatch(self, url, f, etag = None, user_token = None, collection = None, logger = None):
        self.logger.debug('uploadJsonIfMatch %s to %s' % (f, url))
    '''
    '''
        if not os.path.isfile(f):
            raise Exception('Local file to upload doesn\'t exist or is not a file (%s)' % f)
        url = maestro.replaceIP_w_CN(url)
        
        cond_h = 'If-Match: "%s"' % etag if etag else 'If-None-Match: *'
        cmd = maestro.get_curl_args(['-s', '-S', '-X', 'PUT', '-f', '-H', 'Content-Type: application/json', '-H', cond_h, '--data-binary', '@%s' % f, '-D', '-', url], user_token, incl_sc_parm = True)
    
        rc, sto = maestro.trace_stderr_call(logger, cmd)
        sc, new_etag = maestro._parse_headers(sto)
    
        if rc != 0 and not (rc == 22 and sc == '412'):
            raise Exception('curl exit code %s, response status %s' % (rc, sc))
    
        uploaded = (rc == 0 and sc != '412')
    
        if uploaded and collection and not etag:
            metadata = r'{ "Collection" : "%s" }' % collection
            meta_url = '%s?meta=' % url
            cmd = maestro.get_curl_args(['-s', '-S', '-X', 'POST', '-f', '-H', 'Content-Type: application/json', '--data-binary', metadata, '-D', '-', meta_url], user_token, incl_sc_parm = True)
            mrc, sto = maestro.trace_stderr_call(logger, cmd)
            if mrc != 0:
                raise Exception('upload succeeded but collection metadata update failed with curl exit code %s, response status %s' \
                                % (mrc, maestro._parse_headers(sto)[0]))
    
        logger.debug('Upload returning uploaded=%s, new_etag=%s' % (uploaded, new_etag))
        return uploaded, new_etag

    def updateDelta(self, updateDelta):
        self.__deltaToUpdate = updateDelta
    '''
    '''
    i.e, target file is:
        {
          "a": {
                "b":"b1",
                "bb":"bb1"
                },
          "c":{"ccc"},
          "d":"ddd"
          }
    and you want to delete "a:b" and "c" items, and make them:
        {
          "a": {
                "bb":"bb1"
                },
          "d":"ddd"
          }
    then deleteDelta should be [ ["a", "b"] , ["c"] ]
    '''
    '''
    def deleteDelta(self, deletDelta):
        self.__deltaToDelete = deletDelta
    '''
    
    def __str__(self):
        return str(self.jsonObject)
