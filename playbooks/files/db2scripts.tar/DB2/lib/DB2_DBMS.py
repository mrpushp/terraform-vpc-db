#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
#import maestro
import os
import re
import nls
import subprocess
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse
import platform
import logging
import util
import tempfile
import shutil
import time
import common
from ParallelSSH import ParallelSSH

filesurl = 'https://9.42.52.165/icpsfiles/db2/'
scriptdir = '/tmp/db2scripts'

class DB2_DBMS():
    def __init__(self, installDir, databaseFixpack, db2level, fixpacksList ):        
        self.shell_script = os.path.normpath(os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell'))
        self.logger = logging.getLogger("DB2/DB2_DBMS.py")
        #self.dbms_home = maestro.node['parts']['DB2']['installDir']
        self.dbms_home = installDir
        self.databaseFixpack = databaseFixpack
        self.db2level = db2level  # This should be internally found ?
        self.fixpacksList = fixpacksList
         
        #parms = maestro.parms
        #if 'databaseFixpack' in parms:
        if self.databaseFixpack:
            #self.logger.debug("DB2 DBMS version from UI/REST is: %s" % parms['databaseFixpack'])
            self.logger.debug("DB2 DBMS version from UI/REST is: %s" % self.databaseFixpack)
            #if re.match("^\d+\.\d+\.\d+\.\d+$", parms['databaseFixpack']):
            if re.match("^\d+\.\d+\.\d+\.\d+$", self.databaseFixpack):
                #if (util.get_db2_version(maestro.configurations['db2level']) != util.get_db2_version(parms['databaseFixpack'])):
                if (util.get_db2_version(self.db2level) != util.get_db2_version(self.databaseFixpack)):
                    raise Exception ("Fixpack  selected did not match with major DB2 version.")
                else:
                    #self.db2Level = parms['databaseFixpack']
                    self.db2Level = self.databaseFixpack
            else:
                self.logger.debug('DB2 DBMS version set in the pattern isnot well formatted,  use the version specified in the plug-in config')
                #self.db2Level = maestro.configurations['db2level']
                #Not sure what level value is exactly, hardcoding to 11.5.0.0 for now
                self.db2Level = '11.5.0.0'
        else:
            self.logger.debug('DB2 DBMS version is not set in the pattern,  use the version specified in the plug-in config')
            #self.db2Level = maestro.configurations['db2level']    
            #Not sure what level value is exactly, hardcoding to 11.5.0.0 for now
            self.db2Level = '11.5.0.0'   
        self.db2_major_version = util.get_db2_version(self.db2Level)
        self.db2_package = self.get_dbms_info()
        if self.db2_package is None:
            #self.db2_package = maestro.node['parts']['DB2']['binaryFile']
            #Hardcode for 11.5 linux
            self.db2_package = 'IPAS_DBaaS_1.2.12.0_aix64_server_11.5.0.0.tgz'
        self.logger.debug('dbms home: %s, version: %s' % (self.dbms_home, self.db2Level))
        self.logger.debug('dbms install package: %s' % (self.db2_package))        
        nls.install()

    def get_dbms_home(self):
        return self.dbms_home    
        
        
    def get_dbms_info(self):
        built_db2_package_map = {
            "Linux": {
                "10.5": {
                    "10.5.0.4": "db2server/IPAS_DBaaS_1.2.0.1_linuxx64_server_10.5.0.4.tgz",
                    "10.5.0.5": "db2server/IPAS_DBaaS_1.2.2.2_linuxx64_server_10.5.0.5.tgz",
                    "10.5.0.6": "db2server/IPAS_DBaaS_1.2.3.0_linuxx64_server_10.5.0.6.tgz",
                    "10.5.0.8": "db2server/IPAS_DBaas_1.2.5.0_linuxx64_server_10.5.0.8.tgz",
                    "10.5.0.9": "db2server/IPAS_DBaas_1.2.6.1_linuxx64_server_10.5.0.9.tgz",
                    "10.5.0.10": "db2server/IPAS_DBaaS_1.2.8.0_linuxx64_server_10.5.0.10.tgz",                    
					"10.5.0.10": "db2server/IPAS_DBaaS_1.2.9.0_linuxx64_server_10.5.0.10.tgz",
                    "10.5.0.10": "db2server/IPAS_DBaaS_1.2.10.0_linuxx64_server_10.5.0.10.tgz"
                },
                "11.1": {
                    "11.1.1.1": "db2server/IPAS_DBaas_1.2.5.0_linuxx64_server_11.1.1.1.tgz",
                    "11.1.3.3": "db2server/IPAS_DBaas_1.2.6.1_linuxx64_server_11.1.3.3.tgz",
                    "11.1.4.4": "db2server/IPAS_DBaaS_1.2.8.0_linuxx64_server_11.1.4.4.tgz",                    
					"11.1.4.4": "db2server/IPAS_DBaaS_1.2.9.0_linuxx64_server_11.1.4.4.tgz",
                    "11.1.4.4": "db2server/IPAS_DBaaS_1.2.10.0_linuxx64_server_11.1.4.4.tgz",
                    "11.1.4.5": "db2server/IPAS_DBaaS_1.2.11.0_linuxx64_server_11.1.4.5.tgz",
                    "11.1.4.5": "db2server/IPAS_DBaaS_1.2.12.0_linuxx64_server_11.1.4.5.tgz"
                },
                "11.5": {
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.10.0_linuxx64_server_11.5.0.0.tgz",
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.11.0_linuxx64_server_11.5.0.0.tgz",
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.12.0_linuxx64_server_11.5.0.0.tgz"
                    
                }      
            },
            "AIX": {
                "10.5": {
                    "10.5.0.4": "db2server/IPAS_DBaaS_1.2.0.1_aix64_server_10.5.0.4.tgz",
                    "10.5.0.5": "db2server/IPAS_DBaaS_1.2.2.2_aix64_server_10.5.0.5.tgz",
                    "10.5.0.6": "db2server/IPAS_DBaaS_1.2.3.0_aix64_server_10.5.0.6.tgz",
                    "10.5.0.8": "db2server/IPAS_DBaas_1.2.5.0_aix64_server_10.5.0.8.tgz",
                    "10.5.0.9": "db2server/IPAS_DBaas_1.2.6.1_aix64_server_10.5.0.9.tgz",
                    "10.5.0.10": "db2server/IPAS_DBaaS_1.2.8.0_aix64_server_10.5.0.10.tgz",
					"10.5.0.10": "db2server/IPAS_DBaaS_1.2.9.0_aix64_server_10.5.0.10.tgz",
                    "10.5.0.10": "db2server/IPAS_DBaaS_1.2.10.0_aix64_server_10.5.0.10.tgz"
                },
                "11.1": {
                    "11.1.1.1": "db2server/IPAS_DBaas_1.2.5.0_aix64_server_11.1.1.1.tgz",
                    "11.1.3.3": "db2server/IPAS_DBaas_1.2.6.1_aix64_server_11.1.3.3.tgz",
                    "11.1.4.4": "db2server/IPAS_DBaaS_1.2.8.0_aix64_server_11.1.4.4.tgz",
                    "11.1.4.4": "db2server/IPAS_DBaaS_1.2.9.0_aix64_server_11.1.4.4.tgz",
                    "11.1.4.4": "db2server/IPAS_DBaaS_1.2.10.0_aix64_server_11.1.4.4.tgz",
                    "11.1.4.5": "db2server/IPAS_DBaaS_1.2.11.0_aix64_server_11.1.4.5.tgz",
                    "11.1.4.5": "db2server/IPAS_DBaaS_1.2.12.0_aix64_server_11.1.4.5.tgz"                    
                },
                "11.5": {
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.10.0_aix64_server_11.5.0.0.tgz",
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.11.0_aix64_server_11.5.0.0.tgz",
                    "11.5.0.0": "db2server/IPAS_DBaaS_1.2.12.0_aix64_server_11.5.0.0.tgz"
                                        
                }    
            }
        }
        
        if platform.system() == 'Linux':
            sysstr = 'Linux'
        else:
            sysstr = 'AIX'
        
        return built_db2_package_map[sysstr][self.db2_major_version][self.db2Level]

    # Apply licenses
    @util.performance_profile_trace
    def apply_db2_license(self):
        #dbms_licenses = 'db2aese_tb.lic'
        self.logger.debug('Major version: %s' % self.db2_major_version)
        if self.db2_major_version == "11.5":
            dbms_licenses= 'db2adv_vpc.lic'
        else:
            dbms_licenses = 'db2awse_c.lic'
        self.logger.debug('Adding DB2 license file(s): %s' % dbms_licenses)
        
        license_path = os.path.normpath(os.path.join( \
                            os.path.split(os.path.realpath(__file__))[0], \
                            os.path.pardir, 'licenses', \
                            'V' + self.db2_major_version))
        args = [self.dbms_home, license_path, dbms_licenses]
        util.trace_shell_func_call('db2_license_add', *args)
    
    # Remove license
    def remove_db2_license(self):
        self.logger.debug('Remove License Major version is: %s' % self.db2_major_version)
        if self.db2_major_version == "11.5":
            dbms_licenses= 'db2awse'
        
        args = [self.dbms_home,dbms_licenses]
        util.trace_shell_func_call('db2_license_remove', *args)
    
    @util.performance_profile_trace
    def install_DBMS(self):
        # install database product
        args = [self.dbms_home]
        #rc = util.trace_shell_func_call('install_dbms', *args)
        #maestro.check_status(rc, 'Failed while executing install_dbms')
        #rc=util.trace_shell_func_call('install_dbms', *args)
        rc=common.install_dbms(self.dbms_home)
        if rc != 0:
            raise Exception("install_dbms exception")


    @util.performance_profile_trace
    def install_TSMAP(self):
        # Install TSA MP
        if self.db2Level <= "10.5.0.6":
            chk = "1"
        else:
            chk = "0"
        args = [self.dbms_home, chk]
        
        try:
            rc=common.install_tsamp(self.dbms_home, chk)
            if rc == 0:
                self.logger.debug('Succeed to install TSAMP')
            else:
                self.logger.debug('Fail to install TSAMP')
                raise Exception("install_TSAMP exception")
        except Exception as e:
            self.logger.debug("Exception caught")
            self.logger.debug(e)
            import traceback
            traceback.print_exc()
            self.logger.debug("TSAMP Installation failed")
            
        #rc = maestro.trace_call(self.logger, "%s/install/tsamp/db2cptsa" % self.dbms_home)
        rc, out, err=util.runShell("%s/install/tsamp/db2cptsa" % self.dbms_home)
        
        if rc != 0:
            self.logger.debug("Failed to run %s/install/tsamp/db2cptsa" % self.dbms_home)
        else:
            self.logger.debug("Succeeded to run %s/install/tsamp/db2cptsa" % self.dbms_home)

    @util.performance_profile_trace
    def install(self):       
        #maestro.downloadx(urlparse.urljoin(maestro.filesurl, self.db2_package), self.dbms_home)  
        #Assume available at /tmp
        #util.downloadFile(urlparse.urljoin(filesurl, self.db2_package), '/tmp', self.db2_package)
        print("***** %s   %s******" % (self.db2_package, self.dbms_home))
        util.extractFile(os.path.join('/tmp',self.db2_package), self.dbms_home)
        self.install_DBMS()
        #self.install_TSMAP()
        self.apply_db2_license()

        '''
        ##Anshu commented
        self.logger.debug("Getting Fixpack details to upgrade")
        #if 'fixpacksList' in maestro.parms:
        if self.fixpacksList:
            #fixpackName = maestro.parms['fixpacksList']
            fixpackName = self.fixpacksList
            #to check default condition when user DO NOT select a fixpack     
            if fixpackName != 'NONE' and fixpackName != "":
                self.logger.debug("Current Fixpack is %s" % self.db2Level)
                self.logger.debug("Need to Upgrade to Fixpack %s" % fixpackName)
                rc = self.upgrade_core(fixpackName)
                if rc == 0:                
                    self.logger.debug("Upgrade to Fixpack %s successful" % fixpackName)
                else:
                    self.logger.debug("Upgrade to Fixpack %s Failed with error %d" % (fixpackName, rc))
       

    @util.performance_profile_trace
    def download_upgrade_package(self, installerUrl, fixpack_dir, db2_package):
        if platform.system() == 'Linux':
            maestro.downloadx(installerUrl, fixpack_dir)
        else:
            target_path = os.path.join(fixpack_dir, db2_package)
            maestro.download(installerUrl, target_path)
            #delete the image after unzip
            cmd = 'cd %s; gunzip < %s | tar xf -; rm -f %s; cd - ' % (fixpack_dir, db2_package, target_path)
            subprocess.call(cmd, shell = True)

    # call this to upgrade a stopped database with installFixPack
    @util.performance_profile_trace
    def upgrade_core(self, fixpack_url):
        self.logger.debug("upgrade_core")
        #scriptdir is defined globally
        #scriptdir = maestro.node['scriptdir']
        #tmpdir = maestro.role['tmpdir']
        tmpdir = tempfile.gettempdir()
            
        basedir = os.path.join(scriptdir, 'DB2')
        rc = 0
        fixpack_dir = os.path.join(tmpdir, 'db2upgrade_%s' % str(os.getpid()))
        os.makedirs(fixpack_dir)
        url_index = maestro.node['deployment.url'].rfind("deployments")
        download_url = maestro.node['deployment.url'][:url_index] + "db2/fixpacks/" + fixpack_url

        self.logger.debug('download url:%s' % download_url)
        self.logger.debug('fixpack_dir:%s' % fixpack_dir)
        try:
            #maestro.downloadx(download_url, fixpack_dir)
            self.download_upgrade_package(download_url, fixpack_dir, fixpack_url)

            func_agent_sh = os.path.join(basedir, 'shell', 'func_agent.sh')
            rc = util.trace_call(self.logger, func_agent_sh, 'db2_upgrade', fixpack_dir, self.dbms_home)
        except:
            import traceback
            traceback.print_exc()
            raise Exception("db2 upgrade exception")
        finally:
            if os.path.exists(fixpack_dir):
                self.logger.debug('delete the fixpack_dir under: %s after upgrade' % fixpack_dir)
                shutil.rmtree(fixpack_dir)
        return rc

    def remove_fixpack_files(self, fixpack_dir):
        if os.path.exists(fixpack_dir):
            self.logger.debug('delete the fixpack_dir under: %s after upgrade' % fixpack_dir)
            shutil.rmtree(fixpack_dir)

    # call this to upgrade an existing and running database
    @util.performance_profile_trace
    def upgrade(self, fixpack_name):
        self.logger.debug("upgrade begin")
        try:
            fixpack_name = fixpack_name.strip()
            fixpack_version = util.parse_fixPack_version(fixpack_name)
            self.logger.debug("fixpack_name=%s, fixpack_version=%s" % (fixpack_name, fixpack_version))
            if (platform.system() == 'Linux' and \
                    fixpack_name.find('linuxx64') == -1 and fixpack_name.find('linuxamd64') == -1) \
                    or platform.system() == 'AIX' and fixpack_name.find('aix64') == -1:
                self.logger.error("The specified DB2 version %s is not compatible with OS platform %s!" % (fixpack_name, platform.system()))
                msg = 'db2 upgrade fail'
                return [1, msg]

            has_hadr_db = False
            inst_name = maestro.parms["instanceOwner"]
            
            if 'DATABASES' in maestro.export:
                for db in maestro.export['DATABASES']['databases']:
                    if 'HADR' in maestro.export['DATABASES']['databases'][db] \
                            and maestro.export['DATABASES']['databases'][db]['HADR'] == 'true':
                        has_hadr_db = True
                    
            fixpack_dir = os.path.join(tempfile.gettempdir(), 'db2upgrade_%s' % fixpack_version)
            if not os.path.exists(fixpack_dir):
                self.logger.debug('not exist, %s' % fixpack_dir)
                os.system('mkdir -p %s' % fixpack_dir)
            else:
                self.logger.debug('exist, %s' % fixpack_dir)

            # Added code related to PMR 247432
            #self.logger.debug('Checking Pre-req')
            #db2prereqcheckrc = self.check_db2_prereq(self.dbms_home)
            #if (db2prereqcheckrc == 1):
            #   self.logger.debug('Prereq check related to space availability is successful!')
            #else:
            #   self.logger.debug('Prereq check related to space availability failed!')
            
            if (not has_hadr_db):
                rc = self.upgrade_normal(fixpack_name, fixpack_dir)
            elif (has_hadr_db):
                rc = self.upgrade_hadr(fixpack_name, fixpack_dir)
            else:
                rc = -1    
            
            if rc == 0:
                from DB2_Instance import DB2_Instance
                inst_name = maestro.parms["instanceOwner"]
                inst_agent = DB2_Instance(inst_name)
                inst_agent.update_profile({"db2Level": util.get_db2_level()})

        except Exception as e:
            self.logger.debug("Exception caught")
            self.logger.debug(e)
            import traceback
            traceback.print_exc()
            self.logger.debug("need to restart the VM to start the db2")
            rc = -1
        finally:
            self.remove_fixpack_files(fixpack_dir)
            pass
            if rc == 0:
    #            msg = 'db2 upgrade success'  # NLS
                msg = "Successfully upgraded db2 fixpack to the latest version: '%s'" % (fixpack_version)
                self.logger.info(msg)
                return [True, msg]
            elif rc == -1:
                #msg = 'db2 upgrade fail'
                msg = "Failed to upgrade db2 fixpack to version: '%s'" % (fixpack_version)
                self.logger.error(msg)
                return [False, msg]
            elif rc == 1:
                installed_version = util.get_db2_level().strip()
                msg = 'No need to upgrade a database from: ''%s'' to: ''%s''' 
        ''' 
                ###Anshu commented
                % (installed_version, fixpack_version)
                return [True, msg]
    
    # rc = -1: upgrade failed; 0: succeeded; 1: no need to upgrade
    def upgrade_normal(self, fixpack_name, fixpack_dir):
        self.logger.debug("upgrade_normal")
        fixpack_version = util.parse_fixPack_version(fixpack_name)
        installed_version = util.get_db2_level().strip()
        self.logger.debug("installed_version=%s, fixpack_version=%s" % (installed_version, fixpack_version))
        is_special_build = fixpack_name.find("special")
        version_compare = util.compare_versions(installed_version, fixpack_version)
        #if it's a special build, installed_version should be the same with fixpack_version           
        if (is_special_build >=0 and version_compare ==0) or (is_special_build == -1 and version_compare == -1):
            self.logger.debug('upgrade_normal, whether it is a special build by: ''%s''' 
        ''' % (is_special_build))
            ###Anshu commented
            self.logger.debug('upgrade_normal, and version comparation result is: ''%s''' 
        '''% (version_compare))
            url_index = maestro.node['deployment.url'].rfind("user/deployments")
            download_url = maestro.node['deployment.url'][:url_index] + "user/db2/fixpacks/" + fixpack_name
            self.logger.debug('download_url:%s' % download_url)
            self.download_package(download_url, fixpack_dir)
            self.logger.debug('fixpack_dir:%s' % fixpack_dir)
            db2prereqcheckrc = self.check_db2_prereq(fixpack_dir)
            if (db2prereqcheckrc == 1):
               self.logger.debug('Prereq check related to space availability is successful!')
            else:
               self.logger.debug('Prereq check related to space availability failed!')
               return -1 
            self.logger.debug("Begin to call pre_db2_upgrade, db2_upgrade, post_db2_upgrade")
            inst_name = maestro.parms["instanceOwner"]
            util.trace_shell_func_call('pre_db2_upgrade', inst_name)
            rc = util.trace_shell_func_call('db2_upgrade', fixpack_dir, self.dbms_home)
            util.trace_shell_func_call('post_db2_upgrade', inst_name)            
            
            if rc == 0:
                #db2updv command based on the db2 version
                self.upgrade_database()
                return 0
            else:
                return -1
        else:
            self.logger.debug("No need to install fixpack")
            return 1

    # rc = -1: upgrade failed; 0: succeeded; 1: no need to upgrade
    @util.performance_profile_trace
    def upgrade_hadr(self, fixpack_name, fixpack_dir):
        self.logger.debug("upgrade_hadr")
        fixpack_version = util.parse_fixPack_version(fixpack_name)
        installed_version = util.get_db2_level().strip()
        is_special_build = fixpack_name.find("special")
        version_compare = util.compare_versions(installed_version, fixpack_version)
        self.logger.debug('upgrade_hadr, whether it is a special build by: ''%s''' 
        ''' % (is_special_build))
        self.logger.debug('upgrade_hadr, and version comparation result is: ''%s''' 
        ''' % (version_compare))
        self.logger.debug("installed_version=%s, fixpack_version=%s" % (installed_version, fixpack_version))
        fixpack_upgraded_locally = False
        fixpack_upgraded_remotelly = False
        from DB2_Instance import DB2_Instance
        inst_name = maestro.parms["instanceOwner"]
        inst_agent = DB2_Instance(inst_name)
        take_over_done = False
        fixpack_downloaded = False
        remote_public_ip_list = {}
        db2prereqcheckrc=1
        url_index = maestro.node['deployment.url'].rfind("user/deployments")
        download_url = maestro.node['deployment.url'][:url_index] + "user/db2/fixpacks/" + fixpack_name
        self.logger.debug('download_url:%s' % download_url)
        hosts_to_upgrade = self.get_hosts_to_upgrade(fixpack_version, fixpack_name)
        self.logger.debug("hosts_to_upgrade=%s" % str(hosts_to_upgrade))
        if (is_special_build >= 0 and version_compare !=0) or (is_special_build == -1 and version_compare != -1) or len(hosts_to_upgrade) == 0:
            self.logger.debug('upgrade_hadr, special build or fix pack no need to upgrade')
            return 1
        try:
            # record hadr role for every db
            if 'DATABASES' in maestro.export:
                for db in maestro.export['DATABASES']['databases']:
                    if 'HADR' in maestro.export['DATABASES']['databases'][db] \
                            and maestro.export['DATABASES']['databases'][db]['HADR'] == 'true':
                        if not 'DB2LUW_HADR' in maestro.role:
                            maestro.role['DB2LUW_HADR'] = {}
                        maestro.role['DB2LUW_HADR'][db] = maestro.export['DATABASES']['databases'][db]['HADR_ROLE']

            if (is_special_build >= 0 and version_compare == 0) or (is_special_build == -1 and version_compare == -1):
                self.logger.debug('upgrade_hadr, need to upgrade')
                self.logger.debug('download fixpack to :%s' % fixpack_dir)
                self.download_package(download_url, fixpack_dir)
                fixpack_downloaded = True
                self.logger.debug('fixpack_dir:%s' % fixpack_dir)
                db2prereqcheckrc = self.check_db2_prereq(fixpack_dir)
                if (db2prereqcheckrc == 1):
                    self.logger.debug('Prereq check related to space availability is successful!')
                else:
                    self.logger.debug('Prereq check related to space availability failed!')
                    return -1 
                self.logger.debug("Step 1. Start HADR upgrade")
                #inst_agent.makeAllHADRDatabasesStandby()
                self.logger.debug("Step 2. HADR rolling upgrade locally")
                rc = util.trace_shell_func_call('hadr_rolling_uprade', self.dbms_home, fixpack_dir, inst_name)
                fixpack_upgraded_locally = True
                if rc != 0:
                    self.logger.debug("Failed to perform HADR rolling upgrade locally")
                    return -1
            else:
                self.logger.debug("Locally, installed_version=%s, fixpack_version=%s" % (installed_version, fixpack_version))
                self.logger.debug("No need to install fixpack locally, skip Step 1 and 2")
            
            if len(hosts_to_upgrade) == 0:
                self.logger.debug("No need to upgrade remote hosts")
            else:
                for remote_public_ip in hosts_to_upgrade:
                    if remote_public_ip not in remote_public_ip_list:
                        remote_public_ip_list[remote_public_ip] = inst_name
                        sshShell = ParallelSSH([remote_public_ip], self.logger)
                        if not fixpack_downloaded:
                            self.logger.debug('download fixpack to :%s' % fixpack_dir)
                            self.download_package(download_url, fixpack_dir)
                            fixpack_downloaded = True
                    
                        if not take_over_done:
                            self.logger.debug("Step 3. take over all databases at local host")
                            if inst_agent.makeAllHADRDatabasesPrimary():
                                self.logger.debug("Succeeded to take over all databases at local host")
                                take_over_done = True
                            else:
                                take_over_done = False
                                self.logger.debug("Failed to take over databases on standby,pls manually upgrade primary")
                                return -1                        
                        self.logger.debug("Step 4. HADR rolling update remotely")
                        sshShell.ssh("mkdir -p " + fixpack_dir)
                        sshShell.scp(fixpack_dir, 'root', os.path.dirname(fixpack_dir))
                        rc, status = sshShell.ssh("func_agent.sh %s %s %s %s" % ('hadr_rolling_uprade', self.dbms_home, fixpack_dir, inst_name))
                        fixpack_upgraded_remotelly = True
                        sshShell.ssh("rm -rf " + fixpack_dir)
                        if not rc:
                            self.logger.debug("Failed to perform HADR rolling upgrade remotely, rc=%s" % str(rc))
                            return -1
        finally:
            if fixpack_upgraded_locally or fixpack_upgraded_remotelly:
                self.logger.debug("Step 5. migrate and double check")
                #Retry migrate_check twice and if it doesn't succeed, then stop with appropriate error code.\n"
                retryCount=0
                while retryCount <= 1:
                      #Added delay to finish the RSCT upgrade PMR252564\n"
                      self.logger.debug("60 sec delay added to finish the RSCT migration")
                      time.sleep(60)
                      rc = util.trace_shell_func_call("migrate_check")
                      if rc == 0:
                         self.logger.debug("Migrate check succeeded")
                         break;
                      retryCount=retryCount+1;
                if rc == 1:
                   self.logger.debug('Migrate check failed')
                   return -1         
                self.logger.debug("Step 6. make database hadr role back")
                # restore hadr role for every db
                if 'DB2LUW_HADR' in maestro.role:
                    standby_db_list = []
                    primary_db_list = []
                    for db in maestro.role['DB2LUW_HADR']:
                        if maestro.role['DB2LUW_HADR'][db].upper() == "STANDBY":
                            standby_db_list.append(db)
                        else:
                            primary_db_list.append(db)
                    #inst_agent.makeAllHADRDatabasesPrimary(primary_db_list)
                    #inst_agent.makeAllHADRDatabasesStandby(standby_db_list)
                    inst_agent.makeAllHADRDatabasesPrimary()
                    inst_agent.makeAllHADRDatabasesStandby()
                if rc != 0:
                    return -1
                else:
                    return 0
            elif (db2prereqcheckrc != 1):
                return -1
                
            else:
                self.logger.debug("fixpack is not upgraded locally and remotely, skip Step 5 and 6")
                return 1

    def get_hosts_to_upgrade(self, fixpack_version, fixpack_name):
        self.logger.debug("get_hosts_to_upgrade")
        from DB2_Instance import DB2_Instance
        inst_name = maestro.parms["instanceOwner"]
        inst_agent = DB2_Instance(inst_name)
        hadr_manager_list = inst_agent.getHADRManagerList()
        hosts_to_upgrade = []
        hosts_checked = []
        for db_name in hadr_manager_list:
            hadr_manager = hadr_manager_list[db_name]
            remote_public_ip = hadr_manager.getCounterpartNodeInfo().publicIP
            if remote_public_ip not in hosts_checked:
                hosts_checked.append(remote_public_ip)
                sshShell = ParallelSSH([remote_public_ip], self.logger)
                rc, rc_msg, remote_result = sshShell.sshWithOutput("func_agent.sh get_db2_level")
                self.logger.debug("remote_result=%s"%remote_result)
                remote_db2_level = remote_result[remote_public_ip]
                is_special_build = fixpack_name.find("special")
                version_compare = util.compare_versions(remote_db2_level, fixpack_version)
                self.logger.debug("in get_hosts_to_upgrade, version_compare is %s"%version_compare)
                if (is_special_build >=0 and version_compare == 0) or (is_special_build == -1 and version_compare == -1):
                    hosts_to_upgrade.append(remote_public_ip)
        return hosts_to_upgrade

    @util.performance_profile_trace
    def upgrade_by_payload(self):
        self.logger.debug("upgrade_by_payload")

        installed_version = util.get_db2_level()
        installerUrl = urlparse.urljoin(maestro.filesurl, self.db2_package)
        fixpack_version = util.parse_fixPack_Payload_version(self.db2_package)
        self.logger.debug("fixpack_version1=%s"%fixpack_version)
        fixpack_version = self.db2Level
        m1=re.search("\d+\.\d", installed_version)
        m2=re.search("\d+\.\d", fixpack_version)
        self.logger.debug("installed_version m1=%s"%m1.group(0))
        self.logger.debug("fixpack_version m2=%s"%m2.group(0))
        if(m1.group(0) == m2.group(0)):
            self.logger.debug("fixpack_version2=%s"%fixpack_version)
            compare_versions = util.compare_versions(installed_version, fixpack_version)
            self.logger.debug("installed_version=%s, fixpack_version=%s, compare_versions=%d" \
                              % (installed_version, fixpack_version, compare_versions))
            license_name=util.trace_shell_func_call_with_output('get_db2_license', self.dbms_home)
            self.logger.debug("License product is=%s"%license_name)
            rc = -1
            if util.compare_versions(installed_version, fixpack_version) == -1:
                util.trace_shell_func_call('stop_all_instances', self.dbms_home)
                
                #uninstall the dbms under payload fixpack
                rm_sh = ['rm']
                rm_sh.extend(['-rf', self.dbms_home])
                self.logger.debug(rm_sh)
                maestro.trace_call(self.logger, rm_sh)
                #download the payload fixpack
                self.download_package(installerUrl, self.dbms_home)
                
                #upgrade the db2            
                rc = util.trace_shell_func_call('upgrade_all_db2_instances', self.dbms_home)
                util.trace_shell_func_call('start_all_instances', self.dbms_home)
               
                #apply the license under payload fixpack
                self.apply_db2_license()
                #remove the db2awse license
                if self.db2_major_version == "11.5":
                    if license_name == "\"db2awse\"":
                        self.remove_db2_license()
            
            else:
                if self.db2_major_version == "11.5":
                    if license_name == "\"db2awse\"":
                        self.apply_db2_license()
                        self.remove_db2_license()
                        
                self.logger.debug("No need to upgrade payload")
            self.logger.debug('upgrade_by_payload_normal end')
    
            if rc == 0:
                from DB2_Instance import DB2_Instance
                inst_name = maestro.parms["instanceOwner"]
                inst_agent = DB2_Instance(inst_name)
    #            inst_agent.update_profile({"db2Level": util.get_db2_level()})
                inst_agent.update_profile({"db2Level": self.db2Level})
                
                #db2updv command based on the db2 version
                self.upgrade_database()

    def download_package(self, installerUrl, dbms_home):
        self.logger.debug("download_package")
        self.logger.debug("platform.system() = %s" % platform.system())
        if platform.system() == 'Linux':
            maestro.downloadx(installerUrl, dbms_home)
        else:
            index = installerUrl.rfind("/")
            db2_package = installerUrl[index+1:]
            target_path = os.path.join(dbms_home, db2_package)
            maestro.download(installerUrl, target_path)
            # delete the image after unzip
            self.logger.debug("db2_package=%s" % db2_package)
            cmd = 'cd %s; gunzip < %s | tar xf -; rm -rf %s; cd - ' % (dbms_home, db2_package, db2_package)
            subprocess.call(cmd, shell=True)
    
    def upgrade_database(self):
        self.logger.debug("Begin to call db_db2_upgrade_105 or db_db2_upgrade_111 or db_db2_upgrade_115")
            
        if self.db2_major_version == "10.5":
            util.trace_shell_func_call('db_db2_upgrade_105', self.dbms_home)
            
        if self.db2_major_version == "11.1":
            util.trace_shell_func_call('db_db2_upgrade_111', self.dbms_home)
        if self.db2_major_version == "11.5":
            util.trace_shell_func_call('db_db2_upgrade_115', self.dbms_home)       
        self.logger.debug("Finishing db_db2_upgrade_105 or db_db2_upgrade_111 or b_db2_upgrade_115")
    '''    
        
    def check_db2_prereq(self, db2_home):
        # Added code related to PMR 247432
        # Reach to the ./ibm/db2/V10.5/instance/native/install/db2prereqcheck path
        
        self.logger.debug("****************************DB2_DBMS.py file, check_db2_prereq***************************")
        self.logger.debug("db2 home: %s" % db2_home)
        
        # Run db2prereqcheck with fpversion
        args = [db2_home]
        rc = util.trace_shell_func_call('check_db2_prereq', *args)
        # if this function returns 1 - it means pre req check related to space availability is successful
        # if this function returns 0 - it means pre req check related to space availability failed 
        self.logger.debug("Fixpack Installation prereq check rc code : %s" % rc)
        
        
        return rc
