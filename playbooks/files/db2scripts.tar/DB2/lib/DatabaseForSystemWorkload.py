#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import util
import json
import logging
import maestro
import nls
import os
import traceback
import copy
import time
import datetime
import platform

from StorehouseUtil import StorehouseUtil
from UserGroupManager import UserGroupManager
from DB2User import DB2User
from StorageManager import StorageManager

# the exception for the installation
class InstallationException(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

    def getValue(self):
        return self.value

# the default workload standard installer
class DatabaseForSystemWorkload():
    def __init__(self, inst_name, db_name, logger = None):
        # self.logger
        if logger is None:
            logging.basicConfig(level = logging.DEBUG, format = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                datefmt = '%a, %d %b %Y %H:%M:%S')
            self.logger = logging.getLogger()
        else:
            self.logger = logger

        # instance info
        self.inst_name = inst_name

        # the db info
        self.db_name = db_name

        self.db_parms = None
        # get the sql type
        args = [self.inst_name]
        rc = util.trace_shell_func_call('check_sqltype', *args)
        if rc == 0:
            self.inst_sqltype = 'ORACLE'
        else:
            self.inst_sqltype = 'DB2'

        #support the multiple databases in one deployment
        self.vmTemplateID = util.getRoleName() #maestro.node['id'][:maestro.node['id'].rindex('.')]
        self.jsonFileName = '%s_%s_instance_profile.json' % (self.vmTemplateID, self.inst_name)
        self.PROFILE_LOCK = '%s_instance_profile.lck' % self.inst_name

        # script path and dbaas path
        self.shell_script = os.path.normpath(os.path.join(os.path.split(os.path.realpath(__file__))[0], os.path.pardir, 'shell'))
        self.dbaasdir = '/dbaas'

        if not os.path.exists(self.dbaasdir):
            os.makedirs(self.dbaasdir)
            os.chmod(self.dbaasdir, 0777)

        self.logger.debug(self.shell_script)

        self.logger.debug('=========init %s instance_profile.json================' % self.db_name)
        self.profileName = os.path.join(self.dbaasdir, self.jsonFileName)

        if 'DEPLOYMENT_URL' in os.environ:
            self.remote_profile_url = os.path.join(os.environ['DEPLOYMENT_URL'], 'instances', self.jsonFileName)

        self.storehouseUtil = StorehouseUtil(self.profileName, self.remote_profile_url)

        nls.install()

        self.downloadProfile()

    # Download dbaas inst_profile_content from storehouse
    def downloadProfile(self):
        self.inst_profile_content = self.storehouseUtil.download()

    # Upload the inst_profile_content to storehouse
    def uploadProfile(self):
        self.storehouseUtil.generate(self.inst_profile_content)

    def getDatabaseProfile(self):
        if self.inst_profile_content.has_key('databases'):
            for database_profile in self.inst_profile_content['databases']:
                if self.db_name == database_profile['databaseName']:
                    return database_profile
            return {}
        else:
            return {}

    def updateDatabaseProfile(self, updateDict):
        database_profile = self.getDatabaseProfile()
        if isinstance(updateDict, dict):
            database_profile.update(updateDict)
            self.uploadProfile()

    # Delete the inst_profile_content from storehouse
    def deleteRemoteProfile(self):
        self.storehouseUtil.delete()

    # delete the inst_profile_content from the local disk
    def deleteProfile(self):
        if os.path.exists(self.profileName):
            os.remove(self.profileName)

    def getDirectory(self):
        return self.inst_profile_content

    def putDict(self, value):
        self.inst_profile_content.update(value)

    def change_backup_frequency(self, frqcy, dateparams = '', timeparams = '', weekday = ''):
        role_name = maestro.role['name']
        util.startCrontab()
        if frqcy == "off":
            rc = util.trace_shell_func_call('delete_backup_schedule', self.inst_name, self.db_name, role_name)
        else:
            rc = util.trace_shell_func_call('chk_if_tsm_client_configured')
            if rc != 0:
                msg = "DB2 database is not configured as TSM Archive. Changing the frequency of automatic scheduled backup is not supported in this way!"
                return False, msg
            
            year = dateparams[:4]
            month = dateparams[4:6]
            day = dateparams[-2:]
            hour = timeparams.split(":")[0]
            minute = timeparams.split(":")[1]
            # Turn on or turn off the auto-scheduled backup accordingly
            rc = util.trace_shell_func_call('create_backup_schedule', frqcy, self.inst_name, self.db_name, role_name, year, month, day, hour, minute, weekday)
        if rc == 0:
            if frqcy == "off":
                timestampparams = None
            else:
                dateC = datetime.datetime(int(year),int(month),int(day),int(hour),int(minute),00)
                timestampparams = time.mktime(dateC.timetuple()) * 1000
            self.updateDatabaseProfile({'frequency': frqcy, 'timestamp': timestampparams})
            msg = "Changed the frequency of automatic scheduled database backup to %s" % (frqcy)
            result = True
        else:
            #Failed to update the frqcy of auto-scheduled backup to %s, Exit code 1. TSM Server is not configured...
            msg = "Failed to update the frequency of automatic scheduled database backup to %s" % (frqcy)
            result = False

        if self.isStandby():
            msg = "This is standby, auto-scheduled backup job is trigger, but no database image will be created."

        return result, msg

    def backup(self, image_request = 'M', image_name = '', image_desc = ''):
        if self.isStandby():
            return True, "This is standby, no backup job is trigger."
        else:
            if image_request == 'B':
                out_file = os.path.join(self.dbaasdir, 'backup.baseline.%s' % self.db_name)
            else:
                pid = str(os.getpid())
                out_file = os.path.join(self.dbaasdir, 'backup.%s' % pid)

            try:
                if image_request == 'B':
                    self.logger.info(nls.msg('1050I'))  # NLS
                    image_flag = 'F'  # full offline
                    image_name = ''  # nls.msg('1090I', db_name)  # NLS
                    if image_name == '':
                        image_name = "Baseline database image '%s'" % self.db_name
                    image_desc = ''  # nls.msg('1091I')  ## NLS
                    if image_desc == '':
                        image_desc = 'Initial database image created during deployment'
                elif image_request == 'A':
                    self.logger.info(nls.msg('1051I'))  # NLS
                    image_flag = 'N'  # full online
                    image_name = ''  # nls.msg('1092I', db_name)  ## NLS
                    if image_name == '':
                        image_name = "System-created image '%s'" % self.db_name

                    image_desc = ''  # nls.msg('1093I')  ## NLS
                    if image_desc == '':
                        image_desc = "This database image is created by the DBaaS scheduler automatically"
                elif image_request == 'M':
                    msg_str = nls.msg('1051I')
                    if msg_str == '':
                        msg_str = "Creating a full online database image"

                    self.logger.info(msg_str)  # NLS
                    image_flag = 'N'  # full online
                else:
                    self.logger.debug('Invalid value for parameter image_request %s' % (image_request))
                    rc = False
                    msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg('0004N', '201'))  # NLS
                    self.logger.error(msg)
                    return [rc, msg]
                self.logger.debug("image_request: %s, image_flag: %s" % (image_request, image_flag))

                if not image_name:
                    self.logger.debug('Parameter image_name is not set')
                    rc = False
                    msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg('0004N', '202'))  # NLS
                    self.logger.error(msg)
                    return [rc, msg]
                self.logger.debug("image_name: %s" % image_name)
                self.logger.debug("image_desc: %s" % image_desc)

                deployment_id = os.environ['DEPLOYMENT_URL'].split('/')[-1]
                role_name = maestro.role['name']

                # Set parameters for backup script
                backup_sh = [os.path.join(self.shell_script, 'backup_db.sh')]
                backup_sh.extend(['-i', self.inst_name])
                backup_sh.extend(['-v', self.vmTemplateID])
                backup_sh.extend(['-d', self.db_name])
                backup_sh.extend(['-t', image_request])
                backup_sh.extend(['-g', image_flag])
                backup_sh.extend(['-n', image_name.encode('utf-8', 'ignore')])
                backup_sh.extend(['-s', image_desc.encode('utf-8', 'ignore')])
                backup_sh.extend(['-p', deployment_id])
                backup_sh.extend(['-r', role_name])
                backup_sh.extend(['-o', out_file])
                self.logger.debug(backup_sh)

                # Call backup script
                call_rc = maestro.trace_call(self.logger, backup_sh)
                f = file(out_file, 'r')
                if call_rc == 0:
                    rc = True
                    timestamp = eval(f.read())
                    f.close()
                    msg = nls.msg('1080I', self.db_name, *timestamp)  # NLS
                    msg = "Succeed in creating image %s" % image_name
                    self.logger.info(msg)
                    return [rc, msg]
                else:
                    rc = False
                    db2_error, dbaas_error = eval(f.read())
                    f.close()
                    if db2_error[0] and db2_error[1]:
                        msg = '%s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0003N', rc, *db2_error))
                    elif db2_error[0]:
                        msg = '%s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0002N', rc, db2_error[0]))
                    elif dbaas_error[0]:
                        if nls.msg(*dbaas_error):
                            msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg(*dbaas_error))
                        else:
                            msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg('0004N', dbaas_error[0]))
                    else:
                        msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg('0004N', '291'))
                    self.logger.error(msg)

                    msg = "Fail to create image %s" % image_name
                    return [rc, msg]
            except Exception as e:
                self.logger.debug("Exception caught")
                self.logger.debug(e)
                rc = False
                msg = '%s. %s. %s' % (nls.msg('1101N', self.db_name), nls.msg('0001N', rc), nls.msg('0004N', '299'))
                self.logger.error(msg)
                return [rc, msg]
            finally:
                if image_request == 'B':
                    #if it is baseline backup, keep the tmp file for timestamp
                    pass
                else:
                    # Remove temporary file
                    if os.path.exists(out_file):
                        os.remove(out_file)

    def isHADREnabled(self):
        keyList = ['enableHADR', 'customizedEnableHADR', 'cloneHADREnable', 'hadrProfileName']
        if self.db_parms == None:
            self.db_parms = self.getDatabaseProfile()
        for key_item in keyList:
            if key_item in self.db_parms and self.db_parms[key_item]:
                return self.db_parms[key_item]
        return False

    def isHADRPrimary(self):
        if self.isHADREnabled():
            if 'initialHADRRole' in self.db_parms:
                return self.db_parms['initialHADRRole'] == 'PRIMARY'
        return False

    def isHADRStandby(self):
        if self.isHADREnabled():
            if 'initialHADRRole' in self.db_parms:
                return self.db_parms['initialHADRRole'] == 'STANDBY'
        return False

    @util.performance_profile_trace
    def install(self, workload_exec_dir, db_parms):
        self.logger.debug('create the database: : start')
        # self.logger.info(nls.gen_usr_msg(self.install_start_msg, workload_name))

        # the parameters for database
        self.db_parms = db_parms
        self.workload_exec_dir = workload_exec_dir

        if self.db_parms is None:
           raise InstallationException('Failed to create DB!')

        rc = 0
        try:
            self.printInputParms()

            self.validateTSMNode()

            self.preCreateDatabase()

            self.prepareDefaultUser(self.defaultUser, self.defaultUser_password)

            self.tuneInstance()

            self.prepareDisk()
            if not self.isHADRStandby():
                try:
                    self.createDatabase()
                except Exception as e:
                    self.logger.error(repr(e))
                    raise InstallationException('Failed to create DB!')

                self.post_create_db()

                self.tuneDatabase()

                self.initDatabase()

                self.executeSqlForUser()

                self.cleanupTemporaryFiles()

            if not self.isHADREnabled():
                self.configureTSMForDatabase()
                self.createBaselineBackup()
                # self.configureBackupScheduler()

            self.registerDatabase(self.db_parms)

            self.complete(True)
        except InstallationException as e:
            rc = 1
            self.logger.debug(e.getValue())
            self.complete(False)
        except:
            rc = 1
            self.logger.exception("create database error:")
            traceback.print_exc()
            self.complete(False)
        finally:
            self.logger.debug('create the database :  end')
            return rc

    @util.performance_profile_trace
    def validateTSMNode(self):
        if 'isTSMEnabled' in self.inst_profile_content and self.inst_profile_content['isTSMEnabled'] is True:
            self.logger.debug('isTSMEnabled: %s' % self.inst_profile_content['isTSMEnabled'])
            self.is_tsm_enabled = True
            tsm_node_name = self.inst_profile_content['tsm']['nodeName']
            tsm_admin_password = maestro.decode(self.inst_profile_content['tsm']['adminpassword'])
            tsm_admin_name = self.inst_profile_content['tsm']['adminusername']
            rc = util.trace_shell_func_call('query_tsm_node', tsm_admin_name, tsm_admin_password, tsm_node_name, echo_stdin = False)
            if rc != 0:
                self.logger.error('validateTSMNode: Fail')
                raise InstallationException('Failed to query TSM for database')

        else:
            self.is_tsm_enabled = False

    @util.performance_profile_trace
    def prepareDisk(self):
        diskSizeinKSize = 0
        if 'dataMountPoint' in self.db_parms:
            self.data_mount_point = self.db_parms['dataMountPoint']
            data_path_list = self.data_mount_point.split(',')

            for data_path in data_path_list:
                if not os.path.ismount(data_path):
                    raise InstallationException("The mount point path: '%s' does not exist" % data_path)

                args = ['/home/%s/sqllib' % (self.inst_name), data_path]
                rc = util.trace_shell_func_call('clone_dir_owner', *args)
                self.logger.debug('clone_dir_owner: %s' % rc)
        else:
            self.data_mount_point = "/home/%s" % self.inst_name

        data_path_list = self.data_mount_point.split(',')
        for data_path in data_path_list:
            disk = util.trace_shell_func_call_with_output('get_disk_size', data_path)
            diskSizeinKSize += float(disk)
        diskSize = int(round(diskSizeinKSize / 1024 / 1024)) #self.diskSize  is in Gagabyte
        self.db_parms['diskSize'] = diskSize

    def printInputParms(self):
        # print db_parms details to log
        db_parms_dump = copy.copy(self.db_parms)
        password_list = ['fencedUserPassword', 'instanceOwnerPassword', 'databaseUserPassword',
        'cloneDatabaseUserPassword', 'customizedDatabaseUserPassword']

        for key, val in db_parms_dump.iteritems():
            if key in password_list:
                db_parms_dump[key] = '*********'
        self.logger.debug(json.dumps(db_parms_dump, sort_keys = True, indent = 4))

    @util.performance_profile_trace
    def preCreateDatabase(self):
        self.install_start_msg = "DBAAS_PROVISION_WORKLOAD_PREDEFINED_START"  # workload name
        self.install_success_msg = "DBAAS_PROVISION_WORKLOAD_SUCCESS"
        self.install_fail_msg = "DBAAS_PROVISION_WORKLOAD_FAIL"
        # workload name
        self.source = 'defaultWorkloadStandardApproach'
        self.isSystem = 'True'

        create_db_script = os.path.join(self.workload_exec_dir, 'create_db', 'create_db.sh')
        if not os.path.exists(create_db_script):
            raise InstallationException('Failed to find the create_db.sh under create_db directory under %s ' % self.workload_exec_dir)

        # Change permission for workload dir
        if self.workload_exec_dir:
            util.trace_shell_func_call('fix_workload', self.workload_exec_dir)

        # the default user name and password
        self.defaultUser = ''
        if 'databaseUser' in self.db_parms:
            self.defaultUser = self.db_parms['databaseUser']

        self.defaultUser_password = ''
        if 'databaseUserPassword' in self.db_parms:
            self.defaultUser_password = maestro.decode(self.db_parms['databaseUserPassword'])


    @util.performance_profile_trace
    def tuneInstance(self):
        script = os.path.join(self.workload_exec_dir, 'tune_inst', 'tune_inst.sh')
        args = [script, self.inst_name]
        util.trace_call(self.logger, *args, notfound_ignore = 1, user = self.inst_name)

    @util.performance_profile_trace
    def prepareDefaultUser(self, userName, user_password):
        user_agent = UserGroupManager(self.jsonFileName, self.logger, self.db_name)
        sysadm_group_name = user_agent.getPermissionGroupName('SYSADM')
        #===========Code changes for RFE 128497==============#
        if 'sysControlGroupName' in self.db_parms:
            sysctrl_group_name=self.db_parms['sysControlGroupName']
            
        else:
            sysctrl_group_name="g_sysctl"
        if 'sysMaintGroupName' in self.db_parms:
            sysmnt_group_name=self.db_parms['sysMaintGroupName']
            
        else:
             sysmnt_group_name="g_sysmnt"
        if 'sysMonGroupName' in self.db_parms:
            sysmon_group_name=self.db_parms['sysMonGroupName']
            
        else:
            sysmon_group_name="g_sysmon" 
        #===========Code changes for RFE 128497 Ends==============#
        self.logger.debug('sysctrl_group_name %s:' %sysctrl_group_name)
        self.logger.debug('sysmnt_group_name %s:' %sysmnt_group_name)
        self.logger.debug('sysadm_group_name %s:' %sysadm_group_name)
        if  sysctrl_group_name != "" and sysmnt_group_name!= "":
            groupsval = [sysadm_group_name, sysctrl_group_name, sysmnt_group_name]
            permissionval = ['SYSADM', 'SYSCTRL', 'SYSMAINT']
        elif sysctrl_group_name != "" and sysmnt_group_name == "":
            groupsval = [sysadm_group_name, sysctrl_group_name]
            permissionval = ['SYSADM', 'SYSCTRL']
        elif sysctrl_group_name == "" and sysmnt_group_name != "":
            groupsval = [sysadm_group_name,sysmnt_group_name]
            permissionval = ['SYSADM','SYSMAINT']    
        elif sysctrl_group_name == "" and sysmnt_group_name == "":
            groupsval = [sysadm_group_name]
            permissionval = ['SYSADM']
        dbOwner = DB2User(userName = userName, \
                          password = user_password, \
                          groups = groupsval, \
                          permission = permissionval, \
                          description = "default database owner", \
                          sshAccess = True, \
                          isInstanceAdmin = False, \
                          isDatabaseAdmin = True, \
                          instanceName = self.inst_name)

        user_agent.addUser(dbOwner)

    @util.performance_profile_trace
    def createDatabase(self):
        # self.logger.info(nls.msg('1010I'))
        if 'databaseTerritory' in self.db_parms:
            inst_territory = self.db_parms['databaseTerritory'].upper()
        else:
            inst_territory = 'US'

        if 'databaseCodeset' in self.db_parms:
            inst_codeset = self.db_parms['databaseCodeset'].upper()
        else:
            inst_codeset = 'UTF-8'

        if 'databaseCollate' in self.db_parms:
            inst_collate = self.db_parms['databaseCollate'].upper()
        else:
            inst_collate = 'SYSTEM'

        if 'databasePageSize' in self.db_parms:
            page_size = self.db_parms['databasePageSize']
        else:
            page_size = 8

        script = os.path.join(self.workload_exec_dir, 'create_db', 'create_db.sh')

        args = [script, self.inst_name, self.db_name, self.inst_sqltype, inst_codeset, inst_territory, inst_collate, page_size, self.data_mount_point]
        self.logger.debug('create db command "%s"' % args)
        rc = util.trace_call(self.logger, *args, user = self.inst_name)
        self.logger.debug('create database result is: %s' % rc)

    @util.performance_profile_trace
    def post_create_db(self):
        script = os.path.join(self.shell_script, 'post_create_db.sh')

        trackmod = 'ON'
        num_db_backups = '32767'
        rec_his_retentn = '0'
        auto_del_rec_obj = 'OFF'
        args = [script]
        args.extend(['db_name=%s' % self.db_name])
        args.extend(['inst_name=%s' % self.inst_name])
        args.extend(['databaseUser=%s' % self.defaultUser])
        if self.is_tsm_enabled:
            args.extend(['tsm_enabled=true'])
        else:
            args.extend(['tsm_enabled=false'])

        args.extend(['trackmod=%s' % trackmod])
        args.extend(['num_db_backups=%s' % num_db_backups])
        args.extend(['rec_his_retentn=%s' % rec_his_retentn])
        args.extend(['auto_del_rec_obj=%s' % auto_del_rec_obj])

        rc = util.trace_call(self.logger, *args)
        if rc != 0:
            raise InstallationException('Failed to execute set_db_privilege.sh')

    @util.performance_profile_trace
    def tuneDatabase(self):
        script = os.path.join(self.workload_exec_dir, 'tune_db', 'tune_db.sh')
        args = [script, self.inst_name, self.db_name, self.defaultUser, self.defaultUser_password]
        self.logger.debug('command is: %s ******' % ' '.join(args[0:-1]))
        util.trace_call(self.logger, *args, notfound_ignore = 1, user = self.inst_name, echo_stdin = False)

    @util.performance_profile_trace
    def initDatabase(self):
        script = os.path.join(self.workload_exec_dir, 'init_db', 'init_db.sh')
        args = [script, self.inst_name, self.db_name, self.defaultUser, self.defaultUser_password]
        self.logger.debug('command is: %s ******' % ' '.join(args[0:-1]))
        util.trace_call(self.logger, *args, notfound_ignore = 1, user = self.inst_name, echo_stdin = False)

    @util.performance_profile_trace
    def executeSqlForUser(self):
        if 'databaseSQLFile' in self.db_parms:
            sql_url = self.db_parms['databaseSQLFile']
            sqlFile = os.path.join(self.dbaasdir, sql_url.rsplit('/')[-1])
            maestro.download(sql_url, sqlFile)
            rc = self.executeLocalSql(sqlFile)

            if rc != 0:
                raise InstallationException('failed to execute sql for user')
            os.remove(sqlFile)

    # Execute the local sql file as the defaultUser
    @util.performance_profile_trace
    def executeLocalSql(self, sqlFile):
        sql_log_file = '%s.log' % sqlFile
        self.logger.debug('sql file is %s, result will be logged at %s' % (sqlFile, sql_log_file))

        args = [self.inst_name, self.db_name]
        args.extend([self.defaultUser, self.defaultUser_password, sqlFile, sql_log_file, '1'])
        rc = util.trace_shell_func_call('load_sqlfile_for_%s' % self.inst_sqltype.lower(), *args, echo_stdin = False)
        return rc

    @util.performance_profile_trace
    def configureTSMForDatabase(self):
        # self.inst_profile_content.putDict({"frequency":frequency})
        if self.is_tsm_enabled:
            # read the TSM server info from instance profile
            tsm_node_name = ''
            tsm_node_password = ''

            tsm_node_name = self.inst_profile_content['tsm']['nodeName']
            tsm_node_password = maestro.decode(self.inst_profile_content['tsm']['nodePassword'])

            args = [self.inst_name, self.db_name, tsm_node_name, tsm_node_password]
            rc = util.trace_shell_func_call('config_database_for_tsm', *args, echo_stdin = False)
            rc2 = util.trace_shell_func_call('config_database_as_tsm_archive', *[self.inst_name, self.db_name])
            if (rc or rc2) != 0:
                self.logger.error('Failed to configure TSM for database')
                raise InstallationException('Failed to configure TSM for database')

    # Perform DB2 database backup when TSM is configured
    @util.performance_profile_trace
    def createBaselineBackup(self):
        if self.is_tsm_enabled:
            func_agent_sh = os.path.join(self.shell_script, 'func_agent.sh')
            args = [self.db_name]
            rc = util.trace_call(self.logger, func_agent_sh, 'backup_to_null', *args, user = self.inst_name)
            if rc != 0:
                raise InstallationException("Failed to create baseline database image")

    # Perform DB2 database backup when TSM is configured
    @util.performance_profile_trace
    def configureBackupScheduler(self):
        if self.is_tsm_enabled:
            frequency = "off"
            change_backup_sh = os.path.join(self.shell_script, 'change_backup.sh')

            # Turn on the auto-scheduled backup accordingly
            rc = maestro.trace_call(self.logger, [change_backup_sh, frequency])

            if rc == 0:
                msg = "Changed the frequency of automatic scheduled database backup to %s" % (frequency)
            else:
                #Failed to update the frqcy of auto-scheduled backup to %s, Exit code 1. TSM Server is not configured...
                msg = "Failed to update the frequency of automatic scheduled database backup to %s" % (frequency)
            self.logger.debug(msg)

    # Export DB info for WAS or other dependency
    @util.performance_profile_trace
    def exportEnv(self, db_parms, hadr = 'false', hadr_role = ''):
        self.logger.debug('Exporting DB info for WAS and other dependency')
        parms = {}
        parms['database_name'] = db_parms['databaseName']
        parms['database_user'] = db_parms['databaseUser']
        parms['database_user_password'] = maestro.encode(db_parms['databaseUserPassword'])
        parms['HADR'] = hadr
        parms['HADR_ROLE'] = hadr_role.upper()

        opt_parms = {}
        opt_parms['parameters'] = parms
        opt_parms['script'] = 'export_database.py'

        deployment = maestro._get_deployment_doc()
        master_ip = deployment['instances'][deployment['roles']['master']['node']]['private-ip']
        maestro.operationUtil.invoke_operation(opt_parms, target_role_type = 'abstractDB2', target_ip = maestro.node['instance']['public-ip'], deployment_id = maestro.node['deployment.id'], ip = master_ip)

    #  cleanup the tempory files in the preCreateDatabase phase
    @util.performance_profile_trace
    def cleanupTemporaryFiles(self):
        pass

    @util.performance_profile_trace
    def isTextSearchEnabled(self):
        return os.path.exists('/home/%s/sqllib/db2tss/config/config.xml' % self.inst_name)

    @util.performance_profile_trace
    def is_database_exist(self):
        args = [self.inst_name, self.db_name]
        rc = util.trace_shell_func_call('chk_if_database_exist', *args)
        if rc == 0:
            return True
        else:
            self.logger.debug('Failed to find the database %s' % self.db_name)
            return False

    @util.performance_profile_trace
    def registerDatabase(self, db_parms, cust_parameter_map = None):
        #check whether database exists
        if not self.isHADRStandby() and not self.is_database_exist():
            raise InstallationException('Failed to find the database %s' % self.db_name)

        #Register the user info into the profile
        if 'databaseUser' in db_parms:
            user_agent = UserGroupManager(self.jsonFileName, self.logger, self.db_name)
            existing_user = user_agent.getUserByName(db_parms['databaseUser'])
            if existing_user is None or not existing_user.hasConsumer(self.db_name):
                self.logger.debug('user is not in the profile')
                self.prepareDefaultUser(db_parms['databaseUser'], maestro.decode(db_parms['databaseUserPassword']))

        #Register the db info into the profile
        self.downloadProfile()

        db_profile = self.getDatabaseProfile()
        frequency = 'off'

        db_profile.update({
            "databaseName": self.db_name,
            "textSearchEnabled": self.isTextSearchEnabled(),
            "frequency": frequency
            })

        if db_parms:
            db_profile.update({
                "databaseUser": db_parms['databaseUser'] if 'databaseUser' in db_parms else "",
                "description": db_parms['description'] if 'description' in db_parms else "",
                "diskSize": db_parms['diskSize'],
                "dataMountPoint": db_parms['dataMountPoint']
            })

        if cust_parameter_map:
            db_profile.update(cust_parameter_map)

        self.inst_profile_content['databases'].append(db_profile)

        self.uploadProfile()

        if not self.isHADREnabled():
           self.exportEnv(db_parms)

    # complete to install database
    @util.performance_profile_trace
    def complete(self, status):
#         if status == True:
#             self.logger.info(nls.gen_usr_msg(self.install_success_msg))
#         else:
#             self.logger.info(nls.gen_usr_msg(self.install_fail_msg))
#       self.logger.info(nls.msg(status))
        self.logger.debug('complete')

    def add_new_dbpath(self, db_path):
        self.logger.debug('Begin to add new dbpath for db %s' % self.db_name)
        args = []
        args.extend([self.inst_name])
        args.extend([self.db_name])
        args.extend([db_path])
        rc = util.trace_shell_func_call('add_new_dbpath', *args)
        self.logger.debug('End to add new dbpath for db %s' % self.db_name)
        return rc

    def getMountPointSize(self, mount_point):
        int_size_g = 0
        size_g = util.trace_shell_func_call_with_output('get_mount_point_size', mount_point)
        try:
            f_size_g = float(size_g)
            int_size_g = int(f_size_g)
        except ValueError as ve:
            raise InstallationException('Failed to get mount point size because following error: %s' % repr(ve))
        return int_size_g

    def isMPCreatedOnStandby(self, data_mount_point):
        rc = 0
        if self.isHADREnabled():
            if not self.isStandby():
                from DB2_Instance import DB2_Instance
                inst = DB2_Instance(self.inst_name)
                hadr_manager_list = inst.getHADRManagerList()
                hadr_manager = hadr_manager_list[self.db_name.upper()]
                standby_node_info = hadr_manager.getCounterpartNodeInfo()
                remote_private_ip = standby_node_info.privateIP
                if remote_private_ip != '':
                    self.logger.debug("Checking from primary if mount point %s is already exist on standby" % data_mount_point)
                    rc = util.trace_shell_func_call('chk_standby_mp_from_primary', remote_private_ip, data_mount_point)
                else:
                    raise InstallationException("Error: unable to get standby private IP address!")
        else:
            rc = -1 # Bypass DB2 stand alone
        return rc

    def storageMountPointSelector(self, db_profile, delta=0):
        THRESHORD = 1800 #1.8T
        isExceed1800G = False
        data_mount_point = ''
        
        if 'dataMountPoint' in db_profile:
            valid_data_mount_point_list = []
            data_path_list = db_profile['dataMountPoint'].split(',')
            if len(data_path_list) < 1:
                return None
            for data_path in data_path_list:
                if not os.path.ismount(data_path):
                    self.logger.debug("The mount point path: '%s' does not exist" % data_path)
                else:
                    self.logger.debug("User input a valid data mount point: %s" % data_path)
                    valid_data_mount_point_list.append(data_path)
   
        # work around maximum 1.8TB limitation on Linux
        if platform.system() == 'Linux':
            if len(valid_data_mount_point_list) > 0:
                for i in range(len(valid_data_mount_point_list)):
                    temp_mp = valid_data_mount_point_list[i]
                    self.logger.debug("validating the additional mount point %s" % temp_mp)
                    # validate if the next mount point volume have sufficient disk space
                    nx_mp_size = self.getMountPointSize(temp_mp)
                    if (nx_mp_size + delta) > THRESHORD:
                        # If the first mount point is reached 1.8T size limitation, will add storage on the next mount point \
                        if i < len(valid_data_mount_point_list)-1:
                            # Looking for next bigger mount point
                            continue
                        # if the next one dose not exist, DBaaS will generate a new mount point
                        else:
                            isExceed1800G = True
                            self.logger.debug("Warning: Reached the maximum storage size 1.8T in a single VMFS mount point, a new mount point will be generated by DBaaS")
                            # Generate a new mount point
                            j = 1
                            while True:
                                chk_path= '/db2_storage_%s_%s_%s' % (self.inst_name, self.db_name, j)
                                if not os.path.ismount(chk_path):
                                    data_mount_point = chk_path
                                    break
                                else:
                                    j += 1
                    else:
                        data_mount_point = temp_mp
                        break
            else:
                return False, None
        elif platform.system() == 'AIX':
            if len(valid_data_mount_point_list) > 0:
                # Always growth the first valid mount point as db path if more than one mount points exist
                data_mount_point = valid_data_mount_point_list[0]
            else:
                return False, None
                
        self.logger.debug("A valid mount point %s is selected" % data_mount_point)
        return isExceed1800G, data_mount_point

    # Scale up a single node
    @util.performance_profile_trace
    def scaleupStorage(self, delta_disk_size):
        self.logger.debug('Begin to scale up database storage size')
        isNewMPCreated = False
        db_profile = self.getDatabaseProfile()
        original_disk_size = int(db_profile['diskSize'])
        target_disk_size = int(delta_disk_size) + original_disk_size

        self.logger.debug("Original disk size = %s" % original_disk_size)
        self.logger.debug("New adding disk size = %s" % delta_disk_size)
        self.logger.debug("Add to disk size = %s" % target_disk_size)

        data_mount_point = ''
        if 'dataMountPoint' in db_profile:
            isNewMPCreated, data_mount_point = self.storageMountPointSelector(db_profile, int(delta_disk_size))
            if data_mount_point == None:
                resultMessage = 'Failed to add database storage because none of a valid mount point exist'
                return False, resultMessage
            elif isNewMPCreated and data_mount_point != '':
                # Make sure add storage operation was executed from Standby node first
                if self.isMPCreatedOnStandby(data_mount_point) > 0:
                    resultMessage = 'Failed to add database storage, please make sure this operation has been executed from HADR standby node first'
                    return False, resultMessage
        else:
            resultMessage = 'Failed to add database storage because db profile dose not has key \'dataMountPoint\''
            return False, resultMessage

        # start scale up process
        storage_manager = StorageManager(data_mount_point, self.inst_name, self.inst_profile_content['osType'])
        
        rc, resultMessage = storage_manager.doScaleNodeStorage(int(delta_disk_size))
        self.logger.debug(resultMessage)
        if rc == 0 and delta_disk_size > 0:
            db_profile['diskSize'] = target_disk_size
            #Save the new generated mount point
            if isNewMPCreated:
                mt = storage_manager.getMountPoint()
                db_profile['dataMountPoint'] = db_profile['dataMountPoint'] + ',' +  mt
                self.logger.debug('New data mount point is %s' % db_profile['dataMountPoint'])
                # Update db path in db cfg
                self.logger.debug('Update db cfg for new db path')
                self.add_new_dbpath(mt)
                self.logger.debug("Adding new mount point %s to instance profile" % mt)
            self.updateDatabaseProfile(db_profile)
            self.logger.debug('Succeed to update database storage size in database profile in Storehouse')
            resultMessage = 'Succeed to add database storage'
        else:
            resultMessage = 'Failed to add database storage'

        self.logger.debug('End to scale up database storage size')

        if rc == 0:
            return True, resultMessage
        else:
            return False, resultMessage

    def isStandby(self):
        argv = [self.inst_name, self.db_name]
        isStandby = (util.trace_shell_func_call('check_hadr_db_standby_role', *argv))
        if isStandby == 0:
            return True
        else:
            return False

    @util.performance_profile_trace
    def startHADR(self, isPrimary = True):
        self.logger.debug("startHADR begin")
        if isPrimary:
            rc = util.trace_shell_func_call('start_hadr_primary_db', self.inst_name, self.db_name)
        else:
            rc = util.trace_shell_func_call('start_hadr_standby_db', self.inst_name, self.db_name)
        self.logger.debug("rc = %d" % rc)
        self.logger.debug("startHADR end")

    @util.performance_profile_trace
    def stopHADR(self):
        self.logger.debug('Start to stop HADR')
        if self.isStandby():
            rc = util.trace_shell_func_call('deactivate_db', self.inst_name, self.db_name)
            self.logger.debug("rc = %d" % rc)
        rc = util.trace_shell_func_call('stop_hadr_db', self.inst_name, self.db_name)
        self.logger.debug("rc = %d" % rc)
        self.logger.debug('Succeed to stop HADR')
