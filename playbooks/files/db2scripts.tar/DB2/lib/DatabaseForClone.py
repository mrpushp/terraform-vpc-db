#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import os
import util
import maestro
import subprocess
import random

from DatabaseForSystemWorkload import DatabaseForSystemWorkload

class DatabaseForClone(DatabaseForSystemWorkload):

    def __init__(self, inst_name, db_name, logger = None):
        DatabaseForSystemWorkload.__init__(self, inst_name, db_name, logger)
        self.install_start_msg = "DBAAS_CLONE_START"
        self.install_success_msg = "DBAAS_CLONE_SUCCESS"
        self.install_fail_msg = "DBAAS_CLONE_FAIL"

    #download the image
    @util.performance_profile_trace
    def preCreateDatabase(self):
        self.source = 'cloneApproach'

        # https://localhost:9443/services/plugins/pattern.db2/1.2.m.f/extensions/resources/db2/images
        ks_url = '%sservices' % maestro.node['ks-url']
        clone_meta_url = '%s/plugins/pattern.db2/1.2.12.0/extensions/resources/db2/images/%s' % (ks_url, self.db_parms['databaseImage'])

        # read the json file from the SH
        tmpdir = '/tmp'
        try:
            self.clone_meta_json_content = util.read_Json_FromStoreHouse(clone_meta_url, tmpdir)
        except Exception as e:
            self.logger.error(repr(e))
            raise Exception('Cannot get image file from ' + clone_meta_url)

        # get the current db2 level
        self.sqlType = self.clone_meta_json_content['sqlType']

        # the default user name and password
        self.defaultUser = ''
        if 'databaseUser' in self.db_parms:
            self.defaultUser = self.db_parms['databaseUser']
        else:
            if self.clone_meta_json_content.has_key('databaseUser'):
                self.defaultUser = self.clone_meta_json_content['databaseUser']

        self.defaultUser_password = ''
        if 'databaseUserPassword' in self.db_parms:
            self.defaultUser_password = maestro.decode(self.db_parms['databaseUserPassword'])
        else:
            self.defaultUser_password = self.generateRandomPassword()

    @util.performance_profile_trace
    def restore_instance(self):
        # Clone instance level configuration
        # Instance configuration
        inst_cfg = self.clone_meta_json_content['instanceConfig'][0]
        # Instance registry
        inst_reg = self.clone_meta_json_content['registeredVariables'][0]

        # Current instance configuration
        func_agent_sh = os.path.join(self.shell_script, 'func_agent.sh')
        c_inst_cfg = eval('{ %s }' % subprocess.Popen([func_agent_sh, 'generate_instance_cfg_json', self.inst_name], stdout = subprocess.PIPE).communicate()[0].replace('\n', ''))

        # Current instance registry
        c_inst_reg = eval('{ %s }' % subprocess.Popen([func_agent_sh, 'generate_instance_registry_json', self.inst_name], stdout = subprocess.PIPE).communicate()[0].replace('\n', ''))

        # Get real keys and values
        inst_cfg = util.strip_cfg(inst_cfg)
        inst_reg = util.strip_cfg(inst_reg)
        c_inst_cfg = util.strip_cfg(c_inst_cfg)
        c_inst_reg = util.strip_cfg(c_inst_reg)

        # Compare and apply the differences
        args = []
        args.extend([self.inst_name])
        for key in c_inst_cfg:
            if inst_cfg.has_key(key):
                if key != 'COMM_BANDWIDTH' and key != 'CPUSPEED' and key != 'Cluster manager':
                    if inst_cfg[key] != c_inst_cfg[key]:
                        args.extend(['%s=%s' % (key, inst_cfg[key])])
        if args:
            util.trace_shell_func_call('config_instance', *args)

        args = []
        args.extend([self.inst_name])
        for key in inst_reg:
            if c_inst_reg.has_key(key):
                if inst_reg[key] == c_inst_reg[key]:
                    continue
            args.extend(['%s=%s' % (key, inst_reg[key])])
        if args:
            util.trace_shell_func_call('config_instance_registry', *args)

    #check whether there is backup in the TSM server
    #db2adutl query TAKEN AT ${image_timestamp} DB ${database_name} nodename bar  owner roecken password *******
    def create_user(self, user_name, user_password, group_name, ssh_access):
        self.logger.debug("%s %s %s" % (user_name, group_name, ssh_access))

        #Check if user already exist in the system
        rc = util.trace_shell_func_call('chk_if_user_exist', user_name)
        if rc != 0:
            # mapping authorization level to system groups
            from UserGroupManager import UserGroupManager
            from DB2User import DB2User
            user_agent = UserGroupManager(self.inst_profile_content, self.logger, self.inst_name)
            inst_user = DB2User(
                userName=user_name,
                password=user_password,
                groups=[group_name],
                permission=[ssh_access],
                description="",
                sshAccess=True,
                isInstanceAdmin=False,
                isDatabaseAdmin=False,
                instanceName=self.inst_name
            )
            user_agent.addUser(inst_user)
        else:
            self.logger.debug('user exist %s' % user_name)

    def generateRandomPassword(self):
        symbols0 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
        symbols1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        symbols2 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

        length0 = 2 + random.randint(0, 5)
        length1 = 4 + random.randint(0, 5)
        length2 = 4 + random.randint(0, 5)
        bufferStr = []

        # Add some numeric chars
        for idx in range(0, length0):
            ind = random.randint(0, 9)
            bufferStr.extend(symbols0[ind])

        # Add lower case chars   
        for idx in range(0, length1):
            bufferStr.extend(symbols1[random.randint(0, 25)])

        # Add upper case chars
        for idx in range(0, length2):
            bufferStr.extend(symbols2[random.randint(0, 25)])

        # Shuffle the characters a bit
        for i in [len(bufferStr) - 1, 0]:
            index = random.randint(0, i)
            temp = bufferStr[i]
            bufferStr[i] = bufferStr[index]
            bufferStr[index] = temp

        return ''.join(bufferStr)

    @util.performance_profile_trace
    def createDatabase(self):
        util.trace_shell_func_call('backup_dsm_sys')
        if 'tsm' in self.clone_meta_json_content and 'nodeName' in self.clone_meta_json_content['tsm']:
            tsm_node = self.clone_meta_json_content['tsm']['nodeName']
        elif 'tsmnodename' in self.clone_meta_json_content:
            tsm_node = self.clone_meta_json_content['tsmnodename']
        else:
            self.logger.error('Can not find the tsm node name in the image metadata file')

        if 'tsm' in self.clone_meta_json_content and 'nodePassword' in self.clone_meta_json_content['tsm']:
            nodePassword = maestro.decode(self.clone_meta_json_content['tsm']['nodePassword'])
        elif 'tsmserveradminpass' in self.clone_meta_json_content:
            nodePassword = maestro.decode(self.clone_meta_json_content['tsmserveradminpass'])
        else:
            self.logger.error('Can not find the tsm node password in the image metadata file')

        if 'backupMode' in self.clone_meta_json_content:
            backupmode = self.clone_meta_json_content['backupMode']
        else:
            backupmode = 'OFFLINE'

        util.trace_shell_func_call('replace_nodename_in_dsm_sys', tsm_node)
        util.trace_shell_func_call('config_instance_for_tsm', self.inst_name)

        vendoropt = "NULL"
        if 'Vendor options (VENDOROPT)' in self.clone_meta_json_content['databaseConfig'][0]:
            vendoropt = self.clone_meta_json_content['databaseConfig'][0].get('Vendor options (VENDOROPT)')

        script = os.path.join(self.shell_script, 'clone_db.sh')
        args = []
        args.extend([self.inst_name, self.db_name])
        args.extend([self.clone_meta_json_content['databaseName']])
        args.extend([tsm_node])
        args.extend([self.clone_meta_json_content['timestamp']])
        args.extend([nodePassword])
        args.extend([backupmode])
        args.extend([vendoropt])
        args.extend([self.data_mount_point])

        util.trace_call(self.logger, script, *args, user=self.inst_name, echo_stdin=False)

        util.trace_shell_func_call('restore_dsm_sys')


    @util.performance_profile_trace
    def restore_users(self):
        if 'users' in self.clone_meta_json_content:
            for username in self.clone_meta_json_content['users']:
                if username != "":
                    user_info = self.clone_meta_json_content['users'][username]
                    if user_info.has_key('authLevel'):
                        group_name = user_info['authLevel']
                    else:
                        group_name = []
                    self.create_user(username, self.generateRandomPassword(), group_name, user_info['sshAccess'])


    @util.performance_profile_trace
    def post_create_db(self):
        pass

    @util.performance_profile_trace
    def isTextSearchEnabled(self):
        if self.clone_meta_json_content.has_key('isTextSearchEnabled'):
            #Get value from image meta-data
            return self.clone_meta_json_content['isTextSearchEnabled']
        else:
            return False

    @util.performance_profile_trace
    def tuneDatabase(self):
        pass

    @util.performance_profile_trace
    def initDatabase(self):
        pass
