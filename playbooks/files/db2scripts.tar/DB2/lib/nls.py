#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
########################################
# DBS0000-DBS4999   i18n messages
# DBS5000-DBS9999   non-i18n messages
# *C                server messages
# *I                information messages
# *W                warning messages
# *N                error messages
# *E                urgent messages
########################################

import os
import gettext
#import maestro

scriptdir = '/tmp/db2scripts'

def install():
    #scriptdir = maestro.node['scriptdir']
    # Install global domain db2_message with default locale
    #gettext.install('db2_messages', os.path.join(scriptdir, 'locale'), unicode = True);
    gettext.install('db2_messages', os.path.join(scriptdir, 'locale'));

# foo(msg_id, tokens)
def msg(msg_id, *tokens):
    DBS0001N = _("ERROR_CODE") # error_code
    DBS0002N = _("ERROR_CODE_SQLCODE") # error_code, sqlcode
    DBS0003N = _("ERROR_CODE_SQLCODE_REASONCODE") # error_code, sqlcode, reason_code
    DBS0004N = _("ERROR_INTERNAL") # internal_error_code
    DBS0050I = _("LOG_VIEW_HELP")

    DBS0500I = _("Changing appuser password")
    DBS0501I = _("Changing appdba password")
    DBS0502I = _("Setup and start iptables")
    DBS0503I = _("CONFIG_AUTO_BACKUP")
    DBS0504I = _("CONFIG_AUTO_BACKUP_SUCCEED") # daily|weekly|off

    DBS1000I = _("DEPLOYMENT_CREATE_DB2_INSTANCE")
    DBS1001N = _("ERROR_PRE_CREATE_DB2_INSTANCE")
    DBS1002N = _("ERROR_CREATE_DB2_INSTANCE")
    DBS1003N = _("ERROR_CONFIGURE_DB2_INSTANCE")

    DBS1010I = _("DEPLOYMENT_CREATE_DB2_DATABASE")
    DBS1011N = _("ERROR_PRE_CREATE_DB2_DATABASE")
    DBS1012N = _("ERROR_CREATE_DB2_DATABASE")
    DBS1014N = _("ERROR_CONFIGURE_DB2_DATABASE_PRIVILEGES")
    DBS1015N = _("ERROR_CONFIGURE_DB2_DATABASE_OPTIM")
    DBS1016N = _("ERROR_CONFIGURE_DB2_DATABASE_ARCHIVE_LOG")

    DBS1020I = _("DBAAS_PROVISION_WORKLOAD_PREDEFINED_START") # workload name
    DBS1021I = _("DBAAS_PROVISION_WORKLOAD_CUSTOMIZED_START") # workload name
    DBS1022I = _("DBAAS_PROVISION_WORKLOAD_SUCCESS")
    DBS1023N = _("DBAAS_PROVISION_WORKLOAD_FAIL")

    DBS1030I = _("DBAAS_CLONE_START") # timestamp
    DBS1031I = _("DBAAS_CLONE_SUCCESS")
    DBS1032N = _("DBAAS_CLONE_FAIL")
    DBS1033N = _("DBAAS_CLONE_FAIL_NO_IMAGE")
    DBS1034W = _("DBAAS_CLONE_WARN_NO_IMAGE")

    DBS1050I = _("DEPLOYMENT_BACKUP_DB2_DATABASE_FULL_OFFLINE")
    DBS1051I = _("DEPLOYMENT_BACKUP_DB2_DATABASE_FULL_ONLINE")
    DBS1080I = _("DEPLOYMENT_BACKUP_DB2_DATABASE_SUCCEED") # db_name, timestamp
    DBS1090I = _("IMAGE_NAME_FOR_BASELINE_BACKUP") # db_name
    DBS1091I = _("IMAGE_DESC_FOR_BASELINE_BACKUP")
    DBS1092I = _("IMAGE_NAME_FOR_SCHEDULED_BACKUP") # db_name
    DBS1093I = _("IMAGE_DESC_FOR_SCHEDULED_BACKUP")
    DBS1101N = _("ERROR_BACKUP_DB2_DATABASE") # db_name
    DBS1102W = _("ERROR_TSM_CONFIGURED")
    DBS1103N = _("ERROR_REGISTER_TSM_NODE")
    DBS1104N = _("ERROR_CONFIGURE_DB2_DATABASE_TSM")
    DBS1105N = _("ERROR_SAVE_DATABASE_IMAGE_META")
    DBS1106N = _("ERROR_CONFIG_AUTO_BACKUP") # daily|weekly|off

    DBS1150I = _("DEPLOYMENT_RUN_USER_SCHEMA_FILE")
    DBS1151N = _("ERROR_RUN_USER_SCHEMA_FILE")

    try:
        msg = locals()['DBS%s' % msg_id] % (tokens)
    except Exception:
        msg = ''
    return msg

# foo([msg_id, tokens], [msg_id, tokens], ...)
def msgs(*args):
    value = ''
    for arg in args:
        msg_id = arg[0]
        del arg[0]
        msg_value = msg(msg_id, *arg)
        if value and msg_value:
            value += '. '
        value += msg_value
    return value
