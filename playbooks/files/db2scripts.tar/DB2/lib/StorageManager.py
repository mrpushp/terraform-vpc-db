#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import logging
import maestro
import util
import os
import json
import time

# the exception for the installation
class StorageManagerException(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return self.value

    def getValue(self):
        return self.value

class StorageManager:
    def __init__(self, mount_point = '', chown_user = 'root', osType = 'Linux'):
        self.logger = logging.getLogger("StorageManager.py")
        self.node_id = maestro.node['id']

        self.vg = ''

        if mount_point == '':
            timestamp = str(time.time()).split('.')[0]
            self.vg = 'vg%s' % timestamp  # volume group
            self.mount_point = '/dbaas_storage_%s' % self.vg
        else:
            self.mount_point = mount_point
            
        self.chown_user = chown_user
        self.osType = osType

    def setMountPoint(self, mount_point):
        self.mount_point = mount_point

    def getMountPoint(self):
        return self.mount_point

    def callRESTWithResp(self,url, data_file, resp_file, request_type, cn_ip = None, cn_name = None, user_token = None):
        url = maestro.replaceIP_w_CN(url, cn_ip, cn_name)
        self.logger.debug('Putting %s to %s' % (data_file, url))
        cmd = maestro.get_curl_args(['-s', '-S', '-X', request_type, '-H', 'Content-Type: application/json', '-o', resp_file, '-f', '--data-binary', '@%s' % data_file, url], user_token, incl_sc_parm = False)
        self.logger.debug('cmd = %s' % cmd)
        rc, sto = maestro.trace_stderr_call(self.logger, cmd)
        if rc != 0:
            self.logger.debug('Failed to put  %s.  curl rc == %d' % (url, rc)) 
        else:
            self.logger.debug('Succeed to put %s. curl rc=%d' % (url, rc))

        return rc, sto

    def getVolumeGroupName(self,):
        vg = util.trace_shell_func_call_with_output('get_volume_group', self.mount_point)
        if vg != None or vg != '':  
            return vg
        else:
            return ''
    
    def format_mount_disk(self, disk_size):
        self.logger.debug('Begin to format new local disk')
        if self.mount_point == '':
            vg = self.vg     #vg with timestamp postfix 
        else:
            vg = self.getVolumeGroupName()
        
        args = []
        chown_group = util.trace_shell_func_call_with_output('get_user_group_name', self.chown_user)
        disk_size = "%s" % disk_size
        args.extend([disk_size])
        args.extend([self.mount_point])
        args.extend([vg])
        args.extend([self.chown_user])
        args.extend([chown_group])
        rc = util.trace_shell_func_call('format_new_disk', *args)
        self.logger.debug('End to format new disk, rc = %s' % rc)
        if rc != 0:
            self.logger.debug('failed to format local disk')
        else:
            self.logger.debug('succeed to format local disk')
        return rc

    def getLV(self):
        lv = util.trace_shell_func_call_with_output('get_logic_volume', self.mount_point)
        if lv != None or lv != '':
            return lv
        else:
            raise StorageManagerException('Error: unable to get the logic volume info')
    
    def checkScaleNodeTaskStatus(self, task_id):
        self.logger.debug('Begin to check status of scaleNode task %d' % (task_id))
        rc = -1
        # Timeout 180s
        query_times = 10
        query_interval = 18

        if task_id == 0:
            self.logger.debug('invalid taskid %s' % task_id)
            return -1, 'invalid taskid %s' % task_id

        # https://<KS_IP>:9443/services/deployments/resources/tasks/<taskid>
        scalenode_task_url = '%sservices/deployments/resources/tasks/%s' % (maestro.node['ks-url'], task_id)
        self.logger.debug('scalenode_task_url is %s' % scalenode_task_url)

        resp_file = '/tmp/scalenode_task_%s_resp_file' % task_id
        self.logger.debug('scalenode_task_resp_file is %s' % resp_file)

        user_token = None
        url = maestro.replaceIP_w_CN(scalenode_task_url)
        cmd = maestro.get_curl_args(['-s', '-S', '-X', 'GET', '-H', 'Content-Type: application/json', '-o', resp_file, url], user_token, incl_sc_parm = False)
        self.logger.debug('cmd = %s' % cmd)
        currentmessage_text = ''
        for i in range(1, query_times):
            time.sleep(query_interval)
            if i > 1:
                timestr = "times"
            else:
                timestr = "time"
            self.logger.debug('check scaleNode task status for %s %s' % (i, timestr))
            rc, sto = maestro.trace_stderr_call(self.logger, cmd)
            if rc != 0:
                self.logger.debug('Failed to put  %s.  curl rc == %d,  sto = %s' % (url, rc, sto))
                raise StorageManagerException('Failed to put  %s.  curl rc=%d' % (url, rc))
            else:
                with open(resp_file, 'r') as f:
                    resp = json.load(f)
                    self.logger.debug('%s' % resp)
                    if resp.has_key('currentstatus'):
                        if resp.has_key('currentmessage_text'):
                            currentmessage_text=resp['currentmessage_text']
                            if currentmessage_text == "com.ibm.iaas.api.client.exception.MaestroRestException: volume is not available":
                                currentmessage_text = "volume is not available"

                        if resp['currentstatus'] == 'RM01012':
                            self.logger.debug('current task %s is succeed' % task_id)
                            rc = 0
                            break
                        elif resp['currentstatus'] == 'RM01013':
                            self.logger.debug('current task %s is failed' % task_id)
                            rc = -1
                            break
                        elif resp['currentstatus'] == 'RM01036':
                            self.logger.debug('current task %s is queued' % task_id)
                            continue
                        elif resp['currentstatus'] == 'RM01016':
                            self.logger.debug('current task %s is active' % task_id)
                    else:
                        rc = -1
                        break

        if os.path.exists(resp_file):
            os.system('rm -rf %s' % resp_file)

        self.logger.debug('End to check scaleNode task %s, rc = %s' % (task_id, rc))
        return rc, currentmessage_text

    def doScaleNodeStorage(self, disk_size):
        self.logger.debug('Begin to start scaleNode task for node %s, disksize: %s' % (self.node_id, disk_size))
        taskid = 0
        msg = ''
        block_disk = None      
        deployment_id = maestro.node['deployment.id']

        resp_file = '/tmp/resp_file_%s_%s_%s' % (deployment_id, self.node_id, time.time())
        self.logger.debug('resp_file is %s' % resp_file)
        
        vmId = os.getenv('SERVER_NAME')
        sharedDisk_url = "%sservices/deployments/%s/resources/virtualMachines/%s/sharedDisks" % (maestro.node['ks-url'], deployment_id, vmId)
        self.logger.debug('sharedDisk_url is %s' % sharedDisk_url)
        maestro.download(sharedDisk_url, resp_file)
        with open(resp_file, 'r') as f:
            blockDisks = json.load(f)            
            for bDisk in blockDisks:
                if bDisk['mount'] == self.mount_point:
                    block_disk = bDisk                    
        self.logger.debug('block_disk is %s' % (block_disk))     
        
        if os.path.exists(resp_file):   
            os.system('rm -rf %s' % resp_file)
        
        resp_file = '/tmp/resp_file_%s_%s_%s' % (deployment_id, self.node_id, time.time())
        self.logger.debug('resp_file is %s' % resp_file)
        data_file = '/tmp/data_file_%s_%s_%s' % (deployment_id, self.node_id, time.time())
        self.logger.debug('data_file is %s' % data_file)           

        scalenode_url = '%sservices/deployments/%s/scaleNode' % (maestro.node['ks-url'], deployment_id)
        self.logger.debug('scalenode_url is %s' % scalenode_url)
        if (block_disk is None):
            input_profile = {
                        'id':self.node_id,
                        'disksize':disk_size
                      }
        else:
             input_profile = {
                        'id':self.node_id,
                        'disksize':disk_size,
                        'diskid':block_disk['diskid']
                      }

        self.logger.debug('input content: %s' % input_profile)
        with open(data_file, 'w') as f:
            json.dump(input_profile, f, sort_keys = True, indent = 4)

        self.logger.debug('call scaleNode REST to start scale node task')
        rc, sto = self.callRESTWithResp(scalenode_url, data_file, resp_file, 'PUT')
        if rc != 0:
            self.logger.debug('failed to start scaling up on VM %s, because of code: rc=%s, message=%s' % (self.node_id, rc, sto))
            raise StorageManagerException('failed to start scaling up on VM %s, because of code: rc=%s, message=%s' % (self.node_id, rc, sto))
        else:
            with open(resp_file, 'r') as f:
                resp = json.load(f)
                self.logger.debug('output content:')
                self.logger.debug(json.dumps(resp, sort_keys = True, indent = 4))
                taskid = resp['taskid']
                rc, currentmessage_text = self.checkScaleNodeTaskStatus(taskid)
                if rc != 0:
                    msg = 'Failed to operate scaling up on VM %s, taskid: %s, reason: %s' % (self.node_id, taskid, currentmessage_text)
                else:
                    msg = 'succeed to start scaling up on VM %s, taskid=%s' % (self.node_id, taskid)
                    # Clean up temporary files is get successful
                    if os.path.exists(data_file):
                        os.system('rm -rf %s' % data_file)
                    if os.path.exists(resp_file):   
                        os.system('rm -rf %s' % resp_file)
                    #Post scale up storage
                    self.logger.debug('Begin to handle post-scaleNode')
                    if ( block_disk is None ):
                        self.logger.debug('format new VMFS disk')
                        rc = self.format_mount_disk(disk_size)
                        if rc != 0:
                            raise StorageManagerException('failed to handle post scaleup on VM %s' % self.node_id)
                        else:
                            self.logger.debug('succeed to handle post scaleup on VM %s' % self.node_id)                                           
                    else:                            
                        self.logger.debug('expand existing block disk with lunid:  %s' % block_disk['lunId'])
                        os.environ['MOUNT_POINT'] = self.mount_point
                        os.environ['LUN_ID'] = block_disk['lunId']
                        os.environ['NEW_SIZE'] = str(int(block_disk['size'])+int(disk_size)*1024)
                        if 'AIX' == self.osType:
                            disk_refresh_sh = os.path.join(maestro.node['scriptdir'], 'AGENT', 'block_disk_refresh_aix.sh')
                        else:                        
                            disk_refresh_sh = os.path.join(maestro.node['scriptdir'], 'AGENT', 'block_disk_refresh.sh')
                        rc= maestro.trace_call(self.logger, disk_refresh_sh)
                        if rc != 0:
                            raise StorageManagerException('failed to add extra space to local file system on disk id %s on VM %s' % (block_disk['diskid'], self.node_id))
                        else:
                            self.logger.debug('succeed to add extra space to local file system on disk id %s on VM %s' % (block_disk['diskid'], self.node_id))
                    self.logger.debug('End to handle post-scaleNode')
        self.logger.debug('End to scaleNode task for node %s' % self.node_id)

        return rc, msg
