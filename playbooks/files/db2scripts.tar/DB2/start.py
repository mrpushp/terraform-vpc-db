#
#*===================================================================
#*
#* Licensed Materials - Property of IBM
#* IBM Workload Deployer (7199-72X)
#* Copyright IBM Corporation 2014, 2020. All Rights Reserved.
#* US Government Users Restricted Rights - Use, duplication or disclosure
#* restricted by GSA ADP Schedule Contract with IBM Corp.
#*
#*===================================================================

#
import sys
import os
import maestro
import logging
import time
import json

# Get an logger with name "DB2/start.py"
logger = logging.getLogger("DB2/start.py")

parms = maestro.parms
scriptdir = maestro.node['scriptdir']
basedir = os.path.join(scriptdir, 'DB2')
libdir = os.path.join(basedir, 'lib')
if not libdir in sys.path:
    sys.path.append(libdir)
from DB2_Instance import DB2_Instance
from HADRManager import HADRManager
from DatabaseForSystemWorkload import DatabaseForSystemWorkload

def restore_export_info():
    import json
    export_json_file = "/tmp/export_json_file.json"
    restore_succeed = False
    if os.path.isfile(export_json_file):
        restore_succeed = True
        logger.debug("restore via export_json_file")
    else:
        logger.debug("export_json_file doesn't exist")
    if restore_succeed:
        logger.debug("retore export file info")
        with open(export_json_file) as f:
            maestro.export['DATABASES'] = json.load(f)

inst_name = maestro.parms['instanceOwner']
instance_agent = DB2_Instance(inst_name)
hasHADRDB = instance_agent.hasHADRDB()

instance_agent.openFirewallPolicy()
if maestro.isUpdate():
    instance_agent.restart()
else:
    instance_agent.start_text_search()
    instance_agent.start()
    restore_export_info()
    logger.debug('maestro export After reload %s' % maestro.export)
logfilesjson=json.dumps({ "role": maestro.role['name'], "types": [ {"logtype": "File", "type": "dir", "name": maestro.node['parts']['DB2']['installDir'] +"/logs"},{"logtype": "File", "type": "dir", "name": parms['instanceMountPoint']+"/sqllib/log"},{"logtype": "File", "type": "dir", "name": parms['instanceMountPoint']+"/sqllib/db2dump"}]})
maestro.loggingUtil.monitor(logfilesjson)

if hasHADRDB:
    logger.debug('scheduleHADRMonitor')
    script = 'hadr_monitor_task.py'
    interval = 60
    task = {}
    task['script'] = script
    task['interval'] = interval
    maestro.tasks.append(task)

maestro.role_status = 'RUNNING'
